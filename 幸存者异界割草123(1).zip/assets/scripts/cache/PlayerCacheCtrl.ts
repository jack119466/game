// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import CacheUtil from "../cache/CacheUtil";
import CacheKey from "../config/CacheKey";
import CommonConfig from "../config/CommonConfig";
import GeneralConfig, { GeneralBasic } from "../config/GeneralConfig";
import GlobalConfig from "../config/GlobalConfig";
import ItemConfig from "../config/ItemConfig";
import PetConfig, { PetBasic } from "../config/PetConfig";
import PlayerLevelConfig, { PlayerLevelBasic } from "../config/PlayerLevelConfig";
import UnlockManager from "../manager/UnlockManager";

const {ccclass, property} = cc._decorator;

/**
 * 玩家缓存管理
 */
@ccclass
export default class PlayerCacheCtrl {

    private static _instance: PlayerCacheCtrl = null;

    public static getInstance() {
        if (!this._instance) {
            this._instance = new PlayerCacheCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    public createTime:number = null;

    public guide:number = null;

    public chapter:number = null;

    public sysSetting = null;

    public playerExp:number = 0;
    
    public playerLevel:number = 0;

    public lastGainExpTime: number = 0;

    public lastGainVigourTime: number = 0;

    public playerLevelUpFailedTime: number = 0;

    public playerItem = null;

    public playerGeneral = null;

    public playerGong = null;

    public playerPet = null;

    public dailyRewardInfo = null;

    public attainmentRewardInfo = null;

    public killCount:number = 0;

    public aliveTime:number = 0;

    private _init() {
        // 创建时间
        let createTime:number = CacheUtil.getInstance().getNumber(CacheKey.CREATE_TIME);
        cc.log("创建时间：",createTime);
        if(createTime == 0) {
            createTime = new Date().getTime();
            CacheUtil.getInstance().set(CacheKey.CREATE_TIME,createTime);
        }

        // 新手引导步骤
        let guide:number = CacheUtil.getInstance().getNumber(CacheKey.GUIDE);
        cc.log("新手引导步骤：",guide);
        if(guide == 0) {
            guide = 0;
            CacheUtil.getInstance().set(CacheKey.GUIDE,guide);
        }

        // 系统设置
        let sysSetting = CacheUtil.getInstance().getObject(CacheKey.SYS_SETTING);
        cc.log("系统设置：",sysSetting);
        if(sysSetting == null) {
            sysSetting = {
                audioStatus: true,
                audioVolume:0.5,
                damageTextStatus:true
            };
            CacheUtil.getInstance().set(CacheKey.SYS_SETTING,JSON.stringify(sysSetting));
        }

        // 通关关卡
        let chapter:number = CacheUtil.getInstance().getNumber(CacheKey.CHAPTER);
        cc.log("通关关卡",chapter);
        if(chapter == 0) {
            chapter = 0;
            CacheUtil.getInstance().set(CacheKey.CHAPTER,chapter);
        }

        // 阶级
        let playerLevel:number = CacheUtil.getInstance().getNumber(CacheKey.PLAYER_LEVEL);
        cc.log("阶级：",playerLevel);
        if(playerLevel == null) {
            playerLevel = 0;
            CacheUtil.getInstance().set(CacheKey.PLAYER_LEVEL,playerLevel);
        }

        // 玩家经验
        let playerExp:number = CacheUtil.getInstance().getNumber(CacheKey.PLAYER_EXP);
        cc.log("玩家经验：",playerExp);
        if(playerExp == null) {
            playerExp = 0;
            CacheUtil.getInstance().set(CacheKey.PLAYER_EXP,playerExp);
        }

        // 上次获取经验时间(每分钟)
        let lastGainExpTime:number = CacheUtil.getInstance().getNumber(CacheKey.PLAYER_LAST_GAIN_EXP_TIME);
        cc.log("玩家上次获取每分钟经验时间：",lastGainExpTime);
        if(lastGainExpTime == null) {
            lastGainExpTime = 0;
            CacheUtil.getInstance().set(CacheKey.PLAYER_LAST_GAIN_EXP_TIME,lastGainExpTime);
        }

        // 上次获取体力时间
        let lastGainVigourTime:number = CacheUtil.getInstance().getNumber(CacheKey.PLAYER_LAST_GAIN_VIGOUR_TIME);
        cc.log("玩家上次获取体力时间：",lastGainVigourTime);
        if(lastGainVigourTime == null) {
            lastGainVigourTime = 0;
            CacheUtil.getInstance().set(CacheKey.PLAYER_LAST_GAIN_VIGOUR_TIME,lastGainVigourTime);
        }

        // 玩家突破失败时间
        let playerLevelUpFailedTime:number = CacheUtil.getInstance().getNumber(CacheKey.PLAYER_LEVEL_UP_FAILED_TIME);
        cc.log("玩家突破失败时间：",playerLevelUpFailedTime);
        if(playerLevelUpFailedTime == null) {
            playerLevelUpFailedTime = 0;
            CacheUtil.getInstance().set(CacheKey.PLAYER_LEVEL_UP_FAILED_TIME,playerLevelUpFailedTime);
        }

         // 玩家物品
         let playerItem = CacheUtil.getInstance().getObject(CacheKey.PLAYER_ITEM);
         cc.log("玩家物品信息",playerItem);
         if(playerItem == null) {
            playerItem = {};
             CacheUtil.getInstance().set(CacheKey.PLAYER_ITEM,JSON.stringify(playerItem));
         }

         // 玩家角色
        let playerGeneral = CacheUtil.getInstance().getObject(CacheKey.PLAYER_GENERAL);
        cc.log("玩家角色信息",playerGeneral);
        if(playerGeneral == null) {
            this.initPlayerGeneral();
            playerGeneral = this.playerGeneral;
            cc.log("lai",this.playerGeneral);
            CacheUtil.getInstance().set(CacheKey.PLAYER_GENERAL,JSON.stringify(playerGeneral));
        }

        // 玩家天赋
        let playerGong = CacheUtil.getInstance().getObject(CacheKey.PLAYER_GONG);
        cc.log("玩家天赋信息",playerGong);
        if(playerGong == null) {
        playerGong = {};
            CacheUtil.getInstance().set(CacheKey.PLAYER_GONG,JSON.stringify(playerGong));
        }

        // 玩家伙伴
        let playerPet = CacheUtil.getInstance().getObject(CacheKey.PLAYER_PET);
        cc.log("玩家伙伴信息",playerPet);
        if(playerPet == null) {
            playerPet = {};
            CacheUtil.getInstance().set(CacheKey.PLAYER_GONG,JSON.stringify(playerPet));
        }

        
        // 玩家每日奖励领取信息
        let dailyRewardInfo = CacheUtil.getInstance().getObject(CacheKey.DAILY_REWARD_INFO);
        cc.log("玩家每日奖励领取信息",dailyRewardInfo);
        if(dailyRewardInfo == null) {
            dailyRewardInfo = {
                rewardTime : 0,
                rewardCount: 0
            };
            CacheUtil.getInstance().set(CacheKey.DAILY_REWARD_INFO,JSON.stringify(dailyRewardInfo));
        }

        // 玩家成就奖励领取信息
        let attainmentRewardInfo = CacheUtil.getInstance().getObject(CacheKey.ATTAINMENT_REWARD_INFO);
        cc.log("玩家成就奖励领取信息",attainmentRewardInfo);
        if(attainmentRewardInfo == null) {
            attainmentRewardInfo = {};
            CacheUtil.getInstance().set(CacheKey.ATTAINMENT_REWARD_INFO,JSON.stringify(attainmentRewardInfo));
        }

        
        // 总击杀数量
        let killCount:number = CacheUtil.getInstance().getNumber(CacheKey.KILL_COUNT);
        cc.log("总击杀数量：",killCount);
        if(killCount == null) {
            killCount = 0;
            CacheUtil.getInstance().set(CacheKey.KILL_COUNT,killCount);
        }

        
        // 总存活时间
        let aliveTime:number = CacheUtil.getInstance().getNumber(CacheKey.ALIVE_TIME);
        cc.log("总存活时间：",aliveTime);
        if(aliveTime == null) {
            aliveTime = 0;
            CacheUtil.getInstance().set(CacheKey.ALIVE_TIME,aliveTime);
        }

        this.createTime = createTime;
        this.guide = guide;
        this.chapter = chapter;
        this.sysSetting = sysSetting;
        this.playerExp = playerExp;
        this.playerLevel = playerLevel;
        this.lastGainExpTime = lastGainExpTime;
        this.lastGainVigourTime = lastGainVigourTime;
        this.playerLevelUpFailedTime = playerLevelUpFailedTime;
        this.playerItem = playerItem;
        this.playerGeneral = playerGeneral;
        this.playerGong = playerGong;
        this.playerPet = playerPet;
        this.dailyRewardInfo = dailyRewardInfo;
        this.attainmentRewardInfo = attainmentRewardInfo;
        this.killCount = killCount;
        this.aliveTime = aliveTime;
    }

    private _destroy() { }

     /**
     * 修改通关关卡
     * @param chapter 关卡 
     */
    public editChapter(chapter) {
        this.chapter = chapter;
        this.setChapter();
    }

    public getChapter() {
        return this.chapter;
    }
    
    private setChapter() {
        CacheUtil.getInstance().set(CacheKey.CHAPTER,this.chapter);
    }

    /**
     * 获取系统设置
     */
    public getSysSetting() {
        return this.sysSetting;
    }

    /**
     * 修改声音启用状态
     * @param status 状态
     */
    public editAudioStatus(status) {
        this.sysSetting.audioStatus = status;
        this.setSysSetting();
    }

    /**
     * 修改伤害飘字启用状态
     * @param status 状态
     */
    public editDamageTextStatus(status) {
        this.sysSetting.damageTextStatus = status;
        this.setSysSetting();
    }

     /**
     * 修改音量
     * @param volume 音量 
     */
    public editAudioVolume(volume) {
        this.sysSetting.audioVolume = volume;
        this.setSysSetting();
    }

    public setSysSetting() {
        CacheUtil.getInstance().set(CacheKey.SYS_SETTING,JSON.stringify(this.sysSetting));
    }

    /**
     * 增加玩家经验
     * @param limitType 获取类型 1-每分钟获取 2-消耗获取(待做) 
     */
    public addPlayerExp(limitType:number) {
        let addExp = null;
        if(limitType == 1) {
            addExp = this.playerGainExpByOneMinute();
        }
        
        if(addExp == null) {
            return;
        }
        cc.log("增加玩家经验：",addExp);
        this.playerExp += addExp;    
        this.setPlayerExp();
        this.setPlayerGainExpTime();
    }

    /**
     * 玩家每分钟获取经验
     * @returns 
     */
    private playerGainExpByOneMinute() {
        // let nowTime = new Date().getTime();
        // // 根据阶级获取每分钟获得经验配置
        // let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(this.playerLevel);
        // if(playerLevelConfig == null) {
        //     return;
        // }
        // let addExp = playerLevelConfig.oneMintueGainExp; // 每分钟经验
        // // 当前时间距离上一次获得经验的时间
        // let minutes = 1;
        // if(this.lastGainExpTime > 0) { // 防止首次获得经验膨胀
        //     minutes = Math.floor((nowTime - this.lastGainExpTime) / 60000)
        // }
        // if(minutes <= 0) {
        //     return;
        // }

        
        // if(minutes > playerLevelConfig.maxOfflineGainMinute) {
        //     minutes = playerLevelConfig.maxOfflineGainMinute;
        // }
        // cc.log("玩家每分钟获得经验：%s, 距离上次总共有 %s 分钟,获得总经验：%s",addExp,minutes,(addExp * minutes));
        // return addExp * minutes;
    }

    /**
     * 减少玩家经验
     * @param exp 经验
     */
    public costPlayerExp(exp:number) {
        this.playerExp -= exp;
        this.setPlayerExp();
    }

    /**
     * 设置玩家经验
     */
    public setPlayerExp() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_EXP,this.playerExp);
    }

    /**
     * 获取玩家经验
     * @returns 
     */
    public getPlayerExp() {
        return this.playerExp;
    }

    /**
     * 增加阶级
     * @param level 等级
     */
     public addPlayerLevel(level:number) {
        if(PlayerLevelConfig.getConfigByLevel(this.playerLevel + level) == null) {
            cc.log("玩家升级失败,{}的阶级配置找不到",(this.playerLevel + level));
            return;
        }
        
        this.playerLevel += level;
        this.setPlayerLevel();
    }

    /**
     * 设置阶级
     */
    public setPlayerLevel() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_LEVEL,this.playerLevel);
    }

    /**
     * 获取阶级
     * @returns 
     */
    public getPlayerLevel() {
        return this.playerLevel;
    }


    /**
     * 设置玩家获得经验时间
     */
    public setPlayerGainExpTime() {
        this.lastGainExpTime = new Date().getTime();
        CacheUtil.getInstance().set(CacheKey.PLAYER_LAST_GAIN_EXP_TIME,this.lastGainExpTime);
    }

    /**
     * 获取玩家获得经验时间(上次获取经验时间 + 60秒)
     * @returns 
     */
    public getPlayerGainExpTime() {
        return this.lastGainExpTime + 60000;
    }

    public recoveryVigour() {
        let nowTime = new Date().getTime();
        if(this.getPlayerGainVigourTime() > nowTime) {
            return;
        }

        let addNum = 0;
        // 如果上次恢复时间为0，则代表为第一次，只恢复一点
        if(this.lastGainVigourTime == 0) {
            addNum = 1;
        }else{ 
            // 计算到目前为止可以恢复多少点体力
            addNum = Math.floor((nowTime - this.lastGainVigourTime) / GlobalConfig.VIGOUR_RECORVEY_TIME);
        }

        // 防止溢出
        if(this.getPlayerVigourNum() + addNum > GlobalConfig.VIGOUR_MAX_NUM) {
            addNum = GlobalConfig.VIGOUR_MAX_NUM - this.getPlayerVigourNum();
        }

        // 增加体力
        this.addPlayerItem(Number(ItemConfig.ITEM_CONST.VIGOUR),addNum);

        // 更新上次获取体力时间
        this.setPlayerGainVigourTime(nowTime);
    }

    /**
     * 设置玩家获得体力时间
     */
    public setPlayerGainVigourTime(time:number) {
        this.lastGainVigourTime = time;
        CacheUtil.getInstance().set(CacheKey.PLAYER_LAST_GAIN_VIGOUR_TIME,this.lastGainVigourTime);
    }

    /**
     * 获取玩家获得体力时间(上次获取体力时间 + 获取体力间隔时间)
     * @returns 
     */
    public getPlayerGainVigourTime():number {
        return this.lastGainVigourTime + GlobalConfig.VIGOUR_RECORVEY_TIME;
    }


    /**
    * 设置玩家突破失败时间
    */
    public setPlayerLevelUpFailedTime() {
        this.playerLevelUpFailedTime = new Date().getTime();
        CacheUtil.getInstance().set(CacheKey.PLAYER_LEVEL_UP_FAILED_TIME,this.playerLevelUpFailedTime);
    }

    /**
     * 获取突破失败恢复时间
     * @returns 
     */
    public getPlayerRecoveryTime() {
        // let nowTime = new Date().getTime();
        // // （当前时间 - 突破失败时间） - 元神受损恢复时间
        // let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(this.playerLevel);
        // let recoveryTime = Math.floor((playerLevelConfig.recoveryTime - (nowTime - this.playerLevelUpFailedTime)) / 1000);
        // return recoveryTime;
    }

    /**
     * 增加玩家物品数量
     * @param itemId 物品ID
     * @param itemCount 物品数量
     */
     public addPlayerItem(itemId:number,itemCount:number):boolean {
        cc.log("增加玩家物品,itemId:%s , itemCount:%s",itemId,itemCount);
        if(itemCount < 0) {
            cc.log("数量小于0");
            return false;
        }
        if(ItemConfig.getConfigById(itemId) == null) {
            cc.log("%s的物品配置不存在",itemId);
            return false;
        }

        let oldCount = 0;
        if(this.playerItem[itemId+""] != null) {
            oldCount = this.playerItem[itemId+""];
        }

        this.playerItem[itemId+""] = oldCount + itemCount;
        this.setPlayerItem();
        return true;
    }

     /**
     * 减少玩家物品数量
     * @param itemId 物品ID
     * @param itemCount 物品数量
     */
     public costPlayerItem(itemId:number,itemCount:number):boolean {
        cc.log("减少玩家物品,itemId:%s , itemCount:%s",itemId,itemCount);
        if(itemCount < 0) {
            cc.log("数量小于0");
            return false;
        }
        if(ItemConfig.getConfigById(itemId) == null) {
            cc.log("%s的物品配置不存在",itemId);
            return false;
        }

        let oldCount = 0;
        if(this.playerItem[itemId+""] != null) {
            oldCount = this.playerItem[itemId+""];
        }

        if(itemCount > oldCount) {
            cc.log("减少数量：%s,拥有数量：%s",itemCount,oldCount);
            return false;
        }

        this.playerItem[itemId+""] = oldCount - itemCount;
        this.setPlayerItem();
        return true;
    }

    /**
     * 设置玩家金币数量
     */
    public setPlayerItem() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_ITEM,JSON.stringify(this.playerItem));
    }

    /**
     * 获取玩家金币数量
     * @returns 
     */
    public getPlayerGoldNum() {
        let itemCount = 0;
        if(this.playerItem[ItemConfig.ITEM_CONST.GOLD] != null) {
            itemCount = this.playerItem[ItemConfig.ITEM_CONST.GOLD];
        }
        return itemCount;
    }

    /**
     * 获取玩家兽晶数量
     * @returns 
     */
     public getPlayerShouJingNum() {
        let itemCount = 0;
        if(this.playerItem[ItemConfig.ITEM_CONST.SHOU_JING] != null) {
            itemCount = this.playerItem[ItemConfig.ITEM_CONST.SHOU_JING];
        }
        return itemCount;
    }

    /**
     * 获取玩家体力数量
     * @returns 
     */
     public getPlayerVigourNum() {
        let itemCount = 0;
        if(this.playerItem[ItemConfig.ITEM_CONST.VIGOUR] != null) {
            itemCount = this.playerItem[ItemConfig.ITEM_CONST.VIGOUR];
        }else {
            // 初始化为体力上限
            itemCount = GlobalConfig.VIGOUR_MAX_NUM;
            this.playerItem[ItemConfig.ITEM_CONST.VIGOUR] = itemCount;
            this.setPlayerItem();
        }

        return itemCount;
    }

     /**
     * 获取玩家物品数量
     * @returns 
     */
    public getPlayerItemNum(itemId:number) {
        let itemCount = 0;
        if(this.playerItem[itemId + ""] != null) {
            itemCount = this.playerItem[itemId + ""];
        }
        return itemCount;
    }

    /**
     * 获取玩家角色信息
     * @returns 
     */
    public getPlayerGeneral() {
        return this.playerGeneral;
    }

    /**
     * 获取玩家指定角色信息
     * @param generalId 角色ID
     */
    public getPlayerGeneralById(generalId:number) {
        return this.playerGeneral[generalId + ""];
    }

     /**
     * 获取玩家当前使用角色的角色ID
     */
    public getPlayerUseGeneral() {
        for(const id in this.playerGeneral) {
            let general = this.playerGeneral[id];
            if(CommonConfig.USE_STATUS.USED == general.useStatus) {
                return general.id;
            }
        }
        return 1;
    }

    /**
     * 玩家使用角色
     * @param generalId 角色ID
     */
    public playerUseGeneral(generalId:number) {
        for(const id in this.playerGeneral) {
            let general = this.playerGeneral[id];
            let useStatus = CommonConfig.USE_STATUS.UNUSED;
            if(general.id == generalId) {
                useStatus = CommonConfig.USE_STATUS.USED;
            }
            this.playerGeneral[id].useStatus = useStatus;
        }
        this.setPlayerGeneral();
    }

    /**
     * 设置玩家角色信息
     */
     public setPlayerGeneral() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_GENERAL,JSON.stringify(this.playerGeneral));
    }

    public initPlayerGeneral() {
        // 是否置为使用
        let isUse = true;
        // 玩家初始获得免费角色,并将第一个免费角色置为使用
        for(let i = 0; i < GeneralConfig.CONFIG.length;i++) {
            let generalConfig = GeneralConfig.CONFIG[i];
            if(UnlockManager.UNLOCK_TYPE.FREE == generalConfig.unlockType) {
                this.addGeneral(generalConfig.id,isUse);
                if(isUse) {
                    isUse = false;
                }
            }
        }
    }

    /**
     * 玩家获得新角色
     * @param generalId 角色配置 
     * @param isUse 是否置为使用 
     */
    public addGeneral(generalId:number,isUse:boolean) {
        cc.log(generalId,isUse);
        cc.log(GeneralConfig.getConfigById(generalId));
        if(GeneralConfig.getConfigById(generalId) == null) {
            return;
        }

        let general = {
            id : generalId,
            unlockStatus: CommonConfig.UNLOCK_STATUS.UNLOCK,
            useStatus: isUse ? CommonConfig.USE_STATUS.USED : CommonConfig.USE_STATUS.UNUSED,
        }

        cc.log(general);
        if(this.playerGeneral == null) {
            this.playerGeneral = {};
        }

        this.playerGeneral[generalId + ""] = general;

        cc.log(this.playerGeneral);
        this.setPlayerGeneral();

        return general;
    }

    /**
     * 获取玩家天赋信息
     * @returns 
     */
     public getPlayerGong() {
        return this.playerGong;
    }

    /**
     * 获取玩家指定天赋信息
     * @param gongId 天赋ID
     */
    public getPlayerGongById(gongId:number) {
        return this.playerGong[gongId + ""];
    }

    /**
     * 获取玩家指定天赋等级
     * @param gongId 天赋ID
     */
     public getPlayerGongLevelById(gongId:number) {
        let gongInfo = this.playerGong[gongId + ""];
        let level = 0;
        if(gongInfo != null) {
            level = gongInfo.level;
        }
        return level;
    }

     /**
     * 玩家天赋升级
     * @param gongId 天赋ID
     */
    public plyerGongLevelUp(gongId:number){
        let gongInfo = this.playerGong[gongId + ""];
        if(gongInfo == null) {
            gongInfo = {
                id: gongId,
                level : 0,
            }
        }
        gongInfo.level = gongInfo.level + 1;
        this.playerGong[gongId + ""] = gongInfo;
        this.setPlayerGong();
    }
        
    /**
     * 设置玩家天赋信息
     */
    public setPlayerGong() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_GONG,JSON.stringify(this.playerGong));
    }

    /**
     * 获取玩家伙伴信息
     * @returns 
     */
     public getPlayerPet() {
        return this.playerPet;
    }

    /**
     * 获取玩家指定伙伴信息
     * @param petId 伙伴ID
     */
    public getPlayerPetById(petId:number) {
        return this.playerPet[petId + ""];
    }

    /**
     * 获取玩家指定伙伴等级
     * @param petId 伙伴ID
     */
     public getPlayerPetLevelById(petId:number) {
        let petInfo = this.playerPet[petId + ""];
        let level = 0;
        if(petInfo != null) {
            level = petInfo.level;
        }
        return level;
    }

    /**
     * 玩家伙伴升级
     * @param petId 伙伴ID
     */
    public plyerPetLevelUp(petId:number){
        let petInfo = this.playerPet[petId + ""];
        if(petInfo == null) {
            petInfo = {
                id: petId,
                level : 0,
            }
        }
        petInfo.level = petInfo.level + 1;
        this.playerPet[petId + ""] = petInfo;
        this.setPlayerPet();
    }

    /**
     * 设置玩家伙伴信息
     */
     public setPlayerPet() {
        CacheUtil.getInstance().set(CacheKey.PLAYER_PET,JSON.stringify(this.playerPet));
    }

    /**
     * 玩家获得伙伴
     * @param petId 伙伴ID
     * @isUse petId 是否置为使用
     */
    public addPet(petId:number,isUse:boolean) {
        let petConfig:PetBasic = PetConfig.getConfigById(petId);
        if(petConfig == null) {
            return;
        }

        let pet = {
            id : petConfig.id,
            level: 0,
            unlockStatus: CommonConfig.UNLOCK_STATUS.UNLOCK,
            useStatus: isUse ? CommonConfig.USE_STATUS.USED : CommonConfig.USE_STATUS.UNUSED,
        }

        this.playerPet[petId+""] = pet;
        this.setPlayerPet();

        return pet;
    }

    /**
     * 获取玩家当前使用伙伴的伙伴ID
     */
    public getPlayerUsePet() {
        for(const id in this.playerPet) {
            let pet = this.playerPet[id];
            if(CommonConfig.USE_STATUS.USED == pet.useStatus) {
                return pet.id;
            }
        }
        return 1;
    }

    /**
     * 玩家使用角色
     * @param petId 角色ID
     */
    public playerUsePet(petId:number) {
        for(const id in this.playerPet) {
            let pet = this.playerPet[id];
            let useStatus = CommonConfig.USE_STATUS.UNUSED;
            if(pet.id == petId) {
                useStatus = CommonConfig.USE_STATUS.USED;
            }
            this.playerPet[id].useStatus = useStatus;
        }
        this.setPlayerPet();
    }

    /**
     * 获取玩家每日奖励领取信息
     * @returns 
     */
    public getDailyRewardInfo() {
        return this.dailyRewardInfo;
    }

    /**
     * 设置玩家每日奖励领取信息
     * @param info 
     */
    public setDailyRewardInfo(info) {
        this.dailyRewardInfo = info
        CacheUtil.getInstance().set(CacheKey.DAILY_REWARD_INFO,JSON.stringify(this.dailyRewardInfo));
    }

    /**
     * 获取玩家每日奖励领取信息
     * @returns 
     */
    public getAttainmentRewardInfo() {
        return this.attainmentRewardInfo;
    }

    /**
     * 设置玩家成就奖励领取信息
     * @param info 
     */
    public setAttainmentRewardInfo(info) {
        this.attainmentRewardInfo = info
        CacheUtil.getInstance().set(CacheKey.ATTAINMENT_REWARD_INFO,JSON.stringify(this.attainmentRewardInfo));
    }

    /**
     * 获取总击杀数量
     */
    public getKillCount():number {
        return this.killCount;
    }

    /**
     * 设置总击杀数量
     */
    public setKillCount(count:number) {
        this.killCount = count;
        CacheUtil.getInstance().set(CacheKey.KILL_COUNT,this.killCount);
    }

    /**
     * 获取总存活时间
     */
    public getAliveTime():number {
        return this.aliveTime;
    }

    /**
     * 设置总存活时间
     */
    public setAliveTime(aliveTime:number) {
        this.aliveTime = aliveTime;
        CacheUtil.getInstance().set(CacheKey.ALIVE_TIME,this.aliveTime);
    }
}
