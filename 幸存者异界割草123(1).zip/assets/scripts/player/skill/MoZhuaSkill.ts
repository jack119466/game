
import Monster from "../../monster/Monster";
import BaseSkill from "./BaseSkill";

const {ccclass, property} = cc._decorator;

/**
 * 风咒技能
 */
@ccclass
export default class MoZhuaSkill extends BaseSkill {

    private sourcePos:cc.Vec2 = null; // 初始位置

    // 横向移动 调整为一次性显示
    // move(dt): void {

    // }

    onCollisionEnter(other, self) {
        let monster:Monster = other.node.getComponent(Monster);    
        if(monster) {
            // 怪物已死亡
            if(!monster.isAlive) {
                return;
            }
            // 如果该怪物在超出允许被攻击次数就不处理
            if(this.atkMonsterInfo[monster.id] != null && this.atkMonsterInfo[monster.id].num >= this.sameAtkNum) {
                return;
            }
            if(this.atkMonsterInfo[monster.id] == null) {
                this.atkMonsterInfo[monster.id] = {
                    time: 0,
                    num: 0
                }
            }
            this.atkMonsterInfo[monster.id].num += 1; // 攻击次数
            monster.beHit(this.atk);
        }
    }
}
