
import Monster from "../../monster/Monster";
import BaseSkill from "./BaseSkill";

const { ccclass, property } = cc._decorator;

/**
 * 风咒技能
 */
@ccclass
export default class AmuletSkill extends BaseSkill {

    private sourcePos: cc.Vec2 = null; // 初始位置

    private angle = null;
    private radius = null;
    private clockwise = true;

    start() {
        // 计算初始角度和半径
        this.angle = this.getAngle(this.node.parent.getPosition(), this.node.getPosition()) + this.initAngle;
        this.radius = this.getDistance(this.node.parent.getPosition(), this.node.getPosition());
    }

    getAngle(p1: cc.Vec2, p2: cc.Vec2): number {
        return Math.atan((p2.y - p1.y) / (p2.x - p1.x));
    }

    /**
     * 获取两点间的距离
     * @param p1 点1
     * @param p2 点2
     */
    private getDistance(p1: cc.Vec2, p2: cc.Vec2): number {
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    }

    /**
     * 围绕角色旋转
     * @param dt 
     */
    move(dt): void {
        // 将角度转换为弧度
        let radian = Math.PI / 180 * this.angle;
        // 更新节点的位置
        this.node.x = this.node.parent.getPosition().x + this.radius * Math.cos(radian);
        this.node.y = this.node.parent.getPosition().y + this.radius * Math.sin(radian);
        // 计算下一帧的角度
        let anglePerFrame = dt * (this.speed / 3);
        if (this.clockwise) this.angle -= anglePerFrame;
        else this.angle += anglePerFrame;
        // 重置角度，避免数值过大
        if (this.angle >= 360) this.angle %= 360;
        else if (this.angle <= -360) this.angle %= -360;
    }


    radian: number = 0;

    /**
     * 围绕角色旋转
     * @param dt 
     */
    // move(dt): void {
    //     this.radian += dt * (200 / 100);
    //     let x = 100 * Math.cos(this.radian) + this.node.parent.getPosition().x;
    //     let y = 100 * Math.sin(this.radian) + this.node.parent.getPosition().y;
    //     this.node.setPosition(cc.v2(x, y));
    //     // Math.atan2 反正切函数 返回从X轴到某个点的角度（以弧度为单位）。
    //     // let angle = Math.atan2(y, x) / (Math.PI / 180);
    //     // this.node.angle = angle;

    //     console.log('x = ' + x + '  y = ' + y ); //+ '  angle = ' + angle
    // }



    onCollisionEnter(other, self) {
        let monster: Monster = other.node.getComponent(Monster);
        if (monster) {
            // 怪物已死亡
            if (!monster.isAlive) {
                return;
            }
            // // 如果该怪物在超出允许被攻击次数就不处理
            // if(this.atkMonsterInfo[monster.id] != null && this.atkMonsterInfo[monster.id].num >= this.sameAtkNum) {
            //     return;
            // }
            // if(this.atkMonsterInfo[monster.id] == null) {
            //     this.atkMonsterInfo[monster.id] = {
            //         time: 0,
            //         num: 0
            //     }
            // }
            // this.atkMonsterInfo[monster.id].num += 1; // 攻击次数
            monster.beHit(this.atk);
        }
    }
}
