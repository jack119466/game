
import GameMain from "../../main/GameMain";
import Monster from "../../monster/Monster";
import BaseSkill from "./BaseSkill";

const {ccclass, property} = cc._decorator;

/**
 * 龙卷风技能
 */
@ccclass
export default class LongJuanFengSkill extends BaseSkill {

    private lastGetMonsterNode = null;

    // updateDir(): void {
    //     let gameMain:GameMain =  this.node.parent.getComponent(GameMain);
    //     let monsterWorldPos: cc.Vec2 = null;
    //     if(this.lastGetMonsterNode == null || !this.lastGetMonsterNode.active) {
    //         let monsterNode = gameMain.getNearMonsterNode();
    //         cc.log("获取到怪物",monsterNode);
    //         if(monsterNode != null && monsterNode.active) {
    //             this.lastGetMonsterNode = monsterNode;
    //             monsterWorldPos = this.node.convertToNodeSpaceAR(monsterNode.convertToWorldSpaceAR(cc.Vec2.ZERO));
    //         } 
    //     }else {
    //         let id = this.lastGetMonsterNode.getComponent(Monster).id;
    //         let monsterNode = gameMain.getMonsterInfo(id);
    //         if(monsterNode == null) {
    //             this.lastGetMonsterNode = null;
    //             return;
    //         }
    //         monsterWorldPos = this.node.convertToNodeSpaceAR(monsterNode.convertToWorldSpaceAR(cc.Vec2.ZERO));
    //     }
    //     if(monsterWorldPos == null) {
    //         return;
    //     }
    //     let normalizeVec: cc.Vec2 = monsterWorldPos.subtract(this.node.getPosition()).normalize();
    //     this.dirX = normalizeVec.x; // cos
    //     this.dirY = normalizeVec.y; // sin
    //     cc.log("更新方向",this.dirX ,this.dirY);
    // }

    // 移动
    move(dt): void {
        let currPos:cc.Vec2 = this.node.getPosition();

        var vx: number = this.speed * this.dirX * dt;
        var vy: number = this.speed * this.dirY * dt;


        let nextX = currPos.x += vx;
        let nextY = currPos.y += vy;
        this.node.setPosition(cc.v2(nextX,nextY));
    }

    onCollisionStay(other, self) {
        let monster:Monster = other.node.getComponent(Monster);    
        if(monster) {
            // 怪物已死亡
            if(!monster.isAlive) {
                return;
            }
            // 如果该怪物在允许被攻击间隔内就不做处理
            if(this.atkMonsterInfo[monster.id] != null && this.atkMonsterInfo[monster.id].time * 1000 + this.atkIntervalTime > this.currTime * 1000) {
                return;
            }
            if(this.atkMonsterInfo[monster.id] == null) {
                this.atkMonsterInfo[monster.id] = {
                    time: 0,
                    num: 0
                }
            }
            this.atkMonsterInfo[monster.id].time = this.currTime; // 攻击时间
            this.atkMonsterInfo[monster.id].num += 1; // 攻击次数
            monster.beHit(this.atk);
        }
    }

}
