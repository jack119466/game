
import Monster from "../../monster/Monster";
import BaseSkill from "./BaseSkill";

const {ccclass, property} = cc._decorator;

/**
 * 飞刀技能
 */
@ccclass
export default class FeiDaoSkill extends BaseSkill {


    onLoad () {
    }

    start () {
    }

    // update (dt) {
    // }

    // 移动
    move(dt): void {
        let currPos:cc.Vec2 = this.node.getPosition();

        var vx: number = this.speed * this.dirX * dt;
        var vy: number = this.speed * this.dirY * dt;


        let nextX = currPos.x += vx;
        let nextY = currPos.y += vy;
        this.node.setPosition(cc.v2(nextX,nextY));
    }

    onCollisionEnter(other, self) {
        let monster:Monster = other.node.getComponent(Monster);    
        if(monster) {
            // 怪物已死亡
            if(!monster.isAlive) {
                return;
            }
            // 此处判断已穿透数是否大于穿透数量，避免造成多次伤害
            if(this.passNum != -1 && this.alreadyPassNum >= this.passNum) {
                return;
            }
            this.alreadyPassNum += 1;
            monster.beHit(this.atk);
        }
    }
}
