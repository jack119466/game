// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import Monster from "../../monster/Monster";
import BaseSkill from "./BaseSkill";

const {ccclass, property} = cc._decorator;

/**
 * 杀戮领域
 */
@ccclass
export default class QuanQuanSkill extends BaseSkill {


    onCollisionStay(other, self) {
        let monster:Monster = other.node.getComponent(Monster);    
        if(monster) {
            // 怪物已死亡
            if(!monster.isAlive) {
                return;
            }
            // 如果该怪物在允许被攻击间隔内就不做处理
            if(this.atkMonsterInfo[monster.id] != null && this.atkMonsterInfo[monster.id].time * 1000 + this.atkIntervalTime > this.currTime * 1000) {
                return;
            }
            if(this.atkMonsterInfo[monster.id] == null) {
                this.atkMonsterInfo[monster.id] = {
                    time: 0,
                    num: 0
                }
            }
            this.atkMonsterInfo[monster.id].time = this.currTime; // 攻击时间
            this.atkMonsterInfo[monster.id].num += 1; // 攻击次数
            monster.beHit(this.atk);
        }
    }

}
