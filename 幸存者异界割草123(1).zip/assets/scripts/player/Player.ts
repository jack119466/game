import CacheUtil from '../cache/CacheUtil';
import PlayerCacheCtrl from '../cache/PlayerCacheCtrl';
import CacheKey from '../config/CacheKey';
import CommonConfig from '../config/CommonConfig';
import GeneralConfig, { GeneralBasic } from '../config/GeneralConfig';
import PetConfig, { PetBasic } from '../config/PetConfig';
import ExpDrop from '../drop/ExpDrop';
import joystick from '../jsonstick/Joinstick'
import GameMain from '../main/GameMain';
import AnimationManger from '../manager/AnimationManager';
import PetSkillCtrl from '../manager/PetSkillCtrl';
import PlayerFightPropCtrl from '../manager/PlayerFightPropCtrl';
import SkillCtrl from '../manager/SkillCtrl';
import PlayerFightProp from '../prop/PlayerFightProp';
import MathUtil from '../utils/MathUtil';
import PositionUtil from '../utils/PositionUtil';
import SpriteUtil from '../utils/SpriteUtil';

const {ccclass, property} = cc._decorator;

@ccclass
export default class Player extends cc.Component {

    @property(joystick)
    stick: joystick = null;

    @property(cc.ProgressBar)
    boold: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    expProgress: cc.ProgressBar = null;

    @property(cc.Label)
    levelLabel: cc.Label = null;

    @property(cc.Prefab)
    petPrefab: cc.Prefab = null;

    @property(cc.Node)
    damageNode:cc.Node = null;

    @property(cc.Node)
    point: cc.Node = null; // 指向


    // 摄像机
    @property(cc.Node)
    camera: cc.Node = null;

    public isAlive = false; // 是否存活

    public currDir = null; // 当前朝向

    private level = 0; // 等级

    private exp = 0; // 经验

    private offset: cc.Vec2 = cc.v2(0,0);

    private animationStatus:boolean = false; // 动画是否在运行

    private currTime:number = 0; // 当前时间, dt 

    private showDamageEndTime:number = 0; // 展示受伤效果结束时间 

    private lastRecoveryHpTime:number = 0; // 上次恢复生命时间 

    private petId:number = null; // 伙伴ID

    // 上一次X方向大小
    private lastDirX = 1;

    onLoad () {
        // cc.log("人物UI节点：",this.playerUI);
        // if(this.playerUI) {
        //     this.body = this.playerUI.getComponent(cc.RigidBody);
        // }
        // cc.log("人物UI节点body：",this.body);
        
        
        // 初始化
        this.init();
    }

    start () {
        // 摄像机偏离角色位置offset = 摄像机 - 角色位置
        if(this.camera != null) {
            this.offset = this.camera.getPosition().sub(this.node.getPosition());
        }
    }

    init () {
        this.level = 1;
        
        // 计算玩家战斗属性
        PlayerFightPropCtrl.getInstance().initFightProp();
        
        this.isAlive = true;
        this.exp = 0;

        // 刷新,计算玩家战斗属性后执行
        this.flush();

        // 初始化玩家角色相关信息（如初始技能、角色动画)
        this.initPlayerGeneral();
        
        // 初始化玩家上阵伙伴信息
        this.initPlayerPet();

        // 玩家的层级最高
        this.node.z = 100;

    }

    // 刷新
    public flush() {

        // 拾取范围
        this.resetGainRange()

        // 绘制血条
        this.resetBoold();
    }

    // 重新设置拾取范围的刚体大小
    resetGainRange() {
        let gainRange:cc.CircleCollider = this.node.getComponent(cc.CircleCollider);
        // tag = 1为拾取范围碰撞组件
        if(gainRange != null && gainRange.tag == 1) {
            gainRange.radius = PlayerFightPropCtrl.getInstance().getGainRange();
        }
    }

    // 绘制血条
    resetBoold() {
        let currHp = PlayerFightPropCtrl.getInstance().getCurrHp();
        let maxHp = PlayerFightPropCtrl.getInstance().getHp();
        // 血条百分比
        let per = currHp / maxHp;
        if(per == this.boold.progress) {
            return;
        }
        this.boold.progress = per;
    }

    /**
     * 被攻击
     * @param atkNum 攻击力 
     */
    beHit(atkNum:number) {
        if(atkNum <= 0) {
            return;
        }

        // 玩家防御力
        let def = PlayerFightPropCtrl.getInstance().getDef();

        // 至少扣除1HP
        let hp = 1;

        // 伤害值计算： 攻击方的攻击力 - 玩家防御力
        if(atkNum > def) {
            hp = atkNum - def;
        }
        
        // cc.log("玩家受到攻击,攻击者atk:%s 玩家def:%s 扣血:%s",atkNum,def,hp);

        this.costHp(hp);
    }

    showDamageNode() {
        this.showDamageEndTime = this.currTime + 2000;
        if(!this.damageNode.active) {
            this.damageNode.active = true;
        }
    }

    checkHideDamageNode() {
        if(this.showDamageEndTime <= this.currTime && this.damageNode.active) {
            this.damageNode.active = false;
        }
    }

    /**
     * 扣血
     * @param hp 扣除血量
     * @param 
     */
     costHp(hp:number) {
        if(!this.isAlive) {
            return;
        }

        if(hp <= 0) {
            return;
        }

        let currHp = PlayerFightPropCtrl.getInstance().getCurrHp();
        let maxHp = PlayerFightPropCtrl.getInstance().getHp();

        if(hp > currHp) {
            hp = currHp
        }

        currHp = currHp - hp;

        PlayerFightPropCtrl.getInstance().setCurrHp(currHp);

        this.showDamageNode();

        // 重新绘制血条
        this.resetBoold();        

        // 死亡
        if(currHp == 0) {
            this.isAlive = false;
             // 通知主节点玩家死亡
            let gameMain:GameMain = this.node.parent.getComponent(GameMain);
            if(gameMain) {
                // cc.log("玩家通知主节点玩家死亡");
                gameMain.playerDie();
            }
        }
    }

    update (dt) {
        if(!this.isAlive) {
            return;
        }

        this.currTime += (dt * 1000);

        // 检查移动
        this.move(dt)

        // 检查生命恢复
        this.checkHpRecovery();

        this.checkHideDamageNode();
    }

    // 移动
    move(dt) {
        if(this.camera != null) {
            this.camera.x = this.node.x + this.offset.x;
            this.camera.y = this.node.y + this.offset.y;
        }

        if(this.stick.dir.x === 0 && this.stick.dir.y === 0) {
            return;
        }

        this.currDir = this.stick.dir;

        let speed = PlayerFightPropCtrl.getInstance().getSpeed();

        var vx: number = speed * this.stick.dir.x * dt;
        var vy: number = speed * this.stick.dir.y * dt;


        let nextX = this.node.position.x += vx;
        let nextY = this.node.position.y += vy;
        this.node.setPosition(cc.v2(nextX,nextY));

        if(this.stick.dir.x < 0 && this.lastDirX > 0) {
            this.setScaleX(-1);
        }else if(this.stick.dir.x > 0 && this.lastDirX < 0){
            this.setScaleX(1);
        }
        
        // this.body.linearVelocity = cc.v2(vx,vy);

        // 拾取范围跟随
        // this.pickingRegion.setPosition(cc.v2(nextX,nextY));

        // this.setRotaion(); 设置角度，此处不需要

        // 设置指标角度
        this.setPointRotaion();
    }

    setScaleX(x) {
        this.lastDirX = this.stick.dir.x;
        let playerUI:cc.Node = this.node.getChildByName("playerUI");
        playerUI.scaleX = x;
    }

    // 检查生命恢复,每秒一次
    checkHpRecovery() {
        if(this.currTime - 1000 > this.lastRecoveryHpTime) {
            this.lastRecoveryHpTime = this.currTime;
            PlayerFightPropCtrl.getInstance().execRecoveryCurrHp(PlayerFightPropCtrl.getInstance().getHpRecovery(),1,false);
            // 重新绘制血条
            this.resetBoold();  
        }
    }

    // 设置角度
    setRotaion() {
        
        var r: number = Math.atan2(this.stick.dir.y,this.stick.dir.x); // 角度
        var degree: number = r * 180 / Math.PI;

        degree = 360 - degree;
        degree = degree - (-90);

        this.node.rotation = degree;
    }

    // 设置指标角度
    setPointRotaion() {
        
        var r: number = Math.atan2(this.stick.dir.y,this.stick.dir.x); // 角度
        var degree: number = r * 180 / Math.PI;

        let pos = MathUtil.getXyToZero(90,degree);
        this.point.setPosition(cc.v2(pos[0],pos[1]));

        degree = 360 - degree;
        degree = degree - (-270);

        // this.point.rotation = degree;
        this.point.angle = -degree;
    }

    /**
     * 增加经验
     * @param expNum 经验值
     */
    addExp(expNum:number) {
        if(expNum <= 0) {
            return;
        }

        this.exp += expNum;

        // 是否足够升级，临时处理升级经验
        if(this.exp >= this.level * 3) {
            this.levelUp();
        }

        // 绘制经验条
        this.resetExpProcess();
    }

    // 绘制经验条
    resetExpProcess() {
        let per = this.exp / (this.level * 3);
        this.expProgress.progress = per;
    }

    /**
     * 玩家升级
     */
    levelUp() {
        this.level += 1;

        // 经验清空
        this.exp = 0;

        // 绘制阶级
        this.resetLevelLabel();

        // 玩家角色等级并且重新计算玩家角色等级提供的属性加持
        PlayerFightPropCtrl.getInstance().setGeneralLevel(this.level);

        // 通知主节点玩家升级
        let gameMain:GameMain = this.node.parent.getComponent(GameMain);
        if(gameMain) {
            gameMain.playerLevelUp(this.level);
        }

        if(this.petId != null) {
            // 通知伙伴技能更新
            PetSkillCtrl.getInstance().getPetSkill(this.petId,this.level);
        }
    }

    resetLevelLabel() {
        this.levelLabel.string = "LV" + this.level;
    }

    // 碰撞到掉落物
    onCollisionEnter(other, self) {
        let drop:ExpDrop = other.node.getComponent(ExpDrop);
        if(drop) {
            drop.bePacking(self.node);
        }
    }

    // 初始化角色相关信息
    initPlayerGeneral() {
        // 当前使用的角色
        let generalId = PlayerCacheCtrl.getInstance().getPlayerUseGeneral();

        let general:GeneralBasic = GeneralConfig.getConfigById(generalId);

        SkillCtrl.getInstance().getSkill(general.initSkillType,general.initSkillLevel);

        let sprite:cc.Sprite = this.node.getChildByName("playerUI").getComponent(cc.Sprite);
        SpriteUtil._addSpritePic(sprite,general.picRes);

        
        let ani:cc.Animation = this.node.getChildByName("playerUI").getComponent(cc.Animation);

        this.setAnimation(ani,general.animationRes.run,"run");

        // ani.play("run" + general.id);
    }

    // 初始化玩家上阵伙伴信息
    initPlayerPet() {
        let petId = PlayerCacheCtrl.getInstance().getPlayerUsePet();
        let playerPet = PlayerCacheCtrl.getInstance().getPlayerPetById(petId);
        if(playerPet == null || CommonConfig.USE_STATUS.UNUSED ==  playerPet.useStatus) {
            return;
        }
        this.petId = petId;
        let petConfig:PetBasic = PetConfig.getConfigById(petId);
        let pet = cc.instantiate(this.petPrefab);
        let petPic = pet.getComponent(cc.Sprite);
        SpriteUtil._addSpritePic(petPic,petConfig.picRes.uri);

        // 伙伴飞行动画
        let flyAniAddress = petConfig.animationRes.fly;
        let ani:cc.Animation = pet.getComponent(cc.Animation);
        this.setAnimation(ani,flyAniAddress,"fly");

        pet.setPosition(cc.v2(80,60));
        this.node.addChild(pet);
        pet.active = true;

        // 初始化伙伴技能控制器
        PetSkillCtrl.getInstance().getPetSkill(petId,playerPet.level);
    }

    // 设置动画并播放
    async setAnimation(ani,aniClipAddress,clipName) {
        let animationClip = await AnimationManger.getInstance().getAnimationClipsByName(ani,aniClipAddress);
        ani._clips = [];
        ani.addClip(animationClip);
        ani.play(clipName);
    }

    // 以下为测试方法

    // 测试获得技能
    testGetSkill() {
        SkillCtrl.getInstance().getSkill(1,1);
    }

}
