import Monster from "../../monster/Monster";
import MathUtil from "../../utils/MathUtil";
import Player from "../Player";
import BasePetSkill from "./BasePetSkill";

const {ccclass, property} = cc._decorator;

@ccclass
export default class RangeFirePetSkill extends BasePetSkill {


    start () {

    }

    // update (dt) {}

    move(dt: any) {
        let currPos:cc.Vec2 = this.node.getPosition();

        var vx: number = this.speed * this.dirX * dt;
        var vy: number = this.speed * this.dirY * dt;


        let nextX = currPos.x += vx;
        let nextY = currPos.y += vy;
        this.node.setPosition(cc.v2(nextX,nextY));
    }

    onCollisionStay(other, self) {
        let monster:Monster = other.node.getComponent(Monster);    
        if(monster) {
            // 怪物已死亡
            if(!monster.isAlive) {
                return;
            }
            // 如果该怪物在允许被攻击间隔内就不做处理
            if(this.atkMonsterInfo[monster.id] != null && this.atkMonsterInfo[monster.id].time+ this.atkIntervalTime > this.currTime) {
                return;
            }
            if(this.atkMonsterInfo[monster.id] == null) {
                this.atkMonsterInfo[monster.id] = {
                    time: 0,
                    num: 0
                }
            }
            this.atkMonsterInfo[monster.id].time = this.currTime; // 攻击时间
            this.atkMonsterInfo[monster.id].num += 1; // 攻击次数
            monster.beHit(this.atk);
        }
    }

}
