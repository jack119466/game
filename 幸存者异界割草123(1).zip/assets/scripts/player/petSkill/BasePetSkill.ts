const {ccclass, property} = cc._decorator;

@ccclass
export default class BasePetSkill extends cc.Component {

    public durationTime:number = 0;

    public atkIntervalTime:number = 0;

    public currTime:number = 0;

    public atk:number = 0;

    public dirX:number = 0;

    public dirY:number = 0;

    public speed:number = 0;

    public atkMonsterInfo = {

    }

    // onLoad () {}

    /**
     * 初始化
     */
    init(skillConfig:any) {
        // 初始化技能属性
        this.initProp(skillConfig);
    }

    /**
     * 属性初始化
     */
    initProp(skillConfig:any) {
        this.atk = skillConfig.atk;
        this.durationTime = skillConfig.durationTime;
        this.atkIntervalTime = skillConfig.atkIntervalTime;
        this.dirX = skillConfig.dirX;
        this.dirY = skillConfig.dirY;
        this.speed = skillConfig.speed;
    }
    
    start () {

    }

    update (dt) {
        this.currTime += (dt * 1000);

        if(this.currTime > this.durationTime) {
            this.node.destroy();
            return;
        }

        this.move(dt);
    }

    // 移动
    move(dt) {
        
    }
}
