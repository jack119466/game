// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import CacheUtil from "../cache/CacheUtil";
import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import CacheKey from "../config/CacheKey";
import ChapterConfig, { ChapterBasic } from "../config/ChapterConfig";
import DropConfig from "../config/DropConfig";
import ItemConfig from "../config/ItemConfig";
import MonsterConfig from "../config/MonsterConfig";
import PetConfig from "../config/PetConfig";
import RefreshConfig from "../config/RefreshConfig";
import SceneKey from "../config/SecenKey";
import SkillConfig from "../config/SkillConfig";
import BaseDrop from "../drop/BaseDrop";
import ExpDrop from "../drop/ExpDrop";
import TipCtrl from "../index/TipCtrl";
import AnimationManger from "../manager/AnimationManager";
import AudioManager from "../manager/AudioManager";
import ChooseSkillCtrl from "../manager/ChooseSkillCtrl";
import DropCtrl from "../manager/DropCtrl";
import LabelCtrl from "../manager/LabelCtrl";
import MapManager from "../manager/MapManager";
import MonsterCtrl from "../manager/MonsterCtrl";
import ObjectManager from "../manager/ObjectManager";
import PetSkillCtrl from "../manager/PetSkillCtrl";
import PlayerFightPropCtrl from "../manager/PlayerFightPropCtrl";
import SdkCtrl from "../manager/SdkCtrl";
import SkillCtrl from "../manager/SkillCtrl";
import SpriteManager from "../manager/SpriteManager";
import Monster from "../monster/Monster";
import BasePetSkill from "../player/petSkill/BasePetSkill";
import RangeFirePetSkill from "../player/petSkill/RangeFirePetSkill";
import Player from "../player/Player";
import AmuletSkill from "../player/skill/AmuletSkill";
import BaseSkill from "../player/skill/BaseSkill";
import BianZiSkill from "../player/skill/BianZiSkill";
import FeiDaoSkill from "../player/skill/FeiDaoSkill";
import LongJuanFengSkill from "../player/skill/LongJuanFengSkill";
import MoZhuaSkill from "../player/skill/MoZhuaSkill";
import QiGongSkill from "../player/skill/QiGongSkill";
import QuanQuanSkill from "../player/skill/QuanQuanSkill";
import PlayerFightProp from "../prop/PlayerFightProp";
import MathUtil from "../utils/MathUtil";
import PositionUtil from "../utils/PositionUtil";
import RandomUtil from "../utils/RandomUtil";
import SpriteUtil from "../utils/SpriteUtil";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameMain extends cc.Component {
    @property(cc.Prefab)
    mapPrefab: cc.Prefab = null; // 地图预制体

    @property(cc.Node)
    map_center: cc.Node = null; // 地图-中间
    @property(cc.Node)
    map_left_top: cc.Node = null; // 地图-左上
    @property(cc.Node)
    map_right_top: cc.Node = null; // 地图-右上
    @property(cc.Node)
    map_top: cc.Node = null; // 地图-上方
    @property(cc.Node)
    map_right: cc.Node = null; // 地图-右
    @property(cc.Node)
    map_left: cc.Node = null; // 地图-左
    @property(cc.Node)
    map_left_botoon: cc.Node = null; // 地图-左下
    @property(cc.Node)
    map_botton: cc.Node = null; // 地图-下方
    @property(cc.Node)
    map_right_botton: cc.Node = null; // 地图-右下方

    @property(cc.Prefab)
    feiDaoPrefab: cc.Prefab = null; // 飞刀技能预制体
    @property(cc.Prefab)
    quanQuanPrefab: cc.Prefab = null; // 杀戮领域技能预制体
    @property(cc.Prefab)
    bianZiPrefab: cc.Prefab = null; // 风咒技能预制体
    @property(cc.Prefab)
    amuletPrefab: cc.Prefab = null; // 环绕物技能预制体
    @property(cc.Prefab)
    longJuanFengPrefab: cc.Prefab = null; // 龙卷风技能预制体
    @property(cc.Prefab)
    moZhuaPrefab: cc.Prefab = null; // 魔爪技能预制体
    @property(cc.Prefab)
    qiGongPrefab: cc.Prefab = null; // 气功技能预制体
    @property(cc.Prefab)
    tianLeiPrefab: cc.Prefab = null; // 天雷技能预制体
    @property(cc.Prefab)
    daoDangPrefab: cc.Prefab = null; // 导弹技能预制体

    @property(cc.Prefab)
    petRangeFireSkillPrefab = null; // 伙伴范围火焰技能预制体
    
    @property(cc.Prefab)
    expPrefab:cc.Prefab = null; // 掉落物-经验 预制体

    @property(cc.Prefab)
    damagePrefab:cc.Prefab = null; // 伤害文本 预制体

    @property(cc.Node)
    mapParentNode: cc.Node = null;// 地图父节点

    @property(cc.Node)
    skillNode: cc.Node = null; // 技能节点
    @property(cc.Node)
    playerNode: cc.Node = null; // 玩家节点
    @property(cc.Node)
    playerDieTipNode: cc.Node = null; // 玩家死亡提示
    @property(cc.Node)
    settlementNode: cc.Node = null; // 结算界面
    @property(cc.Label)
    useTimeContent: cc.Label = null; // 结算-用时
    @property(cc.Label)
    killContent: cc.Label = null; // 结算-用时
    @property(cc.Label)
    gainGoldContent: cc.Label = null; // 结算-获得金币
    @property(cc.Label)
    gainShouJingContent: cc.Label = null; // 结算-获得兽晶

    @property(cc.Node)
    chooseSkillNode: cc.Node = null; // 技能选择节点

    @property(cc.Label)
    roomTimeLabel: cc.Label = null; // 房间时间

    @property(cc.Label)
    killLabel: cc.Label = null; // 击杀数量

    @property(cc.Node)
    pauseNode: cc.Node = null; // 暂停界面节点

    @property(cc.Node)
    descNode: cc.Node = null; // 提示界面节点

    @property(cc.Button)
    reviveButton: cc.Button = null; // 复活按钮

    @property(cc.Label)
    reviveButtonLabel: cc.Label = null; // 复活按钮提示

    /**
     * 战斗属性
     */
    @property(cc.Label)
    hpLabel: cc.Label = null; // 生命
    @property(cc.Label)
    hpRecoveryLabel: cc.Label = null; // 恢复
    @property(cc.Label)
    defLabel: cc.Label = null; // 防御
    @property(cc.Label)
    atkLabel: cc.Label = null; // 攻击
    @property(cc.Label)
    speedLabel: cc.Label = null; // 速度
    @property(cc.Label)
    gainRangeRateLabel: cc.Label = null; // 拾取范围

    private mapManager: MapManager = null; // 地图管理
    
    private monsterCtrl: MonsterCtrl = null; // 怪物管理

    private skillCtrl: SkillCtrl = null; // 技能管理

    private petSkillCtrl: PetSkillCtrl = null; // 伙伴技能管理

    private dropCtrl: DropCtrl = null; // 掉落管理

    private labelCtrl: LabelCtrl = null; // 文本管理

    private nowTime: number = 0; // 当前时间,毫秒时间戳

    private roomTime: number = 0; // 当前房间时间,从0毫秒开始

    private roomCreateTime: number = 0; // 房间创建时间

    private killNum: number = 0; // 击杀数量

    private gameOver: boolean = false; // 游戏结束 

    private isPause: boolean = false; // 游戏暂停中 

    private lastPlayerDir: cc.Vec2 = cc.v2(0,-1); // 角色上一次朝向,默认朝向下方

    private chapterConfig:ChapterBasic = null; // 关卡配置

    private gainItem = {}; // 获得物品

    private monsterInfos = {}; // 怪物信息

    private reviveCount = 0; // 剩余复活次数

    private nearMonsterDir = {
        x:0,y:-1
    }; // 最近怪物的方向

    onLoad() {
        // 加载配置
        MonsterConfig.loadConfigMap();
        RefreshConfig.loadConfigMap();
        DropConfig.loadConfigMap();
        SkillConfig.loadConfigMap();

        // 初始化房间时间
        this.mapManager = MapManager.getInstance();
        this.roomCreateTime = new Date().getTime();
        this.skillCtrl = SkillCtrl.getInstance();
        this.petSkillCtrl = PetSkillCtrl.getInstance();
        this.dropCtrl = DropCtrl.getInstance();
        this.labelCtrl = LabelCtrl.getInstance();
        this.gainItem = {};
        this.reviveCount = 2; // 两次复活机会
        
        cc.log("战斗场景-主管理器onLoad()..");

        // 加载关卡配置
        this.loadChapterConfig();

        // 加载怪物刷新配置
        this.loadRefreshMonster();
    }

    start () {

    }

    update (dt) {
        if(this.gameOver) {
            return;
        }

        // 玩家已死亡
        if(!this.playerNode.getComponent(Player).isAlive) {
            return;
        }

        // 检查玩家朝向
        if(this.playerNode.getComponent(Player).currDir != null && (this.playerNode.getComponent(Player).currDir.x != 0 || this.playerNode.getComponent(Player).currDir.y != 0) ) {
            this.lastPlayerDir = this.playerNode.getComponent(Player).currDir;
        }

        // 检查是否生成地图
        this.checkMoveMap();

        this.nowTime = new Date().getTime();
        this.roomTime += dt;

        // 检查BOSS
        this.checkBoss();

        // 检查怪物
        this.monsterCtrl.update(dt);
        this.checkMonster();

        // 检查技能
        this.skillCtrl.update(dt);
        this.petSkillCtrl.update(dt);
        if(this.roomTime > 1) { // 一秒后开始检查
            this.checkSkill();
            this.checkPetSkill();
        }

        // 检查掉落
        this.checkDrop();

        // 检查文本生成
        this.checkLabel();

        // 检查房间时间
        this.resetRoomTimeLabel();
    }

    /**
     * 加载关卡配置
     */
    loadChapterConfig() {
        let fightChapter = CacheUtil.getInstance().get(CacheKey.FIGHT_CHAPTER);
        this.chapterConfig = ChapterConfig.getConfigById(fightChapter);

        cc.log("当前关卡等级：",fightChapter);
        
        // 修改地图图片
        this.loadMapPic();

        // 移除记录的挑战关卡
        CacheUtil.getInstance().remove(CacheKey.FIGHT_CHAPTER);
    }

    /**
     * 修改地图图片
     */
    async loadMapPic() {
        let mapPic = await SpriteManager.getInstance().getSpriteFrame(this.chapterConfig.pic);
        this.map_center.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_left.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_right.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_top.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_botton.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_left_top.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_right_top.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_left_botoon.getComponent(cc.Sprite).spriteFrame = mapPic;
        this.map_right_botton.getComponent(cc.Sprite).spriteFrame = mapPic;
    }

    /**
     * 加载怪物刷新配置
     */
    loadRefreshMonster() {
        this.monsterCtrl = MonsterCtrl.getInstance();
        this.monsterCtrl.initMonsterRefresh(this.chapterConfig.refresh,this.chapterConfig.monsterParam);
    }


    /**
     * 广告获得所有能力
     */
    adGetSkill() {
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            this.chooseSkill(null,1);
            this.chooseSkill(null,2);
            this.chooseSkill(null,3);
        })
    }

    /**
     * 检查地图移动
     */
    checkMoveMap() {
        let playerX = this.playerNode.x;
        let playerY = this.playerNode.y;
        if(playerX < this.map_left.x + (this.map_center.width / 2)) {
            this.moveMap(-this.map_center.width,0);
        }else if(playerX > this.map_right.x - (this.map_center.width / 2)) {
            this.moveMap(this.map_center.width,0);
        }

        if(playerY < this.map_botton.y + (this.map_center.height / 2)) {
            this.moveMap(0,-this.map_center.height);
        }else if(playerY > this.map_top.y - (this.map_center.height / 2)) {
            this.moveMap(0,this.map_center.height);
        }
    }

    /**
     * 移动地图
     * @param x 
     * @param y 
     */
    moveMap(x,y) {
        this.map_center.x += x;
        this.map_center.y += y;
        
        this.map_top.x += x;
        this.map_top.y += y;
        
        this.map_botton.x += x;
        this.map_botton.y += y;
        
        this.map_left.x += x;
        this.map_left.y += y;
        
        this.map_right.x += x;
        this.map_right.y += y;
        
        this.map_left_top.x += x;
        this.map_left_top.y += y;
        
        this.map_right_top.x += x;
        this.map_right_top.y += y;
        
        this.map_left_botoon.x += x;
        this.map_left_botoon.y += y;
        
        this.map_right_botton.x += x;
        this.map_right_botton.y += y;
    }

    async setSprite(container,name) {
        await SpriteManager.getInstance().setSpriteFrameByName(container,name);
    }

    // 检查怪物
    checkMonster() {
        let genMonsterList = this.monsterCtrl.getGenMonsterList();
        if(genMonsterList.length <= 0) {
            return;
        }

        for(let i = 0; i < genMonsterList.length; i++) {
            let monsterConfig = genMonsterList[i];
            this.addMonster(monsterConfig);
        }
    }

    // 检查boss
    checkBoss() {
        let boss = this.monsterCtrl.getGenBoss();
        if(!boss) {
            return;
        }
        this.addMonster(boss);
    }

    //生成怪物
    async addMonster(monsterConfig:any) {
        // 创建怪物对象
        let prefab:cc.Prefab = await ObjectManager.getInstance().getObjectPrefab(monsterConfig.ui.prefab);

        let monster = cc.instantiate(prefab);

        let sprite = monster.getComponent(cc.Sprite);
        this.setSprite(sprite,monsterConfig.ui.picRes);

        let animation = monster.getComponent(cc.Animation);
        this.setAnimation(animation,monsterConfig.ui.animationRes.walk,"walk");

        // 初始化怪物属性
        monster.getComponent(Monster).init(monsterConfig.id,monsterConfig,this.playerNode);

        // 节点大小
        monster.width = monsterConfig.ui.width;
        monster.height = monsterConfig.ui.height;

        // 刚体类型 1-BOX 2-Circle
        if(monsterConfig.ui.colliderType == 1) {
            monster.getComponent(cc.BoxCollider).size.width = monsterConfig.ui.width; 
            monster.getComponent(cc.BoxCollider).size.height = monsterConfig.ui.height; 
        }else if(monsterConfig.ui.colliderType == 2) {
            monster.getComponent(cc.CircleCollider).radius = monsterConfig.ui.width / 2;
        }else {
            return;
        }

        // 生成初始位置
        let position = this.monsterCtrl.getInitPosition(this.playerNode.getPosition().x,this.playerNode.getPosition().y,monsterConfig.type);
        monster.position = position;

        this.node.addChild(monster); // 添加为当前节点的子节点

        monsterConfig.node = monster;
        this.addMonsterInfo(monsterConfig);

        monster.active = true;
    }

    // 设置动画并播放
    async setAnimation(ani,aniClipAddress,clipName) {
        let animationClip = await AnimationManger.getInstance().getAnimationClipsByName(ani,aniClipAddress);
        ani._clips = [];
        ani.addClip(animationClip);
        ani.play(clipName);
    }

    // 检查技能释放
    checkSkill() {
        let genSkillList = this.skillCtrl.getGenSkill();
        if(genSkillList.length > 0) {
            for(let i = 0; i < genSkillList.length; i++) {
                this.createSkill(genSkillList[i]);
            }
        }
    }

    
    // 创建技能
    async createSkill(skillInfo:any) {
        // 生成数量
        let num = skillInfo.num;

        // 根据数量获取技能间隔
        let intervalTime = skillInfo.intervalTime;

        for(let i = 1; i <= num; i++) {
            this.scheduleOnce(() => {
                this.createSkillNode(skillInfo,i - 1);
            },(i - 1) * intervalTime / 1000);
        }
        
    }

    /**
     * 创建技能节点
     * @param skillInfo 技能信息
     * @param index 同一批技能中索引
     * @returns 
     */
    createSkillNode(skillInfo:any,index:number) {
        // 计算横向攻击方向与初始纵向距离
        let initXPos = 0;
        let initYPos = 0;
        let atkXDir = 1;
        let initAngle = 0;
        let rotation = 0;
        let dir = this.lastPlayerDir;
        let dirX = this.lastPlayerDir.x;
        let dirY = this.lastPlayerDir.y;
        // 创建技能节点
        let skill:cc.Node = null;
        let script = BaseSkill;
        if(skillInfo.type == 1) { // 飞刀
            script = FeiDaoSkill;
            skill = cc.instantiate(this.feiDaoPrefab);
        }else if(skillInfo.type == 2) { // 杀戮领域
            script = QuanQuanSkill;
            skill = cc.instantiate(this.quanQuanPrefab);
        }else if(skillInfo.type == 3) { // 风咒
            script = BianZiSkill;
            skill = cc.instantiate(this.bianZiPrefab);
            atkXDir = skillInfo.skillParam.xDir[index];
            initXPos = skillInfo.skillParam.pos[index][0];
            if(initXPos < 0) {
                skill.scaleX = -1;
            }
            initYPos = skillInfo.skillParam.pos[index][1];
        }else if(skillInfo.type == 4) { // 环绕物，根据半径计算初始xy
            script = AmuletSkill;
            skill = cc.instantiate(this.amuletPrefab);
            let initRaduis = skillInfo.skillParam.pos[index][0];
            initAngle = skillInfo.skillParam.pos[index][1];
            let initPos = MathUtil.getXyToZero(initRaduis,initAngle);
            initXPos = initPos[0];
            initYPos = initPos[1];
        }else if(skillInfo.type == 5) { // 龙卷风
            script = LongJuanFengSkill;
            skill = cc.instantiate(this.longJuanFengPrefab);
            dirX = this.nearMonsterDir.x;
            dirY = this.nearMonsterDir.y;
        }else if(skillInfo.type == 6) { // 魔爪
            script = MoZhuaSkill;
            skill = cc.instantiate(this.moZhuaPrefab);
            let monsterPos = this.getRandomMonsterPosition();
            initXPos = monsterPos.x;
            initYPos = monsterPos.y;
        }else if(skillInfo.type == 7) { // 气功
            script = FeiDaoSkill;
            skill = cc.instantiate(this.qiGongPrefab);
            rotation = 50;
        }else if(skillInfo.type == 8) { // 天雷
            script = MoZhuaSkill;
            skill = cc.instantiate(this.tianLeiPrefab);
            let monsterPos = this.getRandomMonsterPosition();
            initXPos = monsterPos.x;
            initYPos = monsterPos.y;
        }else if(skillInfo.type == 9) { // 导弹
            script = FeiDaoSkill;
            skill = cc.instantiate(this.daoDangPrefab);
            dirX = this.nearMonsterDir.x;
            dirY = this.nearMonsterDir.y;
        }

        // 初始化技能属性
        let initSkillConfig = {
            atk: skillInfo.atk + PlayerFightPropCtrl.getInstance().fightProp.atk,
            passNum: skillInfo.passNum,
            speed: skillInfo.speed,
            durationTime: skillInfo.durationTime,
            dir: dir,
            dirX: dirX,
            dirY: dirY,
            atkIntervalTime: skillInfo.atkIntervalTime,
            sameAtkNum: skillInfo.sameAtkNum,
            atkXDir: atkXDir,
            initAngle:initAngle
        }
        skill.getComponent(script).init(initSkillConfig);
        // 编辑技能节点大小与刚体大小
        skill.width = skillInfo.atkRange.w;
        skill.height = skillInfo.atkRange.h;
        // 刚体类型 1-BOX 2-Circle
        if(skillInfo.atkRange.type == 1) {
            skill.getComponent(cc.BoxCollider).size.width = skillInfo.atkRange.w; 
            skill.getComponent(cc.BoxCollider).size.height = skillInfo.atkRange.h; 
        }else if(skillInfo.atkRange.type == 2) {
            skill.getComponent(cc.CircleCollider).radius = skillInfo.atkRange.w / 2;
        }else {
            return;
        }
        // 初始位置为技能中心点位置
        let initPos: cc.Vec2 = this.skillNode.getPosition();
        if(skillInfo.parentType == 1) {
            initPos = this.playerNode.getPosition();
            this.node.addChild(skill);
        }else if(skillInfo.parentType == 2) {
            this.skillNode.addChild(skill);
        }else {
            skill.destroy();
            return;
        }
        // XY轴位置预处理
        initPos.x += initXPos;
        initPos.y += initYPos;
        // 是否需要设置初始旋转角度
        if(SkillConfig.ROTATION_TYPE.PLAYER_DIR == SkillConfig.CONFIG[skillInfo.type + ""].rotationType) {
            this.setRotaionByPlayerDir(skill,rotation);
        } 

        skill.setPosition(initPos);
        skill.active = true;
    }

    // 检查伙伴技能释放
    checkPetSkill() {
        let genSkillInfo = this.petSkillCtrl.getGenPetSkill();
        if(genSkillInfo == null) {
            return;
        }
        // AudioManager.getInstance().playerAudio(AudioPathKey.PET_SKILL.DRAGON_SKILL,false);
        let genIntervalTime = genSkillInfo.genIntervalTime;
        for(let i = 0; i < genSkillInfo.num; i++) {
            this.scheduleOnce(() => {
                this.genPetSkill(genSkillInfo);
            },(i - 1) * genIntervalTime / 1000);
            
        }
    }

    /**
     * 生成伙伴技能
     */
    async genPetSkill(genSkillInfo) {
        // let prefabRes = await ObjectManager.getInstance().getObjectPrefab(genSkillInfo.prefab);
        // cc.log("预制体资源：",prefabRes);
        // if(prefabRes == null) {
        //     return;
        // }

        let prefab:cc.Prefab;
        let script = BasePetSkill;
        if(PetConfig.PET_SKILL_TYPE.RANGE_FIRE == genSkillInfo.petId) {
            prefab = this.petRangeFireSkillPrefab;
            script = RangeFirePetSkill;
        }
        let petSkill = cc.instantiate(prefab);

        genSkillInfo.dirX = this.lastPlayerDir.x;
        genSkillInfo.dirY = this.lastPlayerDir.y;
        petSkill.getComponent(script).init(genSkillInfo);

        this.node.addChild(petSkill);
        let initPos = this.playerNode.getPosition();
        // XY轴位置预处理
        initPos.x += 80;
        initPos.y += 50;
        petSkill.setPosition(initPos);
        this.setRotaionByPlayerDir(petSkill,-90); // 跟随玩家角度

        petSkill.active = true;
    }

    // 检查文本生成
    async checkLabel() {
        let genLabelList = this.labelCtrl.getGenLabel();
        if(genLabelList.length == 0) {
            return;
        }

        for(let i = 0;i < genLabelList.length;i++) {
            let data = genLabelList[i];
            let damageNode = cc.instantiate(this.damagePrefab);
            let pos = this.playerNode.getPosition();
            if(data.pos != null) {
                pos = data.pos;
            }
            damageNode.setPosition(pos);
            damageNode.getComponent(cc.Label).string = data.content;
            damageNode.color = data.color;
            this.node.addChild(damageNode);
            damageNode.active = true;
        }

    }

    // 检查掉落
    checkDrop() {
        let genDropList = this.dropCtrl.getGenDrop();
        if(genDropList.length == 0) {
            return;
        }

        this.addDrop(genDropList);
    }
     /**
     * 生成掉落物
     * @param dropList 掉落列表
     */
      async addDrop(dropList) {
        for(let i = 0; i < dropList.length;i++) {
            let drop = dropList[i];

            if(ItemConfig.ITEM_CONST.GOLD == drop.itemId) {
                this.addItem({itemId:drop.itemId,itemCount:drop.num});
                continue;
            }

            let prefab: cc.Prefab = null;
            let script = BaseDrop;
            if(ItemConfig.ITEM_CONST.EXP  == drop.itemId) {
                prefab = this.expPrefab;
                script = ExpDrop;
            }else {
                continue;
            }

            let dropItem = cc.instantiate(prefab);
            dropItem.getComponent(script).init(drop);
            dropItem.setPosition(drop.pos);
            this.node.addChild(dropItem);
            dropItem.active = true;
        }
    }
    
    // 更新房间时间
    resetRoomTimeLabel() {
        let sceonds = Math.floor(this.roomTime);
        let content = "时间：" + sceonds;
        if(this.roomTimeLabel.string == content) {
            return;
        }
        this.roomTimeLabel.string = content;
        this.mixLen = 99999999;
    } 
    
    /**
    * 接收玩家死亡通知
    */
    public playerDie() {
        this.gameOver = true;

        this.playerDieTipNode.active = true;


        if(this.reviveCount == 0) {
            this.reviveButton.node.active = false;
        }else {
            let reviveCountTip = "剩余次数(" + this.reviveCount + ")";
            this.reviveButtonLabel.string = reviveCountTip;
        }


        // 暂停
        cc.director.pause();
    }

    /**
     * 复活
     */
    private revive() {
        if(this.reviveCount == 0) {
            // 无次数,结算
            this.showSettlement();
        }
        this.reviveCount -= 1;

        // 通知恢复生命值
        PlayerFightPropCtrl.getInstance().revive();

        this.gameOver = false;

        this.playerDieTipNode.active = false;

        // 重置玩家死亡状态
        this.playerNode.getComponent(Player).isAlive = true;
        
        // 游戏继续
        cc.director.resume();
    }

     /**
      * 设置技能角度
      * @param skill 技能节点
      * @param initAngle 最终加上角度
      */
     setRotaionByPlayerDir(skill,initAngle) {
        
        var r: number = Math.atan2(this.lastPlayerDir.y,this.lastPlayerDir.x); // 角度
        var degree: number = r * 180 / Math.PI;

        // degree = 360 - degree;
        degree = degree - (-90);

        skill.angle = degree + initAngle;
    }

    /**
     * 接收怪物死亡
     * @param type 怪物类型
     */
     public monsterDie(id:string) {
        if(this.monsterInfos[id] == null) {
            return;
        }
        let monsterInfo = this.monsterInfos[id];

        // 增加击杀数量
        this.killLabel.string = "击杀：" + ++this.killNum;

        if(monsterInfo.type == 3) {
            this.bossDie();
        }

        this.removeMonsterInfo(id);
    }

    /**
     * 怪物距离最近的距离，为了计算出自动攻击的方向
     */
    private mixLen = 99999999;

    /**
     * 怪物报告节点信息
     */
    public monsterNotifyPos(id,node,pos) {
        // 更新怪物节点信息
        this.updateMonsterInfo(id,node);

        // 计算当前玩家节点到怪物位置的距离
        let playerWorldPos: cc.Vec2 = this.node.convertToNodeSpaceAR(this.playerNode.convertToWorldSpaceAR(cc.Vec2.ZERO));
        let monsterLen = PositionUtil.calculationDis(playerWorldPos,pos);
        if(monsterLen < this.mixLen) {
            this.mixLen = monsterLen;
            
            // 计算方向
            let normalizeVec: cc.Vec2 = pos.subtract(playerWorldPos).normalize();
            this.nearMonsterDir.x = normalizeVec.x; // cos
            this.nearMonsterDir.y = normalizeVec.y; // sin
        }
    }

    public addMonsterInfo(monsterInfo) {
        this.monsterInfos[monsterInfo.id] = monsterInfo;
    }

    public getRandomMonsterPosition() {
        if(this.monsterInfos == null || Object.keys(this.monsterInfos).length == 0) {
            return cc.v2(0,-10000);
        }
        let maxLength = Object.keys(this.monsterInfos).length;
        maxLength = maxLength > 100 ? 100 : maxLength; // 避免循环太久
        var index = Math.floor(Math.random() * maxLength + 1) -1; 
        let i = 0;
        for(const key in this.monsterInfos) {
            if(i == index && this.monsterInfos[key] != null) {
                let node:cc.Node = this.monsterInfos[key].node;
                let mosnterPos: cc.Vec2 = this.playerNode.convertToNodeSpaceAR(node.convertToWorldSpaceAR(cc.Vec2.ZERO));
                return mosnterPos;
            }
            i++;
        }
        
        return cc.v2(0,-10000);
    }

    public updateMonsterInfo(id,node) {
        if(this.monsterInfos[id] != null) {
            this.monsterInfos[id].node = node;
        }
    }

    public removeMonsterInfo(monsterId) {
        delete this.monsterInfos[monsterId];
        // this.monsterInfos[monsterId] = null;
    }

    /**
     * 接收玩家升级通知
     */
    public playerLevelUp(level:number) {
        // 获取可以选择的技能
        let canChooseInfos = this.skillCtrl.getChooseSkill(1);
        if(canChooseInfos == null || canChooseInfos.length == 0) {
            return;
        }
        
        // 通知技能选择节点渲染数据并显示
        let showData = {};
        if(canChooseInfos.length > 0) {
            for(let i = 0; i < canChooseInfos.length; i++) {
                let skillInfo = canChooseInfos[i];
                if(i == 0) {
                    showData["skillName1"] = skillInfo.name;
                    showData["skillLevel1"] = skillInfo.level;
                    showData["skillImage1"] = skillInfo.picRes;
                    showData["skillDesc1"] = skillInfo.desc;
                }else if(i == 1) {
                    showData["skillName2"] = skillInfo.name;
                    showData["skillLevel2"] = skillInfo.level;
                    showData["skillImage2"] = skillInfo.picRes;
                    showData["skillDesc2"] = skillInfo.desc;
                }else if(i == 2) {
                    showData["skillName3"] = skillInfo.name;
                    showData["skillLevel3"] = skillInfo.level;
                    showData["skillImage3"] = skillInfo.picRes;
                    showData["skillDesc3"] = skillInfo.desc;
                }
            }
        }

        this.chooseSkillNode.getComponent(ChooseSkillCtrl).show(showData);

        this.isPause = true;
    }

    /**
     * 技能选择
     * @param event 时间
     * @param customEventData 数据
     */
    public chooseSkill(event, customEventData) {

        // 通知技能控制器选择技能
        let item = this.skillCtrl.chooseSkill(customEventData);

        // 记录获得的物品信息
        if(item != null) {
            this.addItem(item);
        }

        // 玩家属性刷新
        this.playerNode.getComponent(Player).flush();

        // 通知关闭
        this.chooseSkillNode.getComponent(ChooseSkillCtrl).hide();
        
        this.isPause = false;
    }

    public addItem(item:any) {
        let oldCount = 0;
        if(this.gainItem[item.itemId + ""] != null) {
            oldCount = this.gainItem[item.itemId + ""];
        }
        this.gainItem[item.itemId + ""] = oldCount + item.itemCount;
    }


    /**
     * BOSS死亡
     */
     public bossDie() {
        this.gameOver = true;

        // 记录通关关卡
        PlayerCacheCtrl.getInstance().editChapter(this.chapterConfig.id);

        this.showSettlement();
    }
    
    // 展示暂停界面
    public showPause() {
        if(!this.playerNode.getComponent(Player).isAlive || this.gameOver || this.isPause) {
            return;
        }
        
        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);

        // 渲染属性
        let playerFightProp:PlayerFightProp = PlayerFightPropCtrl.getInstance().fightProp;

        this.hpLabel.string = playerFightProp.hp + "";
        this.hpRecoveryLabel.string = playerFightProp.hpRecovery + "";
        this.defLabel.string = playerFightProp.def + "";
        this.atkLabel.string = playerFightProp.atk + "";
        this.speedLabel.string = playerFightProp.speed + "";
        this.gainRangeRateLabel.string = playerFightProp.gainRangeRate + "%";

        // 打开节点
        this.pauseNode.active = true;

        // 游戏暂停
        cc.director.pause();
    }

    // 展示介绍界面
    public showDesc() {
        if(!this.playerNode.getComponent(Player).isAlive || this.gameOver || this.isPause) {
            return;
        }

        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);

        
        // 打开节点
        this.descNode.active = true;

        // 游戏暂停
        cc.director.pause();
    }

    /**
     * 展示结算界面
     */
    public showSettlement() {
        this.pauseNode.active = false;
        this.playerDieTipNode.active = false;

        // 增加资源
        for(const key in this.gainItem) {
            PlayerCacheCtrl.getInstance().addPlayerItem(Number(key),this.gainItem[key]);
        }

        // 记录总击杀数量和总存活时间
        this.record();
        
        
        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);

        // 渲染结算界面
        let gainGoldNum = 0;
        let gainShouJingNum = 0;
        if(this.gainItem[ItemConfig.ITEM_CONST.GOLD + ""] != null) {
            gainGoldNum = this.gainItem[ItemConfig.ITEM_CONST.GOLD + ""];
        }else if(this.gainItem[ItemConfig.ITEM_CONST.SHOU_JING + ""] != null) {
            gainShouJingNum = this.gainItem[ItemConfig.ITEM_CONST.SHOU_JING + ""];
        }
        this.gainGoldContent.string = gainGoldNum + ""; 
        this.gainShouJingContent.string = gainShouJingNum + ""; 
        this.useTimeContent.string = Math.floor(this.roomTime) + "秒";
        this.killContent.string = this.killNum + "";
        this.settlementNode.active = true;

        // 暂停
        cc.director.pause();
    }

    /**
     * 广告结算
     */
    public adSettlement() {
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            // 增加资源
            for(const key in this.gainItem) {
                PlayerCacheCtrl.getInstance().addPlayerItem(Number(key),this.gainItem[key]);
            }
            this.closeFight();
        })
    }

    /**
     * 广告复活
     */
    public adRevive() {
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            this.revive();
        })
    }

    public record() {
        // 记录总击杀数量
        if(this.killNum > 0) {
            let killCount = PlayerCacheCtrl.getInstance().getKillCount();
            PlayerCacheCtrl.getInstance().setKillCount(killCount + this.killNum);
        }

        // 记录总存活时间
        if(this.roomTime > 0 && Math.floor(this.roomTime) > 0) {
            let aliveTime = PlayerCacheCtrl.getInstance().getAliveTime();
            PlayerCacheCtrl.getInstance().setAliveTime(aliveTime + Math.floor(this.roomTime));
        }
        
    }

    /**
     * 结束战斗
     */
    public closeFight() {
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
        
        // 返回主页面
        cc.director.loadScene(SceneKey.INDEX);
        
        this.node.destroy();

        // 清空管理
        this.clearCtrl();

        // 游戏继续
        cc.director.resume();

        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);
    }

     /**
     * 继续战斗
     */
    public continueFight() {
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);

        // 隐藏节点
        this.pauseNode.active = false;
        // 隐藏节点
        this.descNode.active = false;

        // 游戏继续
        cc.director.resume();
    }

    /**
     * 清空
     */
    public clearCtrl() {
        MapManager.destroyInstance();
        MonsterCtrl.destroyInstance();
        SkillCtrl.destroyInstance();
        LabelCtrl.destroyInstance();
        DropCtrl.destroyInstance();
        PetSkillCtrl.destroyInstance();
    }
}
