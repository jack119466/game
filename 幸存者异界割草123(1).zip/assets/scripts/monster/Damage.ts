// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

/**
 * 伤害文本
 */
@ccclass
export default class Damage extends cc.Component {

    private currTime = 0;

    onLoad () {
    }

    start () {

    }

    update (dt) {
        this.currTime += dt;

        // 1秒后销毁
        if(this.currTime > 1) {
            this.node.destroy();
            return;
        }

    }
}
