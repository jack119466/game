import GameMain from "../main/GameMain";
import DropCtrl from "../manager/DropCtrl";
import LabelCtrl from "../manager/LabelCtrl";
import Player from "../player/Player";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Monster extends cc.Component {

    private heroNode:cc.Node = null; // 角色节点

    private _canAtk:boolean = true; // 能否造成攻击

    private lastAtkTime:number = null; // 上一次造成攻击时间戳(毫秒)

    private lastBeAtkTime:number = null; // 上一次被攻击时间(毫秒)

    public isAlive:boolean = false; // 是否存活

    private isFreeze:boolean = false; // 是否冰冻

    public id:string = null; // 怪物ID，唯一标识

    private type:number = null; // 怪物类型

    private maxHp:number = null; // 最大血量

    private currHp:number = null; // 当前血量

    private speed:number = null; // 速度

    private atk:number = null; // 攻击力

    private def:number = null; // 防御力

    private skillList = null; // 技能列表

    private atkIntervalTime = null; // 攻击间隔

    private dropIds = null; // 掉落ID列表

    private ui = null;

    onLoad () {
    }

    start () {

    }

    /**
     * 初始化
     * @param id 怪物ID，唯一标识
     * @param monsterConfig 怪物配置
     * 
     */
    init(id:string,monsterConfig,hero:cc.Node) {
        this.id = id;
        this.initProp(monsterConfig);
        this.heroNode = hero;
    }

    /**
     * 初始化属性
     */
    initProp(config:any) {
        this.isAlive = true;
        this.isFreeze = false;
        this.type = config.type;
        this.maxHp = config.hp;
        this.currHp = config.hp;
        this.speed = config.speed;
        this.atk = config.atk;
        this.def = config.def;
        this.skillList = config.def;
        this.atkIntervalTime = config.atkIntervalTime;
        this.dropIds = config.dropIds;
        this.ui = config.ui;

        if(this.ui.isLeft) {
            this.node.scaleX = 1;
        }else {
            this.node.scaleX = -1;
        }
    } 
    
    /**
    * 被攻击
    * @param atkNum 攻击力 
    */
   beHit(atkNum:number) {
       if(atkNum <= 0) {
           return;
       }
       // 至少扣除1HP
       let hp = 1;

       // 伤害值计算： 攻击方的攻击力 - 怪物防御力
       if(atkNum > this.def) {
           hp = atkNum - this.def;
       }

       this.costHp(hp);
   }

    /**
     * 扣血
     * @param hp 扣除血量
     * @param 
     */
    costHp(hp:number) {
        if(!this.isAlive) {
            return;
        }

        if(hp <= 0) {
            return;
        }

        if(hp > this.currHp) {
            hp = this.currHp
        }

        this.currHp = this.currHp - hp;

        // 展示扣血效果
        this.showCostHp(hp);        

        // 死亡
        if(this.currHp == 0) {
            this.isAlive = false;

            // 掉落
            this.calcDrop();

            // 通知主控制器怪物死亡
            this.notifyMonsterDie();

            this.node.destroy();
        }
    }

    /**
     * 通知怪物死亡
     */
    async notifyMonsterDie() {
        let gameMain:GameMain =  this.node.parent.getComponent(GameMain);
        if(gameMain) {
            gameMain.monsterDie(this.id);
        }
    }

    // 通知计算掉落
    calcDrop() {
        DropCtrl.getInstance().calcDrop(this.node.getPosition(),this.dropIds);
    }

    /**
     * 展示扣血效果(飘字)
     * @param hp 扣除血量
     */
    showCostHp(hp:number) {
        // 通知生成伤害文本
        LabelCtrl.getInstance().add(this.node.getPosition(),"-" + hp,cc.Color.WHITE);
    }
    

    update (dt) {
        // 已死亡
        if(!this.isAlive) {
            return;
        }

        // 冰冻中
        if(this.isFreeze) {
            return;
        }

        // 角色已死亡
        if(!this.heroNode.getComponent(Player).isAlive) {
            return;
        }

        // 移动
        this.moveToCenter(dt);

        // 汇报位置
        let gameMain:GameMain =  this.node.parent.getComponent(GameMain);
        if(gameMain) {
            gameMain.monsterNotifyPos(this.id,this.node,this.node.getPosition());
        }
    }

    /**
     * 像中心点移动，也就是角色位置
     */
    moveToCenter(dt) {
        var currPos: cc.Vec2 = this.node.getPosition();
        let targetPos: cc.Vec2 = this.node.parent.convertToNodeSpaceAR(this.heroNode.convertToWorldSpaceAR(cc.Vec2.ZERO));

        // 超出一定数值再旋转
        if(Math.abs(currPos.x - targetPos.x) > 5) {
            // 是否需要翻面,默认左面,即怪物.x > 玩家.x
            let scaleX = this.ui.isLeft ? 1 : -1 ;
            if(currPos.x < targetPos.x) {
                scaleX =  this.ui.isLeft ? -1 : 1;
            }
            this.node.scaleX = scaleX;
        }

        // 移动
        let normalizeVec: cc.Vec2 = targetPos.subtract(currPos).normalize();
        this.node.x += normalizeVec.x * this.speed * dt;
        this.node.y += normalizeVec.y * this.speed * dt;

    }

    onCollisionStay(other, self) {
        let player:Player = other.node.getComponent(Player);    
        if(player && this._canAtk && other.tag == 0) { // tag=0 为玩家受伤区域
            // 玩家已死亡
            if(!player.isAlive) {
                return;
            }
            this._canAtk = false;
            player.beHit(this.atk);
            this.scheduleOnce(() => {
                this._canAtk = true;
            },this.atkIntervalTime / 1000);
        }
    }
        
    onCollisionEnter(other, self) {
    // if (other.node.getComponent(Enemy)) {
    // cc.log("受伤")
    // }
    }
}
