const {ccclass, property} = cc._decorator;
/**
 * 玩家战斗属性
 */
@ccclass
export default class PlayerFightProp {
    atk:number = 0; // 攻击力
    atkRate:number = 0; // 攻击力提升
    def:number = 0; // 防御力
    defRate:number = 0; // 防御力提升
    hp: number = 0; // 最大生命值
    hpRate:number = 0; // 防御力提升
    hpRecovery: number = 0; // 每秒生命恢复
    hpRecoveryRate:number = 0; // 防御力提升
    speed: number = 0; // 移动速度
    speedRate: number = 0; // 移动速度
    atkNum: number = 0; // 攻击数量
    atkPassNum: number = 0; // 穿透数量
    critRate: number = 0; // 暴击
    atkRangeRate: number = 0; // 攻击范围提升
    atkSpeedRate: number = 0; // 弹道速度提升
    durationTimeRate: number = 0; // 持续时间提升
    backRate: number = 0; // 击退提升
    cdRate: number = 0; // 冷却缩减提升
    gainRange: number = 0; // 拾取范围
    gainRangeRate: number = 0; // 拾取范围提升
    gainGoldRate: number = 0; // 金币获取提升
    gainExpRate: number = 0; // 经验获取提升

    /**
     * 初始某些属性
     */
    public initProp() {
        this.speed = 120;
        this.gainRange = 80;
    }
}
