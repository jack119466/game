// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class CacheKey {

    /**
     * 选择的战斗关卡
     */
    public static FIGHT_CHAPTER = "FIGHT_CHAPTER"; 

    /**
     * 创建时间
     */
    public static CREATE_TIME = "CREATE_TIME";

    /**
     * 新手引导
     */
    public static GUIDE = "GUIDE";

    /**
     * 通关关卡
     */
    public static CHAPTER = "CHAPTER";
    
    /**
     * 系统设置
     */
    public static SYS_SETTING = "SYS_SETTING"; 

    /**
     * 阶级
     */
    public static PLAYER_LEVEL = "PLAYER_LEVEL"; 

    /**
     * 玩家经验
     */
    public static PLAYER_EXP = "PLAYER_EXP"; 

    /**
     * 玩家上次获得经验时间
     */
    public static PLAYER_LAST_GAIN_EXP_TIME = "PLAYER_LAST_GAIN_EXP_TIME"; 

    /**
     * 玩家上次获得体力时间
     */
    public static PLAYER_LAST_GAIN_VIGOUR_TIME = "PLAYER_LAST_GAIN_VIGOUR_TIME"; 

    /**
     * 玩家突破失败时间
     */
    public static PLAYER_LEVEL_UP_FAILED_TIME = "PLAYER_LEVEL_UP_FAILED_TIME"; 

    /**
     * 玩家物品
     */
    public static PLAYER_ITEM = "PLAYER_ITEM"; 

    /**
     * 玩家角色
     */
     public static PLAYER_GENERAL = "PLAYER_GENERAL"; 
     
    /**
     * 玩家天赋
     */
     public static PLAYER_GONG = "PLAYER_GONG"; 

     /**
      * 玩家伙伴
      */
      public static PLAYER_PET = "PLAYER_PET"; 

      /**
       * 每日奖励信息
       */
      public static DAILY_REWARD_INFO = "DAILY_REWARD_INFO";

      /**
       * 成就奖励信息
       */
      public static ATTAINMENT_REWARD_INFO = "ATTAINMENT_REWARD_INFO";

      /**
       * 总击杀数量
       */
      public static KILL_COUNT = "KILL_COUNT";

      /**
       * 存活时间
       */
      public static ALIVE_TIME = "ALIVE_TIME";

}
