const {ccclass, property} = cc._decorator;

/**
 * 广告配置
 */
@ccclass
export default class AdvertConfig {


    public static CONFIG = [
        {
            id:10001,
            name:"广告ID",
        },
    ]


    public static CONFIG_MAP = new Map<number,ItemBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取广告配置
     * @param id 广告ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }
}

/**
 * 广告配置
 */
export class ItemBasic {
    id:number = null; // 广告唯一标识
    name:string = null; // 广告名称
}