// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class UiPathKey {

    /**
     * 底部导航栏
     */
    public static NAV_BG = {
        ENABLE:"ui/nav/nav_bg_enable", // 启用
        DISABLED:"ui/nav/nav_bg_disabled" // 禁用
    } 


     /**
     * 天赋等级状态
     */
    public static TALENT_LEVEL_STATUS_BG = {
        ENABLE:"ui/talent/talent_level_status_enable", // 启用
        DISABLED:"ui/talent/talent_level_status_disabled" // 禁用
    } 



    /**
     * 提示信息预制体
     */
    public static TIP_PREFAB = "prefab/tip";
}
