// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { DropBasic } from "./DropConfig";

const {ccclass, property} = cc._decorator;

/**
 * 怪物配置
 */
@ccclass
export default class RefreshConfig {

    public static CONFIG = [
        {
            id:101,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 101,
            maxNum : 80 
        },
        {
            id:102,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 102,
            maxNum : 120 
        },
        {
            id:103,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 103,
            maxNum : 120 
        },
        {
            id:104,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 104,
            maxNum : 100 
        },
        {
            id:105,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 105,
            maxNum : 140 
        },
        {
            id:106,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 106,
            maxNum : 140 
        },
        {
            id:107,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 107,
            maxNum : 120 
        },
        {
            id:108,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 108,
            maxNum : 160 
        },
        {
            id:109,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 109,
            maxNum : 160 
        },
        {
            id:110,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 110,
            maxNum : 140 
        },
        {
            id:111,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 111,
            maxNum : 180 
        },
        {
            id:112,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 112,
            maxNum : 180 
        },
        {
            id:113,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 113,
            maxNum : 160 
        },
        {
            id:114,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 114,
            maxNum : 200 
        },
        {
            id:115,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 115,
            maxNum : 200 
        },
        {
            id:116,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 116,
            maxNum : 180 
        },
        {
            id:117,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 117,
            maxNum : 220 
        },
        {
            id:118,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 118,
            maxNum : 220 
        },
        {
            id:119,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 119,
            maxNum : 80 
        },
        {
            id:120,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 120,
            maxNum : 120 
        },
        {
            id:121,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 121,
            maxNum : 120 
        },
        {
            id:122,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 122,
            maxNum : 80 
        },
        {
            id:123,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 123,
            maxNum : 120 
        },
        {
            id:124,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 124,
            maxNum : 120 
        },
        {
            id:125,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 125,
            maxNum : 80 
        },
        {
            id:126,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 126,
            maxNum : 120 
        },
        {
            id:127,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 127,
            maxNum : 120 
        },
        {
            id:128,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 128,
            maxNum : 80 
        },
        {
            id:129,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 129,
            maxNum : 120 
        },
        {
            id:130,
            firstTime: 5 * 1000,
            refreshInterval : 1000, 
            mosnterId: 130,
            maxNum : 120 
        },
        {
            id:201,
            firstTime: 59 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 201,
            maxNum : 1
        },
        {
            id:202,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 202,
            maxNum : 1
        },
        {
            id:203,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 203,
            maxNum : 1
        },
        {
            id:204,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 204,
            maxNum : 1
        },
        {
            id:205,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 205,
            maxNum : 1
        },
        {
            id:206,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 206,
            maxNum : 1
        },
        {
            id:207,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 207,
            maxNum : 1
        },
        {
            id:208,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 208,
            maxNum : 1
        },
        {
            id:209,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 209,
            maxNum : 1
        },
        {
            id:210,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 210,
            maxNum : 1
        },
        {
            id:211,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 211,
            maxNum : 1
        },
        {
            id:212,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 212,
            maxNum : 1
        },
        {
            id:213,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 213,
            maxNum : 1
        },
        {
            id:214,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 214,
            maxNum : 1
        },
        {
            id:215,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 215,
            maxNum : 1
        },
        {
            id:216,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 216,
            maxNum : 1
        },
        {
            id:217,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 217,
            maxNum : 1
        },
        {
            id:218,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 218,
            maxNum : 1
        },
        {
            id:219,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 219,
            maxNum : 1
        },
        {
            id:220,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 220,
            maxNum : 1
        },
        {
            id:221,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 221,
            maxNum : 1
        },
        {
            id:222,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 222,
            maxNum : 1
        },
        {
            id:223,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 223,
            maxNum : 1
        },
        {
            id:224,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 224,
            maxNum : 1
        },
        {
            id:225,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 225,
            maxNum : 1
        },
        {
            id:226,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 226,
            maxNum : 1
        },
        {
            id:227,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 227,
            maxNum : 1
        },
        {
            id:228,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 228,
            maxNum : 1
        },
        {
            id:229,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 229,
            maxNum : 1
        },
        {
            id:230,
            firstTime: 60 * 1000,
            refreshInterval : 60 * 1000,
            mosnterId: 230,
            maxNum : 1
        },


        
        {
            id:301,
            firstTime: 8 * 60 * 1000,
            refreshInterval : 10 * 60 * 1000,
            mosnterId: 301,
            maxNum : 1
        },
        {
            id:302,
            firstTime: 8 * 60 * 1000,
            refreshInterval : 10 * 60 * 1000,
            mosnterId: 302,
            maxNum : 1
        },
        {
            id:303,
            firstTime: 8 * 60 * 1000,
            refreshInterval : 10 * 60 * 1000,
            mosnterId: 303,
            maxNum : 1
        }
    ]

    public static CONFIG_MAP = new Map<number,RefreshBasic>();

    /**
     * 加载配置
     */
     public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }

    /**
     * 获取刷怪配置
     * @param id 刷新唯一标识
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }
}

/**
 * 刷怪配置
 */
export class RefreshBasic {
    id:number = null; // 刷怪唯一标识
    firstTime:number = null; // 首次刷新时间
    refreshInterval:number = null; // 刷新间隔,毫秒
    mosnterId:number = null; // 怪物ID
    maxNum:number = null; // 最大数量
}