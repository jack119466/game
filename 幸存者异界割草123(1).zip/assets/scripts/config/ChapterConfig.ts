// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

/**
 * 关卡配置
 */
@ccclass
export default class ChapterConfig {

    public static CONFIG = [
        {
            id:1,
            chapter: 1, 
            level: 1,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第一层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "无",
                hpRate: 0,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:2,
            chapter: 1, 
            level: 2,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第二层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+100%",
                hpRate: 100,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:3,
            chapter: 1, 
            level: 3,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第三层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%",
                hpRate: 200,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:4,
            chapter: 1, 
            level: 4,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第四层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+10%",
                hpRate: 200,
                maxNumRate: 10, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:5,
            chapter: 1, 
            level: 5,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第五层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:6,
            chapter: 1, 
            level: 6,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第六层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 100,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:7,
            chapter: 1, 
            level: 7,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第七层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:8,
            chapter: 1, 
            level: 8,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第八层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%\n怪物防御+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 100, 
                speedRate: 0,
            }
        },
        {
            id:9,
            chapter: 1, 
            level: 9,
            name: "新手秘境",
            desc: "新手秘境为每位修士踏上修行之途的起点",
            levelName: "第九层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[101,102,103,104,105,106,107,108,109,110],
                elite: [201,202,203,204,205,206,207,208,209,210],
                boss: [301],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+300%\n怪物数量+30%\n怪物攻击+200%\n怪物防御+200%",
                hpRate: 300,
                maxNumRate: 30, 
                atkRate: 200,
                defRate: 200, 
                speedRate: 0,
            }
        },


        
        {
            id:10,
            chapter: 2, 
            level: 1,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第一层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "无",
                hpRate: 0,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:11,
            chapter: 2, 
            level: 2,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第二层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+100%",
                hpRate: 100,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:12,
            chapter: 2, 
            level: 3,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第三层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%",
                hpRate: 200,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:13,
            chapter: 2, 
            level: 4,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第四层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+10%",
                hpRate: 200,
                maxNumRate: 10, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:14,
            chapter: 2, 
            level: 5,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第五层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:15,
            chapter: 2, 
            level: 6,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第六层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+20%\n怪物数量+20%\n怪物攻击+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 100,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:16,
            chapter: 2, 
            level: 7,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第七层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:17,
            chapter: 2, 
            level: 8,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第八层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%\n怪物防御+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 100, 
                speedRate: 0,
            }
        },
        {
            id:18,
            chapter: 2, 
            level: 9,
            name: "魔窟秘境",
            desc: "魔窟秘境的怪物凶狠无比,请小心应对",
            levelName: "第九层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[111,112,113,114,115,116,117,118,119,120],
                elite: [211,212,213,214,215,216,217,218,219,220],
                boss: [302],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+300%\n怪物数量+30%\n怪物攻击+200%\n怪物防御+200%",
                hpRate: 300,
                maxNumRate: 30, 
                atkRate: 200,
                defRate: 200, 
                speedRate: 0,
            }
        },


        
        {
            id:19,
            chapter: 3, 
            level: 1,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第一层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "无",
                hpRate: 0,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:20,
            chapter: 3, 
            level: 2,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第二层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+100%",
                hpRate: 100,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:21,
            chapter: 3, 
            level: 3,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第三层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%",
                hpRate: 200,
                maxNumRate: 0, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:22,
            chapter: 3, 
            level: 4,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第四层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+10%",
                hpRate: 200,
                maxNumRate: 10, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:23,
            chapter: 3, 
            level: 5,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第五层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 0,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:24,
            chapter: 3, 
            level: 6,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第六层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 100,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:25,
            chapter: 3, 
            level: 7,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第七层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 0, 
                speedRate: 0,
            }
        },
        {
            id:26,
            chapter: 3, 
            level: 8,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第八层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+200%\n怪物数量+20%\n怪物攻击+200%\n怪物防御+100%",
                hpRate: 200,
                maxNumRate: 20, 
                atkRate: 200,
                defRate: 100, 
                speedRate: 0,
            }
        },
        {
            id:27,
            chapter: 3, 
            level: 9,
            name: "深渊秘境",
            desc: "据说很多修士都倒在了深渊秘境",
            levelName: "第九层",
            pic: "ui/map/1",
            unlock: {
                skill:{},
                gong:{},
                function:{},
            },
            refresh:{
                normal:[121,122,123,124,125,126,127,128,129,130],
                elite: [221,222,223,224,225,226,227,228,229,230],
                boss: [303],
                bossArriveTime: 480000
            },
            monsterParam:{
                desc: "怪物血量+300%\n怪物数量+30%\n怪物攻击+200%\n怪物防御+100%",
                hpRate: 300,
                maxNumRate: 30, 
                atkRate: 200,
                defRate: 200, 
                speedRate: 0,
            }
        }
    ]

    public static CONFIG_MAP = new Map<number,ChapterBasic>();

    /**
     * 加载配置
     */
     public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }

    /**
     * 获取关卡配置
     * @param id 关卡ID
     */
    public static getConfigById(id:number) {
        for(let i = 0; i < this.CONFIG.length; i++) {
            if(id == this.CONFIG[i].id) {
                return this.CONFIG[i];
            }
        }
        return null;
    }
}

/**
 * 阶级配置
 */
export class ChapterBasic {
    id:number = null; // 关卡唯一标识
    chapter:number = null; // 关卡等级
    level:number =  null; // 小节等级
    name: string = null; // 关卡名称
    desc: string = null; // 关卡介绍
    levelName:string =  null ; // 关卡小节名
    pic:string = null; // 地图背景图片
    unlock = {
        skill:null, // 解锁技能法宝
        gong:null, // 解锁天赋
        function:null, // 解锁功能
    }; // 解锁
    refresh = {
        normal: null, // 普通怪物
        elite: null, // 精英怪物
        boss: null, // BOSS
        bossArriveTime: null //BOSS来临时间
    }; // 怪物刷新配置
    monsterParam = {
        hpRate:null, // 生命增强百分比
        maxNumRate:null,  // 怪物数量增强百分比
        atkRate:null,  // 攻击力增强百分比
        defRate:null,  // 防御力增强百分比
        speedRate:null,  // 移速增强百分比
    }; // 怪物增强参数

}
