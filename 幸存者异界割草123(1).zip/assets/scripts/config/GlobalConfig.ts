const {ccclass, property} = cc._decorator;
/**
 * 全局配置
 */
@ccclass
export default class GlobalConfig {

    /**
     * 是否为测试环境
     */
    public static IS_TEST:boolean = true;

    /**
     * 兽晶每次合成消耗数量
     */
    public static CONPOSE_SHOU_JING_NUM = 100;

    /**
     * 兽晶每次合成获得伙伴碎片数量
     */
    public static CONPOSE_GAIN_PET_CHIP_NUM = 5;

    /**
     * 体力恢复间隔,毫秒
     */
     public static VIGOUR_RECORVEY_TIME = 300000;

     /**
      * 体力上限值
      */
      public static VIGOUR_MAX_NUM = 35;

      
     /**
      * 进入战斗扣除体力数量
      */
      public static ENTER_FIGHT_COST_VIGOUR_NUM = 5;
}