const {ccclass, property} = cc._decorator;

/**
 * 技能配置
 */
@ccclass
export default class SkillConfig {

    public static LIMIT_TYPE = {
        NO_LIMIT: 0, // 不限制
        LEVEL_LIMIE : 1, // 技能等级上限
        ONLY_LIMIT : 2, // 限制1次
    } // 技能获得限制类型 

    
    public static EXEC_TYPE = {
        NORMAL: 1, // 法宝
        PROP : 2, // 属性
        RES : 3, // 资源
    } // 技能执行类型

    public static ROTATION_TYPE = {
        NONE: 1, // 不变
        PLAYER_DIR: 2,// 玩家朝向
    }

    public static CONFIG = {
        "1":{
            limitType: 1,
            execType:1,
            rotationType:2,
            baseWeight: 2, // 基础附加选举权重
            list:[
                {
                    id: "1_1",
                    atk: 10, 
                    cdTime: 1500,
                    durationTime: 5000,
                    passNum: 1, 
                    num: 1, 
                    type: 1,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:16,
                        h:60,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"御剑", 
                    desc:"获得1把飞剑\n穿透数量：1" ,
                    picRes:"ui/skill/feiDao/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "1_2",
                    atk: 14, 
                    cdTime: 1400, 
                    durationTime: 5000, 
                    passNum: 1, 
                    num: 2, 
                    type: 1, 
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:16,
                        h:60,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"御剑", 
                    desc:"提升伤害\n飞剑数量 +1" ,
                    picRes:"ui/skill/feiDao/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "1_3",
                    atk: 20, 
                    cdTime: 1350, 
                    durationTime: 5000, 
                    passNum: 2, 
                    num: 3, 
                    type: 1, 
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:16,
                        h:60,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:180, 
                    atkIntervalTime:0, 
                    name:"御剑", 
                    desc:"提升伤害\n飞剑数量 +1\n穿透数量 +1" ,
                    picRes:"ui/skill/feiDao/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "1_4",
                    atk: 25, 
                    cdTime: 1350, 
                    durationTime: 5000, 
                    passNum: 2, 
                    num: 4, 
                    type: 1, 
                    parentType: 1,
                    level: 4, 
                    atkRange: {
                        w:16,
                        h:60,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"御剑", 
                    desc:"提升伤害\n飞剑数量 +1" ,
                    picRes:"ui/skill/feiDao/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "1_5",
                    atk: 35,
                    cdTime: 1350, 
                    durationTime: 5000,
                    passNum: 3,
                    num: 4, 
                    type: 1,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:16,
                        h:60,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"御剑", 
                    desc:"提升伤害\n穿透数量 +1" ,
                    picRes:"ui/skill/feiDao/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                // {
                //     id: "1_6",
                //     atk: 30,
                //     cdTime: 1350, 
                //     durationTime: 5000,
                //     passNum: -1,
                //     num: 1, 
                //     type: 1,
                //     parentType: 1, 
                //     level: 6, 
                //     atkRange: {
                //         w:100,
                //         h:300,
                //         type: 1, 
                //     },
                //     speed:400,
                //     intervalTime:150, 
                //     atkIntervalTime:0, 
                //     name:"极·御剑", 
                //     desc:"融合所有剑身\n无限穿透" ,
                //     picRes:"ui/skill/feiDao/1",
                //     sameAtkNum: 0, 
                //     skillParam:{}
                // },
            ]
        },



        "2":{
            limitType:1,
            execType:1,
            rotationType:1,
            baseWeight: 2, 
            list:[
                {
                    id: "2_1",
                    atk: 8, 
                    cdTime: 5000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 1, 
                    type: 2,
                    parentType: 2, 
                    level: 1, 
                    atkRange: {
                        w:180,
                        h:180,
                        type: 2, 
                    },
                    speed:0,
                    intervalTime:0, 
                    atkIntervalTime:1000,
                    name:"杀戮领域", 
                    desc:"获得杀戮领域" ,
                    picRes:"ui/skill/quanQuan/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "2_2",
                    atk: 10, 
                    cdTime: 5000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 1, 
                    type: 2, 
                    parentType: 2, 
                    level: 2, 
                    atkRange: {
                        w:240,
                        h:240,
                        type: 2, 
                    },
                    speed:0,
                    intervalTime:0, 
                    atkIntervalTime:900,
                    name:"杀戮领域", 
                    desc:"提升伤害与范围" ,
                    picRes:"ui/skill/quanQuan/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "2_3",
                    atk: 12, 
                    cdTime: 5000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 1, 
                    type: 2, 
                    parentType: 2, 
                    level: 3, 
                    atkRange: {
                        w:280,
                        h:280,
                        type: 2, 
                    },
                    speed:0,
                    intervalTime:0, 
                    atkIntervalTime:800,
                    name:"杀戮领域", 
                    desc:"提升伤害与范围" ,
                    picRes:"ui/skill/quanQuan/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "2_4",
                    atk: 12, 
                    cdTime: 5000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 1, 
                    type: 2, 
                    parentType: 2, 
                    level: 4, 
                    atkRange: {
                        w:320,
                        h:320,
                        type: 2, 
                    },
                    speed:0,
                    intervalTime:0, 
                    atkIntervalTime:700,
                    name:"杀戮领域", 
                    desc:"提升范围" ,
                    picRes:"ui/skill/quanQuan/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "2_5",
                    atk: 18, 
                    cdTime: 5000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 1, 
                    type: 2, 
                    parentType: 2, 
                    level: 5, 
                    atkRange: {
                        w:360,
                        h:360,
                        type: 2, 
                    },
                    speed:0,
                    intervalTime:0, 
                    atkIntervalTime:500,
                    name:"杀戮领域", 
                    desc:"提升伤害与范围",
                    picRes:"ui/skill/quanQuan/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
            ]
        },


        "3":{
            limitType:1,
            execType:1,
            rotationType:1,
            baseWeight: 2, 
            list:[
                    {
                        id: "3_1",
                        atk: 20, 
                        cdTime: 5000, 
                        durationTime: 300, 
                        passNum: -1, 
                        num: 1, 
                        type: 3, 
                        parentType: 2, 
                        level: 1, 
                        atkRange: {
                            w:100,
                            h:72,
                            type: 1, 
                        },
                        speed:1200,
                        intervalTime:0, 
                        atkIntervalTime:500,
                        name:"风咒", 
                        desc:"获得风咒", 
                        picRes:"ui/skill/bianZi/2",
                        sameAtkNum: 1, 
                        skillParam:{
                            xDir:[1], 
                            pos:[[-75,0]],
                        }, 
                    },
                    {
                        id: "3_2",
                        atk: 30, 
                        cdTime: 4500, 
                        durationTime: 300, 
                        passNum: -1, 
                        num: 2, 
                        type: 3, 
                        parentType: 2, 
                        level: 2, 
                        atkRange: {
                            w:120,
                            h:72,
                            type: 1, 
                        },
                        speed:1200,
                        intervalTime:200, 
                        atkIntervalTime:500,
                        name:"风咒", 
                        desc:"提升伤害与范围\n冷却时间缩减0.5秒\n风咒数量 +1", 
                        picRes:"ui/skill/bianZi/2",
                        sameAtkNum: 1, 
                        skillParam:{
                            xDir:[1,-1], 
                            pos:[[-90,0],[90,0]],
                        }, 
                    },
                    {
                        id: "3_3",
                        atk: 40, 
                        cdTime: 4000, 
                        durationTime: 300, 
                        passNum: -1, 
                        num: 3, 
                        type: 3, 
                        parentType: 2, 
                        level: 3, 
                        atkRange: {
                            w:140,
                            h:72,
                            type: 1, 
                        },
                        speed:1200,
                        intervalTime:180, 
                        atkIntervalTime:500,
                        name:"风咒", 
                        desc:"提升伤害与范围\n冷却时间缩减0.5秒\n风咒数量 +1", 
                        picRes:"ui/skill/bianZi/2",
                        sameAtkNum: 1, 
                        skillParam:{
                            xDir:[1,-1,1], 
                            pos:[[-100,15],[100,0],[-100,-15]],
                        }, 
                    },
                    {
                        id: "3_4",
                        atk: 60, 
                        cdTime: 4000, 
                        durationTime: 300, 
                        passNum: -1, 
                        num: 4, 
                        type: 3, 
                        parentType: 2, 
                        level: 4, 
                        atkRange: {
                            w:180,
                            h:72,
                            type: 1, 
                        },
                        speed:1200,
                        intervalTime:150, 
                        atkIntervalTime:500,
                        name:"风咒", 
                        desc:"提升伤害与范围\n风咒数量 +1", 
                        picRes:"ui/skill/bianZi/2",
                        sameAtkNum: 1, 
                        skillParam:{
                            xDir:[1,-1,1,-1], 
                            pos:[[-120,15],[120,15],[-120,-15],[120,-15]],
                        }, 
                    },
                    {
                        id: "3_5",
                        atk: 80, 
                        cdTime: 3500, 
                        durationTime: 300, 
                        passNum: -1, 
                        num: 5, 
                        type: 3, 
                        parentType: 2, 
                        level: 5, 
                        atkRange: {
                            w:200,
                            h:72,
                            type: 1, 
                        },
                        speed:1200,
                        intervalTime:120, 
                        atkIntervalTime:500,
                        name:"风咒", 
                        desc:"提升伤害与范围\n冷却时间缩减0.5秒\n风咒数量 +1", 
                        picRes:"ui/skill/bianZi/2",
                        sameAtkNum: 1, 
                        skillParam:{
                            xDir:[1,-1,1,-1,1], 
                            pos:[[-130,0],[130,15],[-130,25],[130,-15],[-130,-25]],
                        }, 
                    }
            ]
        },

        "4":{
            limitType: 1,
            execType:1,
            rotationType:1,
            baseWeight: 1, 
            list:[
                {
                    id: "4_1",
                    atk: 10, 
                    cdTime: 14000,
                    durationTime: 8000,
                    passNum: -1, 
                    num: 1, 
                    type: 4,
                    parentType: 2, 
                    level: 1, 
                    atkRange: {
                        w:45,
                        h:45,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:0, 
                    atkIntervalTime:0, 
                    name:"火炎焱", 
                    desc:"获得1朵火焰" ,
                    picRes:"ui/skill/amulet/1",
                    sameAtkNum: 0, 
                    skillParam:{
                        pos:[[100,90]], // x轴 y轴 初始角度
                    }
                },
                {
                    id: "4_2",
                    atk: 15, 
                    cdTime: 14000,
                    durationTime: 8000,
                    passNum: -1, 
                    num: 2, 
                    type: 4,
                    parentType: 2, 
                    level: 2, 
                    atkRange: {
                        w:45,
                        h:45,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:0, 
                    atkIntervalTime:0, 
                    name:"火炎焱", 
                    desc:"提升伤害\n火焰数量 +1" ,
                    picRes:"ui/skill/amulet/1",
                    sameAtkNum: 0, 
                    skillParam:{
                        pos:[[100,90],[100,270]],
                    }
                },
                {
                    id: "4_3",
                    atk: 20, 
                    cdTime: 14000,
                    durationTime: 8000,
                    passNum: -1, 
                    num: 3, 
                    type: 4,
                    parentType: 2, 
                    level: 3, 
                    atkRange: {
                        w:45,
                        h:45,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:0, 
                    atkIntervalTime:0, 
                    name:"火炎焱", 
                    desc:"提升伤害与范围\n火焰数量 +1" ,
                    picRes:"ui/skill/amulet/1",
                    sameAtkNum: 0, 
                    skillParam:{
                        pos:[[120,90],[120,215],[120,325]],
                    }
                },
                {
                    id: "4_4",
                    atk: 25, 
                    cdTime: 13000,
                    durationTime: 8000,
                    passNum: -1, 
                    num: 4, 
                    type: 4,
                    parentType: 2, 
                    level: 4, 
                    atkRange: {
                        w:45,
                        h:45,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:0, 
                    atkIntervalTime:0, 
                    name:"火炎焱", 
                    desc:"提升伤害\n冷却时间缩减 1秒\n火焰数量 +1" ,
                    picRes:"ui/skill/amulet/1",
                    sameAtkNum: 0, 
                    skillParam:{
                        pos:[[120,90],[120,180],[120,270],[120,0]],
                    }
                },
                {
                    id: "4_5",
                    atk: 25, 
                    cdTime: 11000,
                    durationTime: 8000,
                    passNum: -1, 
                    num: 5, 
                    type: 4,
                    parentType: 2, 
                    level: 5, 
                    atkRange: {
                        w:45,
                        h:45,
                        type: 1, 
                    },
                    speed:500,
                    intervalTime:0, 
                    atkIntervalTime:0, 
                    name:"火炎焱", 
                    desc:"提升攻击速度\n冷却时间缩减 2秒\n火焰数量 +1" ,
                    picRes:"ui/skill/amulet/1",
                    sameAtkNum: 0, 
                    skillParam:{
                        pos:[[130,72],[130,144],[130,216],[130,288],[130,0]],
                    }
                }
            ]
        },

        "5":{
            limitType: 1,
            execType:1,
            rotationType:1,
            baseWeight: 1, // 基础附加选举权重
            list:[
                {
                    id: "5_1",
                    atk: 8, 
                    cdTime: 6000,
                    durationTime: 5000,
                    passNum: -1, 
                    num: 1, 
                    type: 5,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:130,
                        h:136,
                        type: 1, 
                    },
                    speed:240,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"毁灭风暴", 
                    desc:"召唤毁灭风暴" ,
                    picRes:"ui/skill/longJuanFeng/7",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "5_2",
                    atk: 10, 
                    cdTime: 6000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 2, 
                    type: 5, 
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:130,
                        h:136,
                        type: 1, 
                    },
                    speed:240,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"毁灭风暴", 
                    desc:"提升伤害\n风暴数量 +1" ,
                    picRes:"ui/skill/longJuanFeng/7",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "5_3",
                    atk: 15, 
                    cdTime: 6000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 2, 
                    type: 5, 
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:130,
                        h:136,
                        type: 1, 
                    },
                    speed:240,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"毁灭风暴", 
                    desc:"提升伤害\n" ,
                    picRes:"ui/skill/longJuanFeng/7",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "5_4",
                    atk: 20, 
                    cdTime: 6000, 
                    durationTime: 5000, 
                    passNum: -1, 
                    num: 3, 
                    type: 5, 
                    parentType: 1,
                    level: 4, 
                    atkRange: {
                        w:130,
                        h:136,
                        type: 1, 
                    },
                    speed:240,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"毁灭风暴", 
                    desc:"提升伤害\n风暴数量 +1" ,
                    picRes:"ui/skill/longJuanFeng/7",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "5_5",
                    atk: 25,
                    cdTime: 6000, 
                    durationTime: 5000,
                    passNum: -1,
                    num: 3, 
                    type: 5,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:130,
                        h:136,
                        type: 1, 
                    },
                    speed:240,
                    intervalTime:150, 
                    atkIntervalTime:800, 
                    name:"毁灭风暴", 
                    desc:"提升伤害\n" ,
                    picRes:"ui/skill/longJuanFeng/7",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
            ]
        },

        "6":{
            limitType: 1,
            execType:1,
            rotationType:1,
            baseWeight: 1, // 基础附加选举权重
            list:[
                {
                    id: "6_1",
                    atk: 8, 
                    cdTime: 4000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 1, 
                    type: 6,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"地狱之爪", 
                    desc:"召唤地狱之爪" ,
                    picRes:"ui/skill/moZhua/8",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "6_2",
                    atk: 14, 
                    cdTime: 4000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 2, 
                    type: 6,
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"地狱之爪", 
                    desc:"提升伤害\n召唤数量 +1" ,
                    picRes:"ui/skill/moZhua/8",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "6_3",
                    atk: 20, 
                    cdTime: 3500,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 2, 
                    type: 6,
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"地狱之爪", 
                    desc:"提升伤害\n冷却时间缩减0.5秒" ,
                    picRes:"ui/skill/moZhua/8",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "6_4",
                    atk: 26, 
                    cdTime: 3500,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 3, 
                    type: 6,
                    parentType: 1, 
                    level: 4, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"地狱之爪", 
                    desc:"提升伤害\n召唤数量 +1" ,
                    picRes:"ui/skill/moZhua/8",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "6_5",
                    atk: 30, 
                    cdTime: 3000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 3, 
                    type: 6,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"地狱之爪", 
                    desc:"提升伤害\n冷却时间缩减1秒" ,
                    picRes:"ui/skill/moZhua/8",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
            ]
        },
        "7":{
            limitType: 1,
            execType:1,
            rotationType:2,
            baseWeight: 2, // 基础附加选举权重
            list:[
                {
                    id: "7_1",
                    atk: 8, 
                    cdTime: 2000,
                    durationTime: 800,
                    passNum: -1, 
                    num: 1, 
                    type: 7,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:80,
                        h:80,
                        type: 1, 
                    },
                    speed:350,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"斩月剑气", 
                    desc:"挥出斩月剑气" ,
                    picRes:"ui/skill/qiGong/2",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "7_2",
                    atk: 10, 
                    cdTime: 2000, 
                    durationTime: 800, 
                    passNum: -1, 
                    num: 1, 
                    type: 7, 
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:80,
                        h:80,
                        type: 1, 
                    },
                    speed:350,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"斩月剑气", 
                    desc:"提升伤害" ,
                    picRes:"ui/skill/qiGong/2",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "7_3",
                    atk: 15, 
                    cdTime: 2000, 
                    durationTime: 1000, 
                    passNum: -1, 
                    num: 2, 
                    type: 7, 
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:80,
                        h:80,
                        type: 1, 
                    },
                    speed:350,
                    intervalTime:180, 
                    atkIntervalTime:0, 
                    name:"斩月剑气", 
                    desc:"提升伤害与范围\n剑气数量 +1" ,
                    picRes:"ui/skill/qiGong/2",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "7_4",
                    atk: 20, 
                    cdTime: 2000, 
                    durationTime: 1000, 
                    passNum: -1, 
                    num: 3, 
                    type: 7, 
                    parentType: 1,
                    level: 4, 
                    atkRange: {
                        w:80,
                        h:80,
                        type: 1, 
                    },
                    speed:350,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"斩月剑气", 
                    desc:"提升伤害\n剑气数量 +1" ,
                    picRes:"ui/skill/qiGong/2",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "7_5",
                    atk: 25,
                    cdTime: 2000, 
                    durationTime: 1000,
                    passNum: -1,
                    num: 4, 
                    type: 7,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:80,
                        h:80,
                        type: 1, 
                    },
                    speed:350,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"斩月剑气", 
                    desc:"提升伤害\n剑气数量 +1" ,
                    picRes:"ui/skill/qiGong/2",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
            ]
        },
        "8":{
            limitType: 1,
            execType:1,
            rotationType:1,
            baseWeight: 1, // 基础附加选举权重
            list:[
                {
                    id: "8_1",
                    atk: 8, 
                    cdTime: 4000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 1, 
                    type: 8,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"寂灭天雷", 
                    desc:"召唤寂灭天雷" ,
                    picRes:"ui/skill/tianLei/13",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "8_2",
                    atk: 14, 
                    cdTime: 4000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 2, 
                    type: 8,
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"寂灭天雷", 
                    desc:"提升伤害\n召唤数量 +1" ,
                    picRes:"ui/skill/tianLei/13",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "8_3",
                    atk: 20, 
                    cdTime: 3500,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 2, 
                    type: 8,
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"寂灭天雷", 
                    desc:"提升伤害\n冷却时间缩减0.5秒" ,
                    picRes:"ui/skill/tianLei/13",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "8_4",
                    atk: 26, 
                    cdTime: 3500,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 3, 
                    type: 8,
                    parentType: 1, 
                    level: 4, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"寂灭天雷", 
                    desc:"提升伤害\n召唤数量 +1" ,
                    picRes:"ui/skill/tianLei/13",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
                {
                    id: "8_5",
                    atk: 30, 
                    cdTime: 3000,
                    durationTime: 1250,
                    passNum: -1, 
                    num: 3, 
                    type: 8,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:90,
                        h:80,
                        type: 1, 
                    },
                    speed:0,
                    intervalTime:500, 
                    atkIntervalTime:800, 
                    name:"寂灭天雷", 
                    desc:"提升伤害\n冷却时间缩减1秒" ,
                    picRes:"ui/skill/tianLei/13",
                    sameAtkNum: 1, 
                    skillParam:{}
                },
            ]
        },

        "9":{
            limitType: 1,
            execType:1,
            rotationType:2,
            baseWeight: 3, // 基础附加选举权重
            list:[
                {
                    id: "9_1",
                    atk: 10, 
                    cdTime: 1500,
                    durationTime: 5000,
                    passNum: 1, 
                    num: 1, 
                    type: 9,
                    parentType: 1, 
                    level: 1, 
                    atkRange: {
                        w:20,
                        h:20,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"魔法弹", 
                    desc:"获得魔法弹\n穿透数量：1" ,
                    picRes:"ui/skill/daoDang/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "9_2",
                    atk: 14, 
                    cdTime: 1400, 
                    durationTime: 5000, 
                    passNum: 1, 
                    num: 2, 
                    type: 9, 
                    parentType: 1, 
                    level: 2, 
                    atkRange: {
                        w:20,
                        h:20,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:200, 
                    atkIntervalTime:0, 
                    name:"魔法弹", 
                    desc:"提升伤害\n魔法弹数量 +1" ,
                    picRes:"ui/skill/daoDang/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "9_3",
                    atk: 20, 
                    cdTime: 1350, 
                    durationTime: 5000, 
                    passNum: 2, 
                    num: 3, 
                    type: 9, 
                    parentType: 1, 
                    level: 3, 
                    atkRange: {
                        w:20,
                        h:20,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:180, 
                    atkIntervalTime:0, 
                    name:"魔法弹", 
                    desc:"提升伤害\n魔法弹数量 +1\n穿透数量 +1" ,
                    picRes:"ui/skill/daoDang/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "9_4",
                    atk: 25, 
                    cdTime: 1350, 
                    durationTime: 5000, 
                    passNum: 2, 
                    num: 4, 
                    type: 9, 
                    parentType: 1,
                    level: 4, 
                    atkRange: {
                        w:20,
                        h:20,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"魔法弹", 
                    desc:"提升伤害\n魔法弹数量 +1" ,
                    picRes:"ui/skill/daoDang/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
                {
                    id: "9_5",
                    atk: 35,
                    cdTime: 1350, 
                    durationTime: 5000,
                    passNum: 3,
                    num: 4, 
                    type: 9,
                    parentType: 1, 
                    level: 5, 
                    atkRange: {
                        w:20,
                        h:20,
                        type: 1, 
                    },
                    speed:400,
                    intervalTime:150, 
                    atkIntervalTime:0, 
                    name:"魔法弹", 
                    desc:"提升伤害\n穿透数量 +1" ,
                    picRes:"ui/skill/daoDang/1",
                    sameAtkNum: 0, 
                    skillParam:{}
                },
            ]
        },

        // 100-199 为属性技能
        "100" : {
            limitType: 1,
            execType:2,
            rotationType:1,
            baseWeight: 0, 
            list:[
                {
                    id: "100_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 100, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"生命提升", 
                    desc:"生命提升10%", 
                    picRes:"ui/talent/hp",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"hpRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "100_2",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 100, 
                    parentType: null, 
                    level: 2, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"生命提升", 
                    desc:"生命提升\n10%->20%", 
                    picRes:"ui/talent/hp",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"hpRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "100_3",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 100, 
                    parentType: null, 
                    level: 3, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"生命提升", 
                    desc:"生命提升\n20%->35%", 
                    picRes:"ui/talent/hp",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"hpRate",
                        propNum:15,
                        propType:1,
                    }, 
                },
            ]
        },
        "101" : {
            limitType: 1,
            execType:2,
            rotationType:1,
            baseWeight: 0, 
            list:[
                {
                    id: "101_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 101, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"攻击提升", 
                    desc:"攻击提升10%", 
                    picRes:"ui/talent/atk",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"atkRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "101_2",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 101, 
                    parentType: null, 
                    level: 2, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"攻击提升", 
                    desc:"攻击提升\n10%->20%", 
                    picRes:"ui/talent/atk",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"atkRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "101_3",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 101, 
                    parentType: null, 
                    level: 3, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"攻击提升", 
                    desc:"攻击提升\n20%->35%", 
                    picRes:"ui/talent/atk",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"atkRate",
                        propNum:15,
                        propType:1,
                    }, 
                },
            ]
        },
        "102" : {
            limitType: 1,
            execType:2,
            rotationType:1,
            baseWeight: 0, 
            list:[
                {
                    id: "102_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 102, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"防御提升", 
                    desc:"防御提升10%", 
                    picRes:"ui/talent/def",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"defRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "102_2",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 102, 
                    parentType: null, 
                    level: 2, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"防御提升", 
                    desc:"防御提升\n10%->20%", 
                    picRes:"ui/talent/def",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"defRate",
                        propNum:10,
                        propType:2,
                    }, 
                },
                {
                    id: "102_3",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 102, 
                    parentType: null, 
                    level: 3, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"防御提升", 
                    desc:"防御提升\n20->35%", 
                    picRes:"ui/talent/def",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"defRate",
                        propNum:15,
                        propType:1,
                    }, 
                },
            ]
        },
        "103" : {
            limitType: 1,
            execType:2,
            rotationType:1,
            baseWeight: 0, 
            list:[
                {
                    id: "103_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 103, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"速度提升", 
                    desc:"速度提升10%", 
                    picRes:"ui/talent/speed",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"speedRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "103_2",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 103, 
                    parentType: null, 
                    level: 2, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"速度提升", 
                    desc:"速度提升\n10%->20%", 
                    picRes:"ui/talent/speed",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"speedRate",
                        propNum:10,
                        propType:1,
                    }, 
                },
                {
                    id: "103_3",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 103, 
                    parentType: null, 
                    level: 3, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"速度提升", 
                    desc:"速度提升\n20%->35%", 
                    picRes:"ui/talent/speed",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"speedRate",
                        propNum:15,
                        propType:1,
                        
                    }, 
                },
            ]
        },
        "104" : {
            limitType: 1,
            execType:2,
            rotationType:1,
            baseWeight: 1, 
            list:[
                {
                    id: "104_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 104, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"拾取提升", 
                    desc:"拾取范围提升100%", 
                    picRes:"ui/talent/gainRange",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"gainRangeRate",
                        propNum:100,
                        propType:1,
                    }, 
                },
                {
                    id: "104_2",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 104, 
                    parentType: null, 
                    level: 2, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"拾取提升", 
                    desc:"拾取范围提升\n100%->200%", 
                    picRes:"ui/talent/gainRange",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"gainRangeRate",
                        propNum:100,
                        propType:1,
                    }, 
                },
                {
                    id: "104_3",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 104, 
                    parentType: null, 
                    level: 3, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"拾取提升", 
                    desc:"拾取范围提升\n200%->300%", 
                    picRes:"ui/talent/gainRange",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"gainRangeRate",
                        propNum:100,
                        propType:1,
                        
                    }, 
                },
            ]
        },
        "105": {
            limitType: 0,
            execType:2,
            rotationType:1,
            baseWeight: 1, 
            list:[
                {
                    id: "105_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 105, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"生命恢复", 
                    desc:"生命恢复25%", 
                    picRes:"ui/item/recoverBlood3",
                    sameAtkNum: null, 
                    skillParam:{
                        propName:"currHp",
                        propNum:25,
                        propType:2,
                    }
                }
            ]
        },
        // "106": {
        //     limitType: 0,
        //     execType:2,
        //     rotationType:1,
        //     baseWeight: 0, 
        //     list:[
        //         {
        //             id: "106_1",
        //             atk: null, 
        //             cdTime: null, 
        //             durationTime: null, 
        //             passNum: null, 
        //             num: null, 
        //             type: 106, 
        //             parentType: null, 
        //             level: 1, 
        //             atkRange: null,
        //             speed:null,
        //             intervalTime:null, 
        //             atkIntervalTime:null,
        //             name:"大恢复术", 
        //             desc:"生命恢复50%", 
        //             picRes:"ui/item/recoverBlood2",
        //             sameAtkNum: null, 
        //             skillParam:{
        //                 propName:"currHp",
        //                 propNum:50,
        //                 propType:2,
        //             }
        //         }
        //     ]
        // },
        // "107": {
        //     limitType: 0,
        //     execType:2,
        //     rotationType:1,
        //     baseWeight: 0, 
        //     list:[
        //         {
        //             id: "106_1",
        //             atk: null, 
        //             cdTime: null, 
        //             durationTime: null, 
        //             passNum: null, 
        //             num: null, 
        //             type: 106, 
        //             parentType: null, 
        //             level: 1, 
        //             atkRange: null,
        //             speed:null,
        //             intervalTime:null, 
        //             atkIntervalTime:null,
        //             name:"顶级恢复术", 
        //             desc:"生命恢复100%", 
        //             picRes:"ui/item/recoverBlood3",
        //             sameAtkNum: null, 
        //             skillParam:{
        //                 propName:"currHp",
        //                 propNum:100,
        //                 propType:2,
        //             }
        //         }
        //     ]
        // },
        // 200-299 为资源
        "200" :{
            limitType: 0,
            execType:3,
            rotationType:1,
            baseWeight: 2, 
            list:[
                {
                    id: "200_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 200, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"金币", 
                    desc:"获得金币*10", 
                    picRes:"ui/item/gold",
                    sameAtkNum: null, 
                    skillParam:{
                        itemId:10002,
                        itemCount:10
                    }, 
                },
            ]
        },
        "201" :{
            limitType: 0,
            execType:3,
            rotationType:1,
            baseWeight: 0, 
            list:[
                {
                    id: "201_1",
                    atk: null, 
                    cdTime: null, 
                    durationTime: null, 
                    passNum: null, 
                    num: null, 
                    type: 201, 
                    parentType: null, 
                    level: 1, 
                    atkRange: null,
                    speed:null,
                    intervalTime:null, 
                    atkIntervalTime:null,
                    name:"大量金币", 
                    desc:"获得金币*25", 
                    picRes:"ui/item/gold",
                    sameAtkNum: null, 
                    skillParam:{
                        itemId:10002,
                        itemCount:25
                    }, 
                },
            ]
        },
    }

    public static CONFIG_MAP = new Map<string,SkillBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for (const type in SkillConfig.CONFIG) {
            for(let j = 0;j < this.CONFIG[type].list.length;j++) {
                let config = this.CONFIG[type].list[j];
                this.CONFIG_MAP.set(config.id,config);
            }
           
        }
    }

    /**
     * 技能类型的技能列表长度
     * @param type 技能类型
     */
    public static getTypeLength(type:string) {
        if(this.CONFIG[type] == null) {
            return 0;
        }
        return this.CONFIG[type].list.length;
    }

     /**
     * 技能类型的首级名称
     * @param type 技能类型
     */
      public static getTypeName(type:string) {
        if(this.CONFIG[type] == null) {
            return 0;
        }
        return this.CONFIG[type].list[0].name;
    }
    
    /**
     * 获取技能配置
     * @param id 技能ID
     */
    public static getConfigById(id:string) {
        return this.CONFIG_MAP.get(id);
    }

    /**
     * 获取技能配置
     * @param type 类型
     * @param level 等级
     */
    public static getConfigByTypeAndLevel(type:number,level:number) {
        return this.CONFIG_MAP.get(type + "_" + level);
    }
}

/**
 * 技能配置
 */
export class SkillBasic {
    id:string = null; // 技能唯一标识,组成:type_level
    type:number = null; // 技能类型 
    level:number = null; // 技能等级
    name:string = null; // 技能名称
    desc:string = null; // 节能介绍
    picUrl:string = null; // 图片
    atk:number = null; // 攻击力
    cdTime:number = null; // 冷却时间
    durationTime:number = null; //持续时间
    passNum:number = null; // 穿透数量
    num:number = null; // 数量
    parentType:number = null; // 父节点类型 1-地图 2-技能
    speed:number = null; // 速度
    intervalTime:number = null; // 数量不为0时的连续间隔,毫秒
    atkIntervalTime:number = null; // 攻击间隔时间,毫秒
    sameAtkNum:number = null; // 同个对象可造成攻击次数
    atkRange = {
        w : null, // 宽
        h : null, // 高
        type : null,// 刚体类型 1-BOX 2-Circle
    }; // 穿透数量
    skillParam = {
        // xDir : null, // x移动方向
        // pos : null, // 初始xy位置
    }; // 初始参数
}

