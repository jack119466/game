// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

/**
 * 用户等级配置
 */
@ccclass
export default class PlayerLevelConfig {

    public static CONFIG = [
        {
            level:0,
            name:"0",
            atk: 5,
            def: 5,
            hp: 200,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 500, 
            adGain: 1000, 
        },
        {
            level:1,
            name:"1",
            atk: 6,
            def: 6,
            hp: 210,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 1000, 
            adGain: 1000, 
        },
        {
            level:2,
            name:"2",
            atk: 8,
            def: 8,
            hp: 220,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 2000, 
            adGain: 2000, 
        },
        {
            level:3,
            name:"3",
            atk: 10,
            def: 10,
            hp: 230,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 3000, 
            adGain: 3000, 
        },
        {
            level:4,
            name:"4",
            atk: 12,
            def: 12,
            hp: 240,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 4000, 
            adGain: 4000, 
        },
        {
            level:5,
            name:"5",
            atk: 15,
            def: 15,
            hp: 250,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 5000, 
            adGain: 5000, 
        },
        {
            level:6,
            name:"6",
            atk: 18,
            def: 18,
            hp: 260,
            speed: 130,
            hpRecovery: 2,
            levelUpCost: 6000, 
            adGain: 5000, 
        },
        {
            level:7,
            name:"7",
            atk: 21,
            def: 21,
            hp: 270,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 7000, 
            adGain: 5000, 
        },
        {
            level:8,
            name:"8",
            atk: 24,
            def: 24,
            hp: 280,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 8000, 
            adGain: 5000, 
        },
        {
            level:9,
            name:"9",
            atk: 27,
            def: 27,
            hp: 290,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 9000, 
            adGain: 5000, 
        },
        {
            level:10,
            name:"10",
            atk: 30,
            def: 30,
            hp: 300,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 10000, 
            adGain: 5000, 
        },



        {
            level:11,
            name:"11",
            atk: 33,
            def: 33,
            hp: 310,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 11000, 
            adGain: 5500, 
        },
        {
            level:12,
            name:"12",
            atk: 36,
            def: 36,
            hp: 320,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 12000, 
            adGain: 6000, 
        },
        {
            level:13,
            name:"13",
            atk: 39,
            def: 39,
            hp: 330,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 13000, 
            adGain: 6500, 
        },
        {
            level:14,
            name:"14",
            atk: 42,
            def: 42,
            hp: 340,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 14000, 
            adGain: 7000, 
        },
        {
            level:15,
            name:"15",
            atk: 45,
            def: 45,
            hp: 350,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 15000, 
            adGain: 7500, 
        },
        {
            level:16,
            name:"16",
            atk: 48,
            def: 48,
            hp: 360,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 16000, 
            adGain: 8000, 
        },
        {
            level:17,
            name:"17",
            atk: 51,
            def: 51,
            hp: 370,
            speed: 130,
            hpRecovery: 3,
            levelUpCost: 17000, 
            adGain: 8000, 
        },
        {
            level:18,
            name:"18",
            atk: 54,
            def: 54,
            hp: 380,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 18000, 
            adGain: 8000, 
        },
        {
            level:19,
            name:"19",
            atk: 57,
            def: 57,
            hp: 390,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 19000, 
            adGain: 8000, 
        },
        {
            level:20,
            name:"20",
            atk: 60,
            def: 60,
            hp: 400,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 20000, 
            adGain: 8000, 
        },

        
        {
            level:21,
            name:"21",
            atk: 63,
            def: 63,
            hp: 410,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 21000, 
            adGain: 8000, 
        },
        {
            level:22,
            name:"22",
            atk: 66,
            def: 66,
            hp: 420,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 22000, 
            adGain: 8000, 
        },
        {
            level:23,
            name:"23",
            atk: 69,
            def: 69,
            hp: 430,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 23000, 
            adGain: 8000, 
        },
        {
            level:24,
            name:"24",
            atk: 72,
            def: 72,
            hp: 440,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 24000, 
            adGain: 10000, 
        },
        {
            level:25,
            name:"25",
            atk: 75,
            def: 75,
            hp: 450,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 25000, 
            adGain: 10000, 
        },
        {
            level:26,
            name:"26",
            atk: 78,
            def: 78,
            hp: 460,
            speed: 130,
            hpRecovery: 4,
            levelUpCost: 26000, 
            adGain: 10000, 
        },
        {
            level:27,
            name:"27",
            atk: 81,
            def: 81,
            hp: 470,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 27000, 
            adGain: 10000, 
        },
        {
            level:28,
            name:"28",
            atk: 84,
            def: 84,
            hp: 480,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 28000, 
            adGain: 14000, 
        },
        {
            level:29,
            name:"29",
            atk: 87,
            def: 87,
            hp: 500,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 29000, 
            adGain: 14000, 
        },
        {
            level:30,
            name:"30",
            atk: 90,
            def: 90,
            hp: 520,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 30000, 
            adGain: 14000, 
        },

        {
            level:31,
            name:"31",
            atk: 100,
            def: 100,
            hp: 540,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 31000, 
            adGain: 15000, 
        },
        {
            level:32,
            name:"32",
            atk: 110,
            def: 110,
            hp: 550,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 32000, 
            adGain: 15500, 
        },
        {
            level:33,
            name:"33",
            atk: 120,
            def: 120,
            hp: 570,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 33000, 
            adGain: 16000, 
        },
        {
            level:34,
            name:"34",
            atk: 130,
            def: 130,
            hp: 590,
            speed: 130,
            hpRecovery: 5,
            levelUpCost: 34000, 
            adGain: 16500, 
        },
        {
            level:35,
            name:"35",
            atk: 140,
            def: 140,
            hp: 610,
            speed: 130,
            hpRecovery: 6,
            levelUpCost: 35000, 
            adGain: 17000, 
        },
        {
            level:36,
            name:"36",
            atk: 150,
            def: 150,
            hp: 630,
            speed: 130,
            hpRecovery: 6,
            levelUpCost: 36000, 
            adGain: 17500, 
        },
        {
            level:37,
            name:"37",
            atk: 160,
            def: 160,
            hp: 650,
            speed: 130,
            hpRecovery: 6,
            levelUpCost: 37000, 
            adGain: 18000, 
        },
        {
            level:38,
            name:"38",
            atk: 170,
            def: 170,
            hp: 670,
            speed: 130,
            hpRecovery: 6,
            levelUpCost: 38000, 
            adGain: 18500, 
        },
        {
            level:39,
            name:"39",
            atk: 180,
            def: 180,
            hp: 690,
            speed: 130,
            hpRecovery: 6,
            levelUpCost: 39000, 
            adGain: 19000, 
        },
        {
            level:40,
            name:"40",
            atk: 190,
            def: 190,
            hp: 710,
            speed: 130,
            hpRecovery: 7,
            levelUpCost: 40000, 
            adGain: 19500, 
        }
    ]
    public static CONFIG_MAP = new Map<number,PlayerLevelBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.level,config);
        }
    }

    /**
     * 获取玩家境界等级配置
     * @param level 境界等级
     */
    public static getConfigByLevel(level:number) {
        if(level > this.CONFIG.length) {
            return null;
        }

        return this.CONFIG[level];
    }
}

/**
 * 阶级配置
 */
export class PlayerLevelBasic {
    level:number = null; // 等级
    name:string = null; // 等级名称
    atk:number = null; // 攻击力
    def:number = null; // 防御力
    hp: number = null; // 生命值
    hpRecovery: number = null; // 每秒生命恢复
    levelUpCost: number = null; // 升级消耗金币数量
    adGain:number = null; // 广告获得金币数量
}
