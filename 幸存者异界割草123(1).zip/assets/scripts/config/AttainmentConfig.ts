
const {ccclass, property} = cc._decorator;

/**
 * 成就配置
 */
@ccclass
export default class AttainmentConfig {

    /**
     * 成就类型
     */
    public static TYPE_CONST = {
        KILL: 1, // 击杀数量
        ALLIVE: 2 // 存活时间
    }

    public static STATUS_CONST = {
        LOCK: 0, // 未解锁
        RECEIVE: 1, // 已领取
        CAN_RECEIVE: 2, // 可领取
    }

   
    public static CONFIG = [
        {
            id: 1,
            name: "击杀成就1",
            desc: "击杀怪物数量达到100",
            type: 1,
            count: 100,
            itemCount:500
        },
        {
            id: 2,
            name: "击杀成就2",
            desc: "击杀怪物数量达到300",
            type: 1,
            count: 300,
            itemCount:1500
        },
        {
            id: 3,
            name: "击杀成就3",
            desc: "击杀怪物数量达到500",
            type: 1,
            count: 500,
            itemCount:3000
        },
        {
            id: 4,
            name: "击杀成就4",
            desc: "击杀怪物数量达到700",
            type: 1,
            count: 700,
            itemCount:4500
        },
        {
            id: 5,
            name: "击杀成就5",
            desc: "击杀怪物数量达到1000",
            type: 1,
            count: 1000,
            itemCount:6000
        },
        {
            id: 6,
            name: "击杀成就6",
            desc: "击杀怪物数量达到1500",
            type: 1,
            count: 1500,
            itemCount:10000
        },
        {
            id: 7,
            name: "击杀成就7",
            desc: "击杀怪物数量达到2000",
            type: 1,
            count: 2000,
            itemCount:15000
        },
        {
            id: 8,
            name: "击杀成就8",
            desc: "击杀怪物数量达到3000",
            type: 1,
            count: 3000,
            itemCount:20000
        },
        {
            id: 9,
            name: "击杀成就9",
            desc: "击杀怪物数量达到5000",
            type: 1,
            count: 5000,
            itemCount:30000
        },
        {
            id: 10,
            name: "击杀成就10",
            desc: "击杀怪物数量达到8000",
            type: 1,
            count: 8000,
            itemCount:50000
        },


        {
            id: 101,
            name: "生存成就1",
            desc: "总存活120秒",
            type: 2,
            count: 120,
            itemCount:500
        },
        {
            id: 102,
            name: "生存成就2",
            desc: "总存活300秒",
            type: 2,
            count: 300,
            itemCount:1500
        },
        {
            id: 103,
            name: "生存成就3",
            desc: "总存活500秒",
            type: 2,
            count: 500,
            itemCount:3000
        },
        {
            id: 104,
            name: "生存成就4",
            desc: "总存活700秒",
            type: 2,
            count: 700,
            itemCount:4500
        },
        {
            id: 105,
            name: "生存成就5",
            desc: "总存活1000秒",
            type: 2,
            count: 1000,
            itemCount:6000
        },
        {
            id: 106,
            name: "生存成就6",
            desc: "总存活1500秒",
            type: 2,
            count: 1500,
            itemCount:10000
        },
        {
            id: 107,
            name: "生存成就7",
            desc: "总存活2000秒",
            type: 2,
            count: 2000,
            itemCount:15000
        },
        {
            id: 108,
            name: "生存成就8",
            desc: "总存活3000秒",
            type: 2,
            count: 3000,
            itemCount:20000
        },
        {
            id: 109,
            name: "生存成就9",
            desc: "总存活5000秒",
            type: 2,
            count: 5000,
            itemCount:30000
        },
        {
            id: 110,
            name: "生存成就10",
            desc: "总存活8000秒",
            type: 2,
            count: 8000,
            itemCount:50000
        },
    ]


    public static CONFIG_MAP = new Map<number,AttainmentBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取成就配置
     * @param id 成就ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }

    

}

/**
 * 成就配置
 */
export class AttainmentBasic {
    id:number = null; // 成就唯一标识
    name:string = null; // 成就名称
    desc:string = null; // 成就介绍
    type:number = null; // 成就类型
    count:number = null; // 成就达成数量
    itemCount = null; // 奖励金币数量
}