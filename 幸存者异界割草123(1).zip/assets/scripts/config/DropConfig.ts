// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

/**
 * 掉落配置
 */
@ccclass
export default class DropConfig {

    public static CONFIG = [
        // 1-100 经验
        {
            id:1,
            itemId:10001,
            min:1,
            max:2,
            prob: 8000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:2,
            itemId:10001,
            min:10,
            max:20,
            prob: 8000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:3,
            itemId:10001,
            min:100,
            max:200,
            prob: 8000,
            destroyType: 0,
            destroyContent: null
        },















        // 101-200 金币
        {
            id:101,
            itemId:10002,
            min:1,
            max:2,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:102,
            itemId:10002,
            min:2,
            max:3,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:103,
            itemId:10002,
            min:3,
            max:4,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:104,
            itemId:10002,
            min:4,
            max:5,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:105,
            itemId:10002,
            min:5,
            max:6,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:106,
            itemId:10002,
            min:6,
            max:7,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:107,
            itemId:10002,
            min:7,
            max:8,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:108,
            itemId:10002,
            min:8,
            max:9,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:109,
            itemId:10002,
            min:9,
            max:10,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:110,
            itemId:10002,
            min:10,
            max:11,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:111,
            itemId:10002,
            min:11,
            max:12,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:112,
            itemId:10002,
            min:12,
            max:13,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:113,
            itemId:10002,
            min:13,
            max:14,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:114,
            itemId:10002,
            min:14,
            max:15,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:115,
            itemId:10002,
            min:15,
            max:16,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:116,
            itemId:10002,
            min:16,
            max:17,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:117,
            itemId:10002,
            min:17,
            max:18,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:118,
            itemId:10002,
            min:18,
            max:19,
            prob: 2000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:119,
            itemId:10002,
            min:19,
            max:20,
            prob: 10000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:120,
            itemId:10002,
            min:20,
            max:30,
            prob: 10000,
            destroyType: 0,
            destroyContent: null
        },
        {
            id:121,
            itemId:10002,
            min:1000,
            max:2000,
            prob: 10000,
            destroyType: 0,
            destroyContent: null
        },
    ]


    public static CONFIG_MAP = new Map<number,DropBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取掉落配置
     * @param id 掉落ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }
}

/**
 * 掉落配置
 */
export class DropBasic {
    id:number = null; // 掉落唯一标识
    itemId:number = null; // 掉落物品ID
    min:number = null; // 最小数量
    max:number = null; // 最大数量
    prob:number = null; // 掉落概率,万分比
    destroyType: number = null; // 销毁类型 0-不销毁 1-时间 2-范围 
    destroyContent: number = null; // 销毁内容,根据销毁类型做处理
}