const {ccclass, property} = cc._decorator;

@ccclass
export default class AudioPathKey  {

    /**
     * 底部导航栏音效
     */
    public static BOTTON_NAV_AUDIO = "audio/button";

    /**
     * 打开弹窗音效
     */
    public static OPEN_VIEW_AUDIO = "audio/view";

    
    /**
     * 升级通用音效
     */
    public static LEVEL_UP_AUDIO = "audio/levelUp";

    
    /**
     * 拾取相关
     */
     public static GAIN = {
        EXP : "audio/gain_exp", // 拾取经验音效
    }


    /**
     * 伙伴技能
     */
    public static PET_SKILL = {
        DRAGON_SKILL : "audio/dragon_skill", // 烈焰魔龙火焰喷射
    }


}
