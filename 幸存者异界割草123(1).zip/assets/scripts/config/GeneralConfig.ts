
const {ccclass, property} = cc._decorator;

/**
 * 角色配置
 */
@ccclass
export default class GeneralConfig {

    public static CONFIG = [
        {
            id:1,
            name:"御剑师",
            desc:"每升1级，攻击提升1%",
            status: 1,
            picRes: {
                uri:"ui/general/general1/stand",
                width: 60,
                height: 95
            },
            animationRes:{
                run:"animation/general/general_1/run",
            },
            initSkillType:1,
            initSkillLevel:1,
            levelUpParam:[
                {
                    propName:"atkRate",
                    propNum:1,
                    propType:1,
                }
            ],
            unlockType: 0,
            unlockContent: null
        },
        {
            id:2,
            name:"法师",
            desc:"每升1级，防御提升1%",
            status: 1,
            picRes: {
                uri:"ui/general/general2/2",
                width: 60,
                height: 95
            },
            animationRes:{
                run:"animation/general/general_2/run",
            },
            initSkillType:9,
            initSkillLevel:1,
            levelUpParam:[
                {
                    propName:"defRate",
                    propNum:1,
                    propType:1,
                }
            ],
            unlockType: 1,
            unlockContent: {
                itemId: 10002,
                itemCount: 500
            },
        },
        {
            id:3,
            name:"弓箭手",
            desc:"每升1级，生命提升1%",
            status: 1,
            picRes: {
                uri:"ui/general/general3/2",
                width: 70,
                height: 95
            },
            animationRes:{
                run:"animation/general/general_3/run",
            },
            initSkillType:7,
            initSkillLevel:1,
            levelUpParam:[
                {
                    propName:"hpRate",
                    propNum:1,
                    propType:1,
                }
            ],
            unlockType: 1,
            unlockContent: {
                itemId: 10002,
                itemCount: 5000
            },
        },
        {
            id:4,
            name:"",
            desc:"",
            status: 0,
            picRes: {
                uri:"ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            initSkillType:null,
            initSkillLevel:null,
            levelUpParam:null,
            unlockType: null,
            unlockContent: null
        },
        {
            id:5,
            name:"",
            desc:"",
            status: 0,
            picRes: {
                uri:"ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            initSkillType:null,
            initSkillLevel:null,
            levelUpParam:null,
            unlockType: null,
            unlockContent: null
        },
        {
            id:6,
            name:"",
            desc:"",
            status: 0,
            picRes: {
                uri:"ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            initSkillType:null,
            initSkillLevel:null,
            levelUpParam:null,
            unlockType: null,
            unlockContent: null
        },
        {
            id:7,
            name:"",
            desc:"",
            status: 0,
            picRes: {
                uri:"ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            initSkillType:null,
            initSkillLevel:null,
            levelUpParam:null,
            unlockType: null,
            unlockContent: null
        }
    ]


    public static CONFIG_MAP = new Map<number,GeneralBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取角色配置
     * @param id 角色ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }

    /**
     * 获取角色等级增加的属性
     * @param id 角色ID
     * @param level 角色等级
     */
     public static getLevelPropById(id:number,level:number) {
        let general:GeneralBasic = this.CONFIG_MAP.get(id);
        let propList = general.levelUpParam;
        let rst = [];
        if(level > 1) {
            for(let i = 0;i < propList.length; i++) {
                let prop = propList[i];
                rst.push({
                    propName: prop.propName,
                    propNum:prop.propNum * (level - 1),
                    propType:prop.propType
                });
            }
        }
        return rst;
    }
}

/**
 * 角色配置
 */
export class GeneralBasic {
    id:number = null; // 角色唯一标识
    name:string = null; // 角色名称
    desc:string = null; // 角色介绍
    status:number = null; // 启用状态
    picRes = null; // 角色图片资源
    animationRes = null; // 角色动画资源
    initSkillType:number = null; // 初始技能类型
    initSkillLevel:number = null; // 初始技能等级
    levelUpParam = null; // 升级提升属性 {propName,propNum,propType},注意：大于2及开始计算
    unlockType:number = null; // 解锁类型
    unlockContent = null; // 解锁内容， 如：解锁类型为消耗金币，则此处配置消耗金币的数量
}