
const {ccclass, property} = cc._decorator;

/**
 * 伙伴配置
 */
@ccclass
export default class PetConfig {

    /**
     * 伙伴技能 - 伙伴ID
     */
    public static PET_SKILL_TYPE = {
        RANGE_FIRE : 1, 
    }

    public static LEVEL_CONFIG = [
        // 0
        "初生",

        // 1-10
        "妖兽一阶",        
        "妖兽二阶",        
        "妖兽三阶",        
        "妖兽四阶",        
        "妖兽五阶",        
        "妖兽六阶",        
        "妖兽七阶",        
        "妖兽八阶",        
        "妖兽九阶",   
        "妖兽满阶",

        // 11-20
        "兽兵一阶",        
        "兽兵二阶",        
        "兽兵三阶",        
        "兽兵四阶",        
        "兽兵五阶",        
        "兽兵六阶",        
        "兽兵七阶",        
        "兽兵八阶",        
        "兽兵九阶",
        "兽兵满阶",
        
        //21-30
        "兽将一阶",        
        "兽将二阶",        
        "兽将三阶",        
        "兽将四阶",        
        "兽将五阶",        
        "兽将六阶",        
        "兽将七阶",        
        "兽将八阶",        
        "兽将九阶",
        "兽将满阶",

        //31-40
        "兽王一阶",        
        "兽王二阶",        
        "兽王三阶",        
        "兽王四阶",        
        "兽王五阶",        
        "兽王六阶",        
        "兽王七阶",        
        "兽王八阶",        
        "兽王九阶",
        "兽王满阶",

        //41-50
        "兽皇一阶",        
        "兽皇二阶",        
        "兽皇三阶",        
        "兽皇四阶",        
        "兽皇五阶",        
        "兽皇六阶",        
        "兽皇七阶",        
        "兽皇八阶",        
        "兽皇九阶",
        "兽皇满阶",

        //51-60
        "兽尊一阶",        
        "兽尊二阶",        
        "兽尊三阶",        
        "兽尊四阶",        
        "兽尊五阶",        
        "兽尊六阶",        
        "兽尊七阶",        
        "兽尊八阶",        
        "兽尊九阶",
        "兽尊满阶",

        //61-70
        "圣兽一阶",        
        "圣兽二阶",        
        "圣兽三阶",        
        "圣兽四阶",        
        "圣兽五阶",        
        "圣兽六阶",        
        "圣兽七阶",        
        "圣兽八阶",        
        "圣兽九阶",     
        "圣兽满阶",

        //71-80
        "神兽一阶",        
        "神兽二阶",        
        "神兽三阶",        
        "神兽四阶",        
        "神兽五阶",        
        "神兽六阶",        
        "神兽七阶",        
        "神兽八阶",        
        "神兽九阶",
        "神兽满阶",

        //81-90
        "超神兽一阶",        
        "超神兽二阶",        
        "超神兽三阶",        
        "超神兽四阶",        
        "超神兽五阶",        
        "超神兽六阶",        
        "超神兽七阶",        
        "超神兽八阶",        
        "超神兽九阶",
        "超神兽满阶",

        //91-100
        "至尊神兽一阶",        
        "至尊神兽二阶",        
        "至尊神兽三阶",        
        "至尊神兽四阶",        
        "至尊神兽五阶",        
        "至尊神兽六阶",        
        "至尊神兽七阶",        
        "至尊神兽八阶",        
        "至尊神兽九阶",
        "至尊神兽满阶",

        //101
        "虚无",  
    ]    

    public static PET_SKILL_CONFIG = {
        "1" : {
            id:1,
            name: "范围火焰伤害",
            durationTime: 2500, // 每个持续时间
            atkIntervalTime: 500,
            num:20, // 一次释放20个
            speed: 300, // 速度,
            genIntervalTime:200, // 每次生成间隔时间
        }
    }

    public static CONFIG = [
        {
            id:1,
            name:"烈焰魔龙",
            desc:"喷射火焰，造成范围伤害",
            status: 1,
            baseWeight:1,
            skillType: "1",
            picRes:{
                uri: "ui/pet/dragon_red/dragon_red_1",
                width: 120,
                height: 80
            },
            animationRes:{
                fly:"animation/pet/dragon_red/fly"
            },
            unlockType: 0,
            unlockContent: 0,
            levelUpCost:{
                itemId:20001,
                itemCount:[
                    5,
                    10,20,30,40,50,60,70,80,90,100,
                    110,120,130,140,150,160,170,180,190,200,
                    210,220,230,240,250,260,270,280,290,300,
                    310,320,330,340,350,360,370,380,390,400,
                    410,420,430,440,450,460,470,480,490,500,
                    510,520,530,540,550,560,570,580,590,600,
                    610,620,630,640,650,660,670,680,690,700,
                    710,720,730,740,750,760,770,780,790,800,
                    810,820,830,840,850,860,870,880,890,900,
                    910,920,930,940,950,960,970,980,990,1000,
                    2000,
                ]
            },
            cdParam: {
                title: "冷却时间",
                list: [
                    30000,
                    30000,30000,30000,30000,30000,29000,29000,29000,29000,29000,
                    28000,28000,28000,28000,28000,27000,27000,27000,27000,27000,
                    26000,26000,26000,26000,26000,25000,25000,25000,25000,25000,
                    24000,24000,24000,24000,24000,23000,23000,23000,23000,23000,
                    22000,22000,22000,22000,22000,21000,21000,21000,21000,21000,
                    20000,20000,20000,20000,20000,19000,19000,19000,19000,19000,
                    18000,18000,18000,18000,18000,17000,17000,17000,17000,17000,
                    16000,16000,16000,16000,16000,15000,15000,15000,15000,15000,
                    14000,14000,14000,14000,14000,13000,13000,13000,13000,13000,
                    12000,12000,12000,12000,12000,11000,11000,11000,11000,11000,
                    10000
                ]
            },
            skillParam: {
                title: "范围伤害",
                list: [
                    // 5,
                    // 10,20,30,40,50,60,70,80,90,100,
                    // 110,120,130,140,150,160,170,180,190,200,
                    // 210,220,230,240,250,260,270,280,290,300,
                    // 310,320,330,340,350,360,370,380,390,400,
                    // 410,420,430,440,450,460,470,480,490,500,
                    // 510,520,530,540,550,560,570,580,590,600,
                    // 610,620,630,640,650,660,670,680,690,700,
                    // 710,720,730,740,750,760,770,780,790,800,
                    // 810,820,830,840,850,860,870,880,890,900,
                    // 910,920,930,940,950,960,970,980,990,1000,
                    // 2000,

                    5,
                    10,10,10,15,15,15,20,20,20,25,
                    25,25,25,30,30,30,35,35,35,40,
                    45,45,45,50,50,50,55,55,55,60,
                    60,60,60,65,65,65,70,70,70,75,
                    75,75,75,80,80,80,85,85,85,90,
                    90,90,90,95,95,95,100,100,100,105,
                    105,105,105,110,110,110,115,115,115,120,
                    120,120,120,125,125,125,130,130,130,130,
                    135,135,135,140,140,140,145,145,150,155,
                    155,155,155,160,160,160,165,165,165,170,
                    1000,
                ]
            },
            propParam: {
                title: "攻击提升",
                list:[
                    {
                        propName:"atkRate",
                        propNum:1,
                        propType:1,
                    }
                ]
            }
        },
        {
            id:2,
            name:"",
            desc:"",
            status: 0,
            baseWeight: null,
            skillType: null,
            picRes:{
                uri: "ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            unlockType:null,
            unlockContent:null,
            levelUpCost:null,
            cdParam:null,
            skillParam:null,
            propParam:null
        },
        {
            id:3,
            name:"",
            desc:"",
            status: 0,
            baseWeight: null,
            skillType: null,
            picRes:{
                uri: "ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            unlockType:null,
            unlockContent:null,
            levelUpCost:null,
            cdParam:null,
            skillParam:null,
            propParam:null
        },
        {
            id:4,
            name:"",
            desc:"",
            status: 0,
            baseWeight: null,
            skillType: null,
            picRes:{
                uri: "ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            unlockType:null,
            unlockContent:null,
            levelUpCost:null,
            cdParam:null,
            skillParam:null,
            propParam:null
        } ,
        {
            id:5,
            name:"",
            desc:"",
            status: 0,
            baseWeight: null,
            skillType: null,
            picRes:{
                uri: "ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            unlockType:null,
            unlockContent:null,
            levelUpCost:null,
            cdParam:null,
            skillParam:null,
            propParam:null
        },
        {
            id:6,
            name:"",
            desc:"",
            status: 0,
            baseWeight: null,
            skillType: null,
            picRes:{
                uri: "ui/common/lock",
                width: 70,
                height: 95
            },
            animationRes:null,
            unlockType:null,
            unlockContent:null,
            levelUpCost:null,
            cdParam:null,
            skillParam:null,
            propParam:null
        }
        
    ]


    public static CONFIG_MAP = new Map<number,PetBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取伙伴配置
     * @param id 伙伴ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }

    /**
     * 获取伙伴等级增加的属性
     * @param id 伙伴ID
     * @param level 伙伴等级
     */
     public static getLevelPropById(id:number,level:number) {
        let pet:PetBasic = this.CONFIG_MAP.get(id);
        let propList = pet.propParam.list;
        let rst = [];
        for(let i = 0;i < propList.length; i++) {
            let prop = propList[i];
            rst.push({
                title: pet.propParam.title,
                propName: prop.propName,
                propNum:prop.propNum * level,
                propType:prop.propType
            });
        }
        return rst;
    }

    /**
     * 获取伙伴等级技能的属性
     * @param id 伙伴ID
     * @param level 伙伴等级
     */
     public static getLevelSkillById(id:number,level:number) {
        let pet:PetBasic = this.CONFIG_MAP.get(id);
        let skill = pet.skillParam;
        let rst = {
            title: skill.title,
            content: skill.list[level]
        };
        return rst;
    }

    /**
     * 获取伙伴等级冷却时间
     * @param id 伙伴ID
     * @param level 伙伴等级
     */
    public static getLevelCdById(id:number,level:number) {
        let pet:PetBasic = this.CONFIG_MAP.get(id);
        let cd = pet.cdParam;
        let rst = {
            title: cd.title,
            content: cd.list[level]
        };
        return rst;
    }

    /**
     * 获取伙伴等级消耗物品
     * @param id 伙伴ID
     * @param level 伙伴等级
     */
     public static getLevelCostById(id:number,level:number) {
        let pet:PetBasic = this.CONFIG_MAP.get(id);
        let levelUpCost = pet.levelUpCost;
        let item = {
            itemId: levelUpCost.itemId,
            itemCount: levelUpCost.itemCount[level]
        };
        return item;
    }

     /**
     * 获取伙伴等级生成技能信息
     * @param id 伙伴ID
     * @param level 伙伴等级
     */
      public static getLevelGenSkillById(id:number,level:number) {
        let pet:PetBasic = this.CONFIG_MAP.get(id);
        let cdParam = pet.cdParam;
        let cdTime = cdParam.list[level]; // 冷却时间
        let skillParam = pet.skillParam;
        let atk = skillParam.list[level]; // 攻击

        let skillOtherParam = this.PET_SKILL_CONFIG[pet.skillType];
        let durationTime = skillOtherParam.durationTime;
        let atkIntervalTime = skillOtherParam.atkIntervalTime;
        let num = skillOtherParam.num;
        let speed = skillOtherParam.speed;
        let genIntervalTime = skillOtherParam.genIntervalTime;

        let rst = {
            cdTime : cdTime,
            atk : atk,
            durationTime : durationTime,
            atkIntervalTime : atkIntervalTime,
            num:num,
            speed: speed,
            genIntervalTime:genIntervalTime
        }
        return rst;
    }
}

/**
 * 伙伴配置
 */
export class PetBasic {
    id:number = null; // 伙伴唯一标识
    name:string = null; // 伙伴名称
    desc:string = null; // 伙伴介绍
    status:number = null; // 启用状态
    baseWeight:number = null; // 合成获得伙伴碎片的权重
    skillType:string = null; // 技能预制体
    picRes = null; // 伙伴图片资源
    animationRes = null; // 伙伴动画资源
    unlockType:number = null; // 解锁类型
    unlockContent = null; // 解锁内容， 如：解锁类型为消耗金币，则此处配置消耗金币的数量
    levelUpCost = null; // 升级消耗
    cdParam = null; // 冷却参数
    skillParam = null; // 技能参数
    propParam = null; // 属性参数
}