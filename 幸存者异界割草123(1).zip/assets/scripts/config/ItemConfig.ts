// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

/**
 * 物品配置
 */
@ccclass
export default class ItemConfig {

    public static ITEM_CONST = {
        EXP: "10001",
        GOLD : "10002",
        SHOU_JING : "10003",
        VIGOUR: "10004"
    }

    public static CONFIG = [
        {
            id:10001,
            name:"经验",
        },
        {
            id:10002,
            name:"金币",
        },
        {
            id:10003,
            name:"兽晶",
        },
        {
            id:10004,
            name:"体力",
        },
        
        {
            id:20001,
            name:"烈焰魔龙碎片",
        }
    ]


    public static CONFIG_MAP = new Map<number,ItemBasic>();

    /**
     * 加载配置
     */
    public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }
    
    /**
     * 获取物品配置
     * @param id 物品ID
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }
}

/**
 * 玩家物品配置
 */
export class ItemBasic {
    id:number = null; // 物品唯一标识
    name:string = null; // 物品名称
}