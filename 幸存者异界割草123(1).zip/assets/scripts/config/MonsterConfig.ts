// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { DropBasic } from "./DropConfig";

const {ccclass, property} = cc._decorator;

/**
 * 怪物配置
 */
@ccclass
export default class MonsterConfig {

    public static CONFIG = [
        {
            id:101,
            name:"红色骷髅怪",
            type: 1,
            hp:10,
            atk:5,
            def:3,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,101],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:102,
            name:"魔蛛",
            type: 1,
            hp:20,
            atk:8,
            def:5,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,102],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:103,
            name:"魔蚊",
            type: 1,
            hp:30,
            atk:10,
            def:7,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,103],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:104,
            name:"红色骷髅怪",
            type: 1,
            hp:40,
            atk:12,
            def:9,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,104],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:105,
            name:"红色骷髅怪",
            type: 1,
            hp:50,
            atk:14,
            def:11,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,105],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:106,
            name:"红色骷髅怪",
            type: 1,
            hp:60,
            atk:16,
            def:13,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,106],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:107,
            name:"红色骷髅怪",
            type: 1,
            hp:70,
            atk:18,
            def:15,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,107],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:108,
            name:"红色骷髅怪",
            type: 1,
            hp:80,
            atk:20,
            def:17,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,108],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:109,
            name:"红色骷髅怪",
            type: 1,
            hp:90,
            atk:22,
            def:19,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,109],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:110,
            name:"红色骷髅怪",
            type: 1,
            hp:100,
            atk:24,
            def:21,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,110],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:111,
            name:"红色骷髅怪",
            type: 1,
            hp:110,
            atk:26,
            def:23,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,111],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:112,
            name:"红色骷髅怪",
            type: 1,
            hp:120,
            atk:28,
            def:25,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,112],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:113,
            name:"红色骷髅怪",
            type: 1,
            hp:130,
            atk:30,
            def:27,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,113],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:114,
            name:"红色骷髅怪",
            type: 1,
            hp:140,
            atk:32,
            def:29,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,114],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:115,
            name:"红色骷髅怪",
            type: 1,
            hp:150,
            atk:34,
            def:31,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,115],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:116,
            name:"红色骷髅怪",
            type: 1,
            hp:160,
            atk:36,
            def:33,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,116],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:117,
            name:"红色骷髅怪",
            type: 1,
            hp:170,
            atk:38,
            def:35,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,117],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:118,
            name:"红色骷髅怪",
            type: 1,
            hp:180,
            atk:40,
            def:37,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,118],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:119,
            name:"红色骷髅怪",
            type: 1,
            hp:190,
            atk:42,
            def:39,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:120,
            name:"红色骷髅怪",
            type: 1,
            hp:200,
            atk:44,
            def:41,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:121,
            name:"红色骷髅怪",
            type: 1,
            hp:210,
            atk:46,
            def:43,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:122,
            name:"红色骷髅怪",
            type: 1,
            hp:220,
            atk:48,
            def:45,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:123,
            name:"红色骷髅怪",
            type: 1,
            hp:230,
            atk:50,
            def:47,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:124,
            name:"红色骷髅怪",
            type: 1,
            hp:240,
            atk:52,
            def:49,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:125,
            name:"红色骷髅怪",
            type: 1,
            hp:250,
            atk:54,
            def:51,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:126,
            name:"红色骷髅怪",
            type: 1,
            hp:260,
            atk:56,
            def:53,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:127,
            name:"红色骷髅怪",
            type: 1,
            hp:270,
            atk:58,
            def:55,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:128,
            name:"红色骷髅怪",
            type: 1,
            hp:280,
            atk:60,
            def:57,
            speed:40,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:60, 
                height:60 
            }
        },
        {
            id:129,
            name:"红色骷髅怪",
            type: 1,
            hp:290,
            atk:62,
            def:59,
            speed:55,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_3/1", 
                animationRes:{
                    walk:"animation/monster/monster3/walk", 
                },
                colliderType:2,
                width:40, 
                height:40 
            }
        },
        {
            id:130,
            name:"红色骷髅怪",
            type: 1,
            hp:300,
            atk:64,
            def:61,
            speed:60,
            atkIntervalTime:500,
            dropIds:[1,119],
            skillList:null,
            ui:{
                isLeft: false,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_5/1", 
                animationRes:{
                    walk:"animation/monster/monster5/walk", 
                },
                colliderType:2,
                width:30, 
                height:30
            }
        },
        {
            id:201,
            name:"蓝色骷髅怪",
            type: 2,
            hp:200,
            atk:8,
            def:5,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:202,
            name:"地狱魔犬",
            type: 2,
            hp:250,
            atk:14,
            def:9,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:203,
            name:"盾龟",
            type: 2,
            hp:300,
            atk:16,
            def:13,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:204,
            name:"蓝色骷髅怪",
            type: 2,
            hp:350,
            atk:20,
            def:17,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:205,
            name:"蓝色骷髅怪",
            type: 2,
            hp:400,
            atk:24,
            def:21,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:206,
            name:"蓝色骷髅怪",
            type: 2,
            hp:450,
            atk:28,
            def:25,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:207,
            name:"蓝色骷髅怪",
            type: 2,
            hp:500,
            atk:32,
            def:29,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:208,
            name:"蓝色骷髅怪",
            type: 2,
            hp:550,
            atk:36,
            def:33,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:209,
            name:"蓝色骷髅怪",
            type: 2,
            hp:600,
            atk:40,
            def:37,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:210,
            name:"蓝色骷髅怪",
            type: 2,
            hp:650,
            atk:44,
            def:41,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:211,
            name:"蓝色骷髅怪",
            type: 2,
            hp:700,
            atk:48,
            def:45,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:212,
            name:"蓝色骷髅怪",
            type: 2,
            hp:750,
            atk:52,
            def:49,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:213,
            name:"蓝色骷髅怪",
            type: 2,
            hp:800,
            atk:56,
            def:53,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:214,
            name:"蓝色骷髅怪",
            type: 2,
            hp:850,
            atk:60,
            def:57,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:215,
            name:"蓝色骷髅怪",
            type: 2,
            hp:900,
            atk:64,
            def:61,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:216,
            name:"蓝色骷髅怪",
            type: 2,
            hp:950,
            atk:68,
            def:65,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:217,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1000,
            atk:70,
            def:67,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:218,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1050,
            atk:72,
            def:69,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:219,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1100,
            atk:76,
            def:73,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:220,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1150,
            atk:80,
            def:77,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:221,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1200,
            atk:84,
            def:81,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:222,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1250,
            atk:88,
            def:85,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:223,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1300,
            atk:92,
            def:89,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:224,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1350,
            atk:96,
            def:93,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:225,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1400,
            atk:100,
            def:97,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:226,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1450,
            atk:104,
            def:101,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:227,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1500,
            atk:108,
            def:105,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:228,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1550,
            atk:112,
            def:119,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_2/1", 
                animationRes:{
                    walk:"animation/monster/monster2/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:229,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1600,
            atk:116,
            def:113,
            speed:100,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:100, 
                height:48 
            }
        },
        {
            id:230,
            name:"蓝色骷髅怪",
            type: 2,
            hp:1650,
            atk:120,
            def:117,
            speed:50,
            atkIntervalTime:500,
            dropIds:[2,120],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:65, 
                height:65 
            }
        },
        {
            id:301,
            name:"红色BOSS怪",
            type: 3,
            hp:1500,
            atk:50,
            def:30,
            speed:60,
            atkIntervalTime:500,
            dropIds:[3,121],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_1/1", 
                animationRes:{
                    walk:"animation/monster/monster1/walk", 
                },
                colliderType:2,
                width:140, 
                height:140 
            }
        },
        {
            id:302,
            name:"地狱魔犬BOSS",
            type: 3,
            hp:3000,
            atk:100,
            def:80,
            speed:100,
            atkIntervalTime:500,
            dropIds:[3,121],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_4/1", 
                animationRes:{
                    walk:"animation/monster/monster4/walk", 
                },
                colliderType:2,
                width:150, 
                height:72 
            }
        },
        {
            id:303,
            name:"盾龟BOSS",
            type: 3,
            hp:4500,
            atk:150,
            def:120,
            speed:60,
            atkIntervalTime:500,
            dropIds:[3,121],
            skillList:null,
            ui:{
                isLeft: true,
                prefab:"prefab/monster/monster",
                picRes:"ui/monster/monster_6/gui1", 
                animationRes:{
                    walk:"animation/monster/monster6/walk", 
                },
                colliderType:2,
                width:120, 
                height:120 
            }
        },
    ]

    public static CONFIG_MAP = new Map<number,MonsterBasic>();

    /**
     * 加载配置
     */
     public static loadConfigMap() {
        for(let i = 0;i < this.CONFIG.length;i++) {
            let config = this.CONFIG[i];
            this.CONFIG_MAP.set(config.id,config);
        }
    }

    /**
     * 获取怪物配置
     * @param id 怪物唯一标识
     */
    public static getConfigById(id:number) {
        return this.CONFIG_MAP.get(id);
    }
}

/**
 * 阶级配置
 */
export class MonsterBasic {
    id:number = null; // 怪物唯一标识
    name:string = null; // 怪物名称
    type:number = null; // 怪物类型 1-普通怪物 2-精英怪物 3-BOSS怪物
    hp:number = null; // 怪物血量
    atk:number = null; // 怪物攻击力
    def:number = null; // 怪物防御力
    speed:number = null; // 怪物移速
    atkIntervalTime:number = null; // 怪物攻击间隔，即对玩家造成伤害的间隔
    dropIds = null; // 掉落唯一标识列表,
    skillList = null; // 技能配置
    ui:{}
}