import ItemConfig from "../config/ItemConfig";
import SkillConfig, { SkillBasic } from "../config/SkillConfig";
import RandomUtil from "../utils/RandomUtil";
import PlayerFightPropCtrl from "./PlayerFightPropCtrl";

const {ccclass, property} = cc._decorator;

@ccclass
export default class SkillCtrl {

    private static _instance: SkillCtrl = null;

    public static getInstance() {
        if (!this._instance) {
            this._instance = new SkillCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {
    }

    private _destroy() { }

    

    private currTime: number = 0; // 当前时间

    private skillInfos = {} // 玩家当前技能信息

    private canChooseSkillInfos = [] // 能够选择的技能信息

    public chooseType = {
        1:{
            num:3
        }, // 升级选择
        2:{
            num:6
        }, // 初始选择

    } // 选择类型

    public update (dt) {
        this.currTime = this.currTime + (dt * 1000);
        // cc.log(this.currTime);
    }

    // 技能初始化
    skillInit(skill:any) {
        // 新创建该类型的技能
        let skillInfo = {
            id:skill.id,
            type:skill.type,
            level:skill.level,
            num:skill.num,
            passNum:skill.passNum,
            durationTime:skill.durationTime,
            cdTime:skill.cdTime,
            atk:skill.atk,
            atkRange:skill.atkRange,
            lastAtkTime:0,
            speed:skill.speed,
            intervalTime:skill.intervalTime,
            parentType:skill.parentType,
            atkIntervalTime:skill.atkIntervalTime,
            name:skill.name,
            desc:skill.desc,
            picRes:skill.picRes,
            sameAtkNum:skill.sameAtkNum,
            skillParam:skill.skillParam,
        }
        this.skillInfos[skill.type+""] = skillInfo
    }

    // 技能升级
    skillUp(skill:any) {
        let skillInfo = this.skillInfos[skill.type+""]
        skillInfo.id = skill.id;
        skillInfo.level = skill.level;
        skillInfo.num = skill.num;
        skillInfo.passNum = skill.passNum;
        skillInfo.durationTime = skill.durationTime;
        skillInfo.cdTime = skill.cdTime;
        skillInfo.atk = skill.atk;
        skillInfo.atkRange = skill.atkRange;
        skillInfo.speed = skill.speed;
        skillInfo.intervalTime = skill.intervalTime;
        skillInfo.parentType = skill.parentType;
        skillInfo.atkIntervalTime = skill.atkIntervalTime;
        skillInfo.name = skill.name;
        skillInfo.desc = skill.desc;
        skillInfo.picRes = skill.picRes;
        skillInfo.sameAtkNum = skill.sameAtkNum;
        skillInfo.skillParam = skill.skillParam;
        this.skillInfos[skill.type+""] = skillInfo;
    }


    /**
     * 选择技能
     * @param pos 位置
     */
    chooseSkill(pos:number) {
        if(pos < 0 || pos > this.canChooseSkillInfos.length) {
            return;
        }

        let skillInfo = this.canChooseSkillInfos[pos - 1];
        return this.getSkill(skillInfo.type,skillInfo.level);
    }

    // 获得技能,如果为资源类型的技能需要返回获得的物品信息
    getSkill(type:number,level:number) {

        
        // 获取技能配置信息
        let skill = SkillConfig.CONFIG[type+""].list[level-1];
        let execType = SkillConfig.CONFIG[type+""].execType; // 技能执行类型
        let limitType = SkillConfig.CONFIG[type+""].limitType; // 技能限制类型


        if(!skill) {
            return;
        }

        // 根据类型检查是否已经存在技能
        let currSkill = this.skillInfos[type+""];

        // 如果不存在技能信息,则新增技能,存在则升级
        if(SkillConfig.EXEC_TYPE.NORMAL == execType || SkillConfig.EXEC_TYPE.PROP == execType) {
            // 受等级限制的需要存储技能信息
            if(SkillConfig.LIMIT_TYPE.LEVEL_LIMIE == limitType) {
                if(currSkill) {
                    this.skillUp(skill);
                }else {
                    this.skillInit(skill)
                }
            }
            

            // 属性技能处理战斗属性
            if(SkillConfig.EXEC_TYPE.PROP == execType) {
                this.execPropSkill(skill);
            }
        }else if(SkillConfig.EXEC_TYPE.RES) {
            return this.execResSkill(skill);
        }
        return null;
    }

    /**
     * 执行属性技能
     */
    execPropSkill(skill:SkillBasic) {
        let skillParam = skill.skillParam;
        if(skillParam == null) {
            return;
        }
        
        // currHp 特殊属性
        if(skillParam["propName"] == "currHp") {
            PlayerFightPropCtrl.getInstance().execRecoveryCurrHp(skillParam["propNum"],skillParam["propType"],true);
        }else {
            PlayerFightPropCtrl.getInstance().addPropByType(PlayerFightPropCtrl.PROP_TYPE.SKILL, skillParam["propName"],skillParam["propNum"],skillParam["propType"]);
        }

        // 重新计算玩家战斗属性
        PlayerFightPropCtrl.getInstance().calcFightPropBySkill();
    }

    
    /**
     * 执行资源技能
     */
    execResSkill(skill:SkillBasic) {
        let skillParam = skill.skillParam;
        if(skillParam == null) {
            return;
        }
        if(ItemConfig.getConfigById(skillParam["itemId"]) == null || skillParam["itemCount"] <= 0) {
            return null;
        }
        let item = {
            itemId: skillParam["itemId"],
            itemCount: skillParam["itemCount"],
        }
        return item;
    }

    /**
     * 获取能够选择的技能信息
     * @param chooseType 选择类型 1-升级选择 2-初始选择
     * @returns 
     */
     public getChooseSkill(chooseType:number) {
        cc.log("技能控制类->获取可以选择的技能信息,选择类型:",chooseType);
        this.resetCanChooseSkillInfos(chooseType);
        return this.canChooseSkillInfos;
    }

    /**
     * 重新计算能够选择的技能
     * 注：法宝类型技能权重默认 +1
     * @param chooseType 选择类型 1-升级选择 2-初始选择
     */
    private resetCanChooseSkillInfos(chooseType:number) {
        this.canChooseSkillInfos = [];

        // 按照技能类型进行权重分配
        let weights = [];
        for (const key in SkillConfig.CONFIG) {
            let w = 1; // 默认权重
            // 如果技能已经存在,则按当前技能等级分配权重
            let level = 1;
            if(this.skillInfos[key]) {
                level = this.skillInfos[key].level;
                // 如果技能受等级上限限制，已经为最高级则不加入选择
                if(SkillConfig.CONFIG[key].limitType == SkillConfig.LIMIT_TYPE.LEVEL_LIMIE && level >= SkillConfig.getTypeLength(key)) {
                    continue;
                }
                w = level * 4; // 权重等于当前技能等级 * 4
                level += 1; // 需要选择的技能等级为当前等级+1
            }

            // 附加基础权重
            w += SkillConfig.CONFIG[key].baseWeight;
            let skillInfo = SkillConfig.CONFIG[key].list[level-1]; // 技能信息
            if(skillInfo == null) {
                cc.log("类型:%s,等级:%s 的技能信息找不到",key,level);
            }
            weights.push({skillInfo:skillInfo,weight:w}); 
        }

        // 计算
        if(weights.length > 0) {
            for(let i = 0; i < this.chooseType[chooseType].num; i++) {
                let random = RandomUtil.RandomByWeight(weights);
                this.canChooseSkillInfos.push(random.skillInfo); // 技能加入可选列表
                weights = weights.filter(item => item !== random); // 移除已经加入的
            }
        }
    }

    /**
     * 获取需要生成的技能信息
     * @returns 
     */
    public getGenSkill() {
        let genSkillList = [];
        for (const key in this.skillInfos) {
            // 不是正常执行类型的不需要生成
            if(SkillConfig.EXEC_TYPE.NORMAL != SkillConfig.CONFIG[key].execType) {
                continue;
            }
            if (Object.prototype.hasOwnProperty.call(this.skillInfos, key)) {
                let skillInfo = this.skillInfos[key];
                if(skillInfo.lastAtkTime == 0 || skillInfo.lastAtkTime + skillInfo.cdTime < this.currTime) {
                    skillInfo.lastAtkTime = this.currTime;
                    genSkillList.push(skillInfo);
                }
            }
        }
        return genSkillList;
    }
}
