import DropConfig, { DropBasic } from "../config/DropConfig";
import MonsterConfig, { MonsterBasic } from "../config/MonsterConfig";
import RefreshConfig, { RefreshBasic } from "../config/RefreshConfig";
import MapManager from "./MapManager";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MonsterCtrl {

    private static _instance: MonsterCtrl = null;

    /**
     * 怪物类型
     */
    private MONSTER_NORMAL = "normal"; // 普通怪物
    private MONSTER_ELITE = "elite"; // 精英怪物
    private MONSTER_BOSS = "boss"; // BOSS

    private monsterTypes = [
        this.MONSTER_NORMAL, 
        this.MONSTER_ELITE, 
        this.MONSTER_BOSS 
    ]

    private roomTime: number = 0; // 当前房间时间,从0毫秒开始 

    private bossIsArrive:boolean = false; // BOSS来临状态

    public static getInstance() {
        if (!this._instance) {
            this._instance = new MonsterCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }
   
    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }
    
    private _init() {
    }

    public update(dt) {
        this.roomTime += dt;
    }

    /**
     * 怪物刷新配置
     */
    private refresh = null;

    /**
     * 怪物配置
     */
    private monsterConfigs = {
        normal : [],
        elite: [],
        boss: []
    }

    /**
     * 初始化怪物刷新信息
     * @param refresh 怪物刷新配置
     * @param mosnterParam 怪物增强配置
     */
    public initMonsterRefresh(refresh:any,mosnterParam:any) {
        cc.log("monsterRefresh:",refresh);
        this.refresh = refresh;

        // 获取怪物刷新配置
        for(let i = 0; i < this.monsterTypes.length; i++) {
            let monsterType = this.monsterTypes[i];
            this.initMonsterConfig(mosnterParam,refresh[monsterType],monsterType);
        }

        cc.log(this.monsterConfigs);
    }

    /**
     * 初始化怪物配置信息
     * @param mosnterParam 怪物增强配置
     * @param refreshIds 怪物刷新配置ID列表
     * @param monsterType 怪物类型
     */
    private initMonsterConfig(mosnterParam:any,refreshIds,monsterType:string) {
        for(let i = 0;i < refreshIds.length;i++) {
            let refreshId = refreshIds[i];
            // 获取刷新配置
            let refreshConfig:RefreshBasic = RefreshConfig.getConfigById(refreshId);
            // 获取怪物配置
            let monsterConfig:MonsterBasic = MonsterConfig.getConfigById(refreshConfig.mosnterId);
            let hp = monsterConfig.hp;
            let atk = monsterConfig.atk;
            let def = monsterConfig.def;
            let speed = monsterConfig.speed;
            let maxNum = refreshConfig.maxNum; // 怪物數量
            // let refreshInterval = refreshConfig.refreshInterval; // 怪物刷新间隔
            // 处理怪物增强参数
            if(mosnterParam != null) {
                let addMaxNum = (maxNum * mosnterParam.maxNumRate / 100);
                maxNum += addMaxNum;
                hp = Math.floor(hp * ((100 + mosnterParam.hpRate) / 100));
                atk = Math.floor(atk * ((100 + mosnterParam.atkRate) / 100));
                def = Math.floor(def * ((100 + mosnterParam.defRate) / 100));
                speed = Math.floor(speed * ((100 + mosnterParam.speedRate) / 100));
            }
            let refreshInterval = 60000 / maxNum;  // 刷新间隔为一分钟内刷完

            let mc = {
                maxNum : maxNum,
                refreshInterval : refreshInterval,
                firstTime : refreshConfig.firstTime,
                type : monsterConfig.type,
                hp : hp,
                atk : atk,
                def : def,
                speed : speed,
                skillList : monsterConfig.skillList,
                atkIntervalTime : monsterConfig.atkIntervalTime,
                ui : monsterConfig.ui,
                dropIds : monsterConfig.dropIds,
                prefix : monsterType,
                nextId : 1,
            }
            this.monsterConfigs[monsterType].push(mc);
        }
    }

    /**
     * 获取需要生成的怪物列表
     */
    public getGenMonsterList() {
        let monsterList = [];

         // 获取怪物刷新配置,循环怪物类型获取,不包括BOSS
         for(let i = 0; i < this.monsterTypes.length - 1; i++) {
            let monsterType = this.monsterTypes[i];
            let genInfo = this.getGenMonster(monsterType);
            if(genInfo) {
                monsterList.push(genInfo);
            }
        }

        return monsterList;
    }
    
    /**
     * 生成怪物
     * @param monsterType 怪物类型 1-普通怪物 2-精英怪物 3-BOSS
     */
    getGenMonster(monsterType:string) {
        // 当前时间为第几分钟,获取对应下表的怪物
        let index = Math.floor(this.roomTime / 60);
        // 防止配置出错
        if(index >= this.monsterConfigs[monsterType].length) {
            index = this.monsterConfigs[monsterType].length - 1;
        }

        // 首次刷新时间没到
        if(this.roomTime * 1000 < this.monsterConfigs[monsterType][index].firstTime) {
            return null;
        }

        // 刷新间隔没到
        if(this.roomTime * 1000 - this.monsterConfigs[monsterType][index].refreshInterval < this.monsterConfigs[monsterType][index].lastRefreshTime) {
            return null;
        }

        // 重置怪物刷新时间
        this.monsterConfigs[monsterType][index].lastRefreshTime = this.roomTime * 1000;

        // 生成怪物信息
        let id = this.monsterConfigs[monsterType][index].prefix + "_" + this.monsterConfigs[monsterType][index].nextId++;
        let genInfo = this.monsterConfigs[monsterType][index];
        genInfo["id"] = id;
        
        return genInfo;
    }

    /**
     * 获取BOSS生成信息
     */
    public getGenBoss() {
        // BOSS来临时间
        if(this.roomTime * 1000 < this.refresh.bossArriveTime) {
            return null;
        }

        if(this.bossIsArrive) {
            return null;
        }

         // 生成怪物信息
         let id = this.monsterConfigs[this.MONSTER_BOSS][0].prefix + "_" + this.monsterConfigs[this.MONSTER_BOSS][0].nextId++;
         let boss = this.monsterConfigs.boss[0];
         boss["id"] = id;

         // BOSS已出生
        this.bossIsArrive = true;
         
        return boss;
    }

    /**
     * 获取初始位置
     * @param type 怪物类型 1-普通怪物 2-精英怪物 3-BOSS
     */
    public getInitPosition(playerX:number,playerY:number,type:number) {
        let MAP_WIDTH = MapManager.getInstance().MAP_WIDTH / 2;
        let MAP_HEIGHT = MapManager.getInstance().MAP_HEIGHT / 2;
        let position = null;
        let x = (1 + Math.random() * (MAP_WIDTH / 2));
        let y = (1 + Math.random() * (MAP_HEIGHT / 2));
        let vx = Math.random() > 0.5 ? 1 : -1; // 取X正负
        let vy= Math.random() > 0.5 ? 1 : -1; // 取Y正负
        x = x * vx;
        y = y * vy;
        x += playerX;
        y += playerY;
        position = cc.v2(x,y);
        return position;
    } 

    private _destroy() { }
    
}
