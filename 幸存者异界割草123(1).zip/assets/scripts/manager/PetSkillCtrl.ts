import PetConfig from "../config/PetConfig";

const {ccclass, property} = cc._decorator;

@ccclass
export default class PetSkillCtrl {

    private static _instance: PetSkillCtrl = null;

    private lastGenSkillTime: number = 0; // 上次发动技能时间

    private currTime: number = 0; // 当前时间

    private hasPet: boolean = false; // 是否有上阵伙伴

    /**
     * 伙伴技能信息
     */
    private petSkillInfo = {
        petId: 0,
        cdTime : 0,
        atk: 0,
        atkIntervalTime:0,
        durationTime:0,
        num:0,
        speed:0,
        genIntervalTime:0
    };


    public static getInstance() {
        if (!this._instance) {
            this._instance = new PetSkillCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {
    }

    private _destroy() {
        this.hasPet = false;
        this.petSkillInfo = {
            petId: 0,
            cdTime : 0,
            atk: 0,
            atkIntervalTime:0,
            durationTime:0,
            num:0,
            speed:0,
            genIntervalTime:0
        };
     }

    public update (dt) {
        this.currTime = this.currTime + (dt * 1000);
    }

    /**
     * 获得伙伴技能
     * @param petId 伙伴ID
     */
    public getPetSkill(petId:number,level:number) {
        let petConfig = PetConfig.getConfigById(petId);
        if(petConfig == null) {
            return;
        }
  
        let skill = PetConfig.getLevelGenSkillById(petId,level);
        this.petSkillInfo = {
            petId: petId,
            cdTime: skill.cdTime,
            atk: skill.atk,
            atkIntervalTime: skill.atkIntervalTime,
            durationTime: skill.durationTime,
            num: skill.num,
            speed: skill.speed,
            genIntervalTime: skill.genIntervalTime,
        }

        this.hasPet = true;
    }

    /**
     * 获取要生成的伙伴技能
     */
    public getGenPetSkill() {
        if(!this.hasPet) {
            return null;
        }
        if(this.lastGenSkillTime + this.petSkillInfo.cdTime > this.currTime) {
            return null;
        }

        this.lastGenSkillTime = this.currTime;
        return this.petSkillInfo;
    }
}
