import ChapterConfig, { ChapterBasic } from "../config/ChapterConfig";
import SpriteManager from "./SpriteManager";


export default class MapManager {

    public MAP_WIDTH = 1440; // 地图宽度
    public MAP_HEIGHT = 2560; // 地图高度

    /**
     * 当前所有地图块信息
     */
    public mapInfos = {

    }
    

    private static _instance: MapManager = null;
    private _spriteFrames: any = {};

    public static getInstance() {
        if (!this._instance) {
            this._instance = new MapManager();
            this._instance._init();
        }
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private mapDirPositions = [];

    private _init() {
        this.mapDirPositions = [
            {x:0,y:0},
            {x:-this.MAP_WIDTH,y:this.MAP_HEIGHT}, // 左上
            {x:0,y:this.MAP_HEIGHT}, // 上
            {x:this.MAP_WIDTH,y:this.MAP_HEIGHT}, // 右上
            {x:-this.MAP_WIDTH,y:0}, // 左
            {x:this.MAP_WIDTH,y:0}, // 右
            {x:-this.MAP_WIDTH,y:-this.MAP_HEIGHT}, // 左下
            {x:0,y:-this.MAP_HEIGHT}, // 下
            {x:this.MAP_WIDTH,y:-this.MAP_HEIGHT}, // 右下
        ]
    }

    private _destroy() {
        this.mapInfos = {};
    }

    public getGenMaps(playerX,playerY) {
        let mapX = 0;
        let mapY = 0;
        let xNum;
        let yNum;
        if(playerX > this.MAP_WIDTH / 6) { 
            xNum = Math.floor(playerX / (this.MAP_WIDTH / 4));
            mapX = this.MAP_WIDTH * xNum;
        }else if(playerX < -(this.MAP_WIDTH / 6)) {
            xNum = -(Math.floor(Math.abs(playerX) / (this.MAP_WIDTH / 5)));
            mapX = this.MAP_WIDTH * xNum;
        }

        if(playerY > this.MAP_HEIGHT / 6) { 
            yNum = Math.floor(playerY / (this.MAP_HEIGHT / 5));
            mapY = this.MAP_HEIGHT * yNum;
        }else if(playerY < -(this.MAP_HEIGHT / 6)) {
            yNum = -(Math.floor(Math.abs(playerY) / (this.MAP_HEIGHT / 4)));
            mapY = this.MAP_HEIGHT * yNum;
        }

        if(mapX == null || mapY == null) {
            return null;
        }


        let genMaps = [
        ]
        for(let i = 0; i < this.mapDirPositions.length;i++) {
            let dirPosition = this.mapDirPositions[i];
            let x = mapX + dirPosition.x;
            let y = mapY + dirPosition.y;
            let genMap = this.checkGenMap(x,y);
            if(genMap != null) {
                genMaps.push(genMap);
            }
        }

        return genMaps;
    }
    

    checkGenMap(mapX,mapY) {
        if(this.mapInfos[mapX + "_" + mapY] != null) {
            return null;
        }
        this.mapInfos[mapX + "_" + mapY] = {
            x:mapX,
            y:mapY
        };
        return {x:mapX,y:mapY};
    }

    /**
     * 加载地图资源到缓存
     */
    async initMapPic() {
        for(let i = 0;i < ChapterConfig.CONFIG.length;i++) {
            let chapterConfig:ChapterBasic = ChapterConfig.CONFIG[i];
            SpriteManager.getInstance().getSpriteFrame(chapterConfig.pic);
        }
    }
}
