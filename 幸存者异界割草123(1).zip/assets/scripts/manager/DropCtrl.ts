import DropConfig, { DropBasic } from "../config/DropConfig";
import BaseDrop from "../drop/BaseDrop";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DropCtrl {

    // 掉落队列,供给主类获取掉落物处理
    public dropQueue = [];

    // 每次获取的最多数量
    private genNum = 10;

    private static _instance: DropCtrl = null;

    public static getInstance() {
        if (!this._instance) {
            this._instance = new DropCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {
    }

    private _destroy() { }

    /**
     * 计算掉落
     * @param dropIds 
     */
    public calcDrop(pos:cc.Vec2,dropIds:any) {
        if(dropIds == null || dropIds.length == 0) {
            return;
        }
        
        for(let i = 0; i < dropIds.length;i++) {
            // 获取掉落配置
            let dropConfig:DropBasic = DropConfig.getConfigById(dropIds[i]);
            if(Math.random() > dropConfig.prob / 10000) {
                continue;
            }
            // 实际获得数量
            let randomNum = Math.floor(dropConfig.min + Math.random() * (dropConfig.max - dropConfig.min));
            this.dropQueue.push({
                itemId:dropConfig.itemId,
                num: randomNum,
                pos: pos,
                destroyType: dropConfig.destroyType,
                destroyContent: dropConfig.destroyContent,
            })

        }
    }

    /**
     * 获取需要生成的掉落物
     */
    public getGenDrop() {
        let dropList = [];
        if(this.dropQueue.length == 0) {
            return dropList;
        }

        // 返回数量
        let gemNum = this.genNum;
        if(this.genNum > this.dropQueue.length) {
            gemNum = this.dropQueue.length;
        }

        for(let i = 0; i < gemNum; i++) {
            // 取出掉落队列中的第一个
            dropList.push(this.dropQueue.shift());
        }

        return dropList;
    }
}
