import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";


export default class AudioManager {

    private static _instance: AudioManager = null;
    private _audios: any = {};

    public static getInstance() {
        if (!this._instance) {
            this._instance = new AudioManager();
            this._instance._init();
        }
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {

    }

    private _destroy() {

    }

    /**
     * 播放音频
     * @param path 音频路径
     * @param loop 是否循环播放
     */
    public async playerAudio(path,loop) {

        // 获取玩家系统设置
        let sysSetting = PlayerCacheCtrl.getInstance().getSysSetting();
        if(sysSetting == null || !sysSetting.audioStatus) {
            return;
        }

        let audioClip = await this.getAudioClip(path);
        if(audioClip == null) {
            return;
        }

        let volume = sysSetting.audioVolume;

        cc.audioEngine.play(audioClip,loop,volume);
    }

    /**
     * 停止所有音频
     */
    public async stopAllAudio() {
        cc.audioEngine.stopAll();
    }

    /**
     * 初始加载音频
     */
    public async initAllAudioClip() {
        this.getAudioClip(AudioPathKey.BOTTON_NAV_AUDIO);
        this.getAudioClip(AudioPathKey.OPEN_VIEW_AUDIO);
        this.getAudioClip(AudioPathKey.LEVEL_UP_AUDIO);
        this.getAudioClip(AudioPathKey.OPEN_VIEW_AUDIO);
        this.getAudioClip(AudioPathKey.GAIN.EXP);

        // this.getAudioClip(AudioPathKey.PET_SKILL.DRAGON_SKILL);
    }

    public async getAudioClip(path: string, superior: string = ""): Promise<cc.AudioClip> {
        return new Promise<cc.AudioClip>((resolve, reject) => {
            if (this._audios[path]) {

                resolve(this._audios[path]);
                return;
            }
            cc.resources.load(path, cc.AudioClip, (err, prefab) => {
                if (err) {
                    cc.log("getObjectNode err", err);
                    resolve(null);
                    return;
                }
                this._audios[path] = prefab;
                prefab.addRef()
                resolve(prefab as cc.AudioClip);
            });
        });
    }
}
