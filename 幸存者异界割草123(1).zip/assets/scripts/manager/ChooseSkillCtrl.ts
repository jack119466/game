// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import SpriteUtil from "../utils/SpriteUtil";

const {ccclass, property} = cc._decorator;

@ccclass
export default class ChooseSkillCtrl extends cc.Component {

    
    private static _instance: ChooseSkillCtrl = null;

    public static getInstance() {
        if (!this._instance) {
            this._instance = new ChooseSkillCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {
        // for (let key in SkillConfigConfig.datas) {
        //     let skillInfo: SkillConfigBasic = SkillConfigConfig.datas[key];
        //     this._playerCanSelectSkillList.push(skillInfo)
        // }
        // var items = ['1', '2', '4', '5', '6', '7', '8', '9', '10'];
        // console.log(this.getRandomArrayElements(items, 4));
        // this.addEnemyRoguelikeSkill(RoguelikeSkillConfig.datas[14])
    }

    private _destroy() { }

    @property(cc.Node)
    chooseSkillNode: cc.Node = null;

    @property(cc.Label)
    skillName1: cc.Label = null;
    @property(cc.Label)
    skillLevel1: cc.Label = null;
    @property(cc.Sprite)
    skillImage1: cc.Sprite = null;
    @property(cc.Label)
    skillDesc1: cc.Label = null;

    @property(cc.Label)
    skillName2: cc.Label = null;
    @property(cc.Label)
    skillLevel2: cc.Label = null;
    @property(cc.Sprite)
    skillImage2: cc.Sprite = null;
    @property(cc.Label)
    skillDesc2: cc.Label = null;

    @property(cc.Label)
    skillName3: cc.Label = null;
    @property(cc.Label)
    skillLevel3: cc.Label = null;
    @property(cc.Sprite)
    skillImage3: cc.Sprite = null;
    @property(cc.Label)
    skillDesc3: cc.Label = null;

    /**
     * 接收需要渲染的参数
     */
    public show(showData) {
        cc.log("技能选择控制类接收showData:",showData);
        // 数据渲染
        this.skillName1.string = showData.skillName1;
        this.skillLevel1.string = "等级:" + showData.skillLevel1;
        SpriteUtil._addSpritePic(this.skillImage1, showData.skillImage1);
        this.skillDesc1.string = showData.skillDesc1;

        this.skillName2.string = showData.skillName2;
        this.skillLevel2.string = "等级:" + showData.skillLevel2;
        SpriteUtil._addSpritePic(this.skillImage2, showData.skillImage2);
        this.skillDesc2.string = showData.skillDesc2;

        this.skillName3.string = showData.skillName3;
        this.skillLevel3.string = "等级:" + showData.skillLevel3;
        SpriteUtil._addSpritePic(this.skillImage3, showData.skillImage3);
        this.skillDesc3.string = showData.skillDesc3;

        this._show();
    }

    /**
     * 接收隐藏
     */
    public hide() {
        this._hidden();
    }

    private _show() {
        cc.log("_show before");

        this.chooseSkillNode.active = true;

        cc.log("_show after");

        // 暂停
        cc.director.pause();

        cc.log("_show pause");
    }

    private _hidden() {

        this.chooseSkillNode.active = false;

        // 启动
        cc.director.resume();
    }
}
