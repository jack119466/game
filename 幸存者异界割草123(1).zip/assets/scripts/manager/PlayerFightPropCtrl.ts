import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import GeneralConfig, { GeneralBasic } from "../config/GeneralConfig";
import GongConfig from "../config/GongConfig";
import PetConfig from "../config/PetConfig";
import PlayerLevelConfig, { PlayerLevelBasic } from "../config/PlayerLevelConfig";
import PlayerFightProp from "../prop/PlayerFightProp";
import LabelCtrl from "./LabelCtrl";

const { ccclass, property } = cc._decorator;

/**
 * 玩家战斗属性管理
 */
@ccclass
export default class PlayerFightPropCtrl {

    /**
     * 属性归属类型
     */
    public static PROP_TYPE = {
        PET: 1, // 伙伴
        GONG: 2, // 天赋
        SKILL: 3, // 技能
        GENERAL_LEVEL: 4, // 角色等级
        PLAYER_LEVEL: 5, // 阶级
    }

    public static _instance: PlayerFightPropCtrl = null; // 管理器实例

    public fightProp: PlayerFightProp = null; // 总战斗属性

    public playerLevelProp: PlayerFightProp = null; // 阶级提供属性

    public skillProp: PlayerFightProp = null; // 技能提供属性

    public playerGongProp: PlayerFightProp = null; // 天赋提供属性

    public playerGeneralProp: PlayerFightProp = null; // 角色等级提供属性

    public playerPetProp: PlayerFightProp = null; // 上阵伙伴提供属性

    private currHp: number = 0; // 当前生命

    private generalLevel: number = 1; // 角色等级

    private lastMaxHp: number = 0; // 上一次最大生命值

    /**
     * 计算玩家战斗属性
     */
    public initFightProp() {
        this.playerLevelProp = new PlayerFightProp();
        this.skillProp = new PlayerFightProp();
        this.playerGongProp = new PlayerFightProp();
        this.playerGeneralProp = new PlayerFightProp();
        this.fightProp = new PlayerFightProp();
        this.generalLevel = 1;


        // 玩家境界等级
        this.calcByPlayerLevelProp();

        // 玩家天赋
        this.calcByPlayerGongProp();

        // 玩家角色等级
        this.calcByGeneralLevelProp();

        // 玩家上阵伙伴
        this.calcByPlayerPetProp();

        // 计算总属性
        this.calcFightProp();

        this.currHp = this.fightProp.hp;
        this.lastMaxHp = this.fightProp.hp;
    }

    /**
     * 选择技能后重新计算玩家战斗属性
     */
    public calcFightPropBySkill() {
        this.fightProp = new PlayerFightProp();

        // 计算总属性
        this.calcFightProp();

        // 最大生命值是否增加了
        let addMaxHp = this.fightProp.hp - this.lastMaxHp;
        if (addMaxHp > 0) {
            this.showAddCurrHp(addMaxHp);
            this.currHp += addMaxHp;
            this.lastMaxHp = this.fightProp.hp;
        }

    }

    /**
     * 玩家境界等级参与属性计算
     * @param playerLevel 玩家境界等级
     */
    private calcByPlayerLevelProp() {
        let playerLevel = PlayerCacheCtrl.getInstance().getPlayerLevel();
        let prop: PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(playerLevel);
        this.playerLevelProp.atk += prop.atk;
        this.playerLevelProp.def += prop.def;
        this.playerLevelProp.hp += prop.hp;
        this.playerLevelProp.hpRecovery = prop.hpRecovery;
    }

    /**
    * 玩家天赋参与属性计算
    * @param 
    */
    private calcByPlayerGongProp() {
        let playerGong = PlayerCacheCtrl.getInstance().getPlayerGong();
        if (playerGong == null) {
            return null;
        }

        for (const key in playerGong) {
            let gongInfo = playerGong[key];
            let prop = GongConfig.getLevelUpPropById(gongInfo.id, gongInfo.level);
            if (prop) {
                this.addPropByType(PlayerFightPropCtrl.PROP_TYPE.GONG, prop.propName, prop.propNum, prop.propType);
            }
        }
    }

    /**
     * 玩家角色等级参与属性计算
     * @param playerLevel 玩家角色等级
     */
    private calcByGeneralLevelProp() {
        this.playerGeneralProp = new PlayerFightProp();
        let generalId = PlayerCacheCtrl.getInstance().getPlayerUseGeneral();
        let propList = GeneralConfig.getLevelPropById(generalId, this.generalLevel);
        for (let i = 0; i < propList.length; i++) {
            let prop = propList[i];
            this.addPropByType(PlayerFightPropCtrl.PROP_TYPE.GENERAL_LEVEL, prop.propName, prop.propNum, prop.propType);
        }

    }

    /**
    * 玩家伙伴参与属性计算
    * @param 
    */
    private calcByPlayerPetProp() {
        this.playerPetProp = new PlayerFightProp();

        let petId = PlayerCacheCtrl.getInstance().getPlayerUsePet();
        let petInfo = PlayerCacheCtrl.getInstance().getPlayerPetById(petId);
        if(petInfo == null) {
            return;
        }
        let propList = PetConfig.getLevelPropById(petId, petInfo.level);
        for (let i = 0; i < propList.length; i++) {
            let prop = propList[i];
            this.addPropByType(PlayerFightPropCtrl.PROP_TYPE.PET, prop.propName, prop.propNum, prop.propType);
        }
    }

    /**
    * 计算总战斗属性
    */
    private calcFightProp() {
        // 初始某些属性
        this.fightProp.initProp();

        for (const propName in this.fightProp) {
            this.fightProp[propName] += this.playerLevelProp[propName];
            this.fightProp[propName] += this.playerPetProp[propName];
            this.fightProp[propName] += this.skillProp[propName];
            this.fightProp[propName] += this.playerGongProp[propName];
            this.fightProp[propName] += this.playerGeneralProp[propName];
        }

        // 计算攻击提升率
        this.fightProp.atk = Math.floor(this.fightProp.atk * ((100 + this.fightProp.atkRate) / 100));

        // 计算防御提升率
        this.fightProp.def = Math.floor(this.fightProp.def * ((100 + this.fightProp.defRate) / 100));

        // 计算生命提升率
        this.fightProp.hp = Math.floor(this.fightProp.hp * ((100 + this.fightProp.hpRate) / 100));

        // 计算生命恢复提升率
        this.fightProp.hpRecovery = Math.floor(this.fightProp.hpRecovery * ((100 + this.fightProp.hpRecoveryRate) / 100));

        // 计算速度提升率
        this.fightProp.speed = Math.floor(this.fightProp.speed * ((100 + this.fightProp.speedRate) / 100));

    }

    /**
     * 增加玩家战斗属性
     * @param propType 属性归属类型
     * @param prop 属性字段
     * @param num 属性提升值
     * @param type 提升类型 1-数值叠加 2-提升百分比
     */
    public addPropByType(propType: number, prop: string, num: number, type: number) {
        let calcProp: PlayerFightProp = null;
        if(PlayerFightPropCtrl.PROP_TYPE.PET == propType) {
            calcProp = this.playerPetProp;
        }else if (PlayerFightPropCtrl.PROP_TYPE.SKILL == propType) {
            calcProp = this.skillProp;
        } else if (PlayerFightPropCtrl.PROP_TYPE.GONG == propType) {
            calcProp = this.playerGongProp;
        } else if (PlayerFightPropCtrl.PROP_TYPE.GENERAL_LEVEL == propType) {
            calcProp = this.playerGeneralProp;
        }
        if (calcProp == null) {
            return;
        }

        if (calcProp[prop] == null) {
            return;
        }

        if (num <= 0) {
            return;
        }

        let sourceProp = calcProp[prop]; //原有属性值
        let addNum = 0; // 本次提升属性值
        if (type == 1) {
            addNum = num
        } else if (type == 2) {
            addNum = Math.floor(sourceProp * num / 100);
        }
        calcProp[prop] = sourceProp + addNum; // 现有属性值
    }

    /**
     * 执行恢复当前生命
     */
    public execRecoveryCurrHp(num: number, type: number,isShow:boolean) {
        let addNum = 0;
        if (type == 1) {
            addNum = num;
        } else if (type = 2) {
            addNum = Math.floor(this.fightProp.hp * (num / 100));
        }

        if (addNum <= 0) {
            return;
        }

        // 超出生命上限
        if(this.currHp + addNum > this.fightProp.hp) {
            addNum = this.fightProp.hp - this.currHp;
        }

        if(addNum == 0) {
            return;
        }

        if(isShow) {
            this.showAddCurrHp(addNum);
        }
        
        let currHp = this.currHp + addNum;

        // 设置当前生命
        this.currHp = currHp;

    }

    /**
     * 渲染增加当前生命效果
     */
    showAddCurrHp(addHp:number) {
        LabelCtrl.getInstance().add(null,"+" + addHp,cc.Color.GREEN);
    }

    /**
     * 获取最大生命值
     */
    public getHp() {
        return this.fightProp.hp;
    }

    /**
     * 获取当前生命值
     */
    public getCurrHp() {
        return this.currHp;
    }

    /**
     * 设置当前生命值
     * @param currHp 当前生命值
     */
    public setCurrHp(currHp: number) {
        this.currHp = currHp;
    }

    /**
    * 设置当前角色等级,同时计算角色等级提供的属性
    * @param generalLevel 角色等级
    */
    public setGeneralLevel(generalLevel: number) {
        this.fightProp = new PlayerFightProp();
        this.generalLevel = generalLevel;
        this.calcByGeneralLevelProp();
        // 计算总属性
        this.calcFightProp();
    }

    /**
     * 获取当前生命恢复
     */
    public getHpRecovery() {
        return this.fightProp.hpRecovery;
    }


    /**
     * 获取当前攻击力
     */
    public getAtk() {
        return this.fightProp.atk;
    }

    /**
     * 获取当前防御力
     */
    public getDef() {
        return this.fightProp.def;
    }

    /**
     * 获取移动速度
     */
    public getSpeed() {
        return this.fightProp.speed;
    }

    /**
     * 获取当前拾取范围
     */
    public getGainRange() {
        // 计算拾取范围提升
        let range = Math.floor(this.fightProp.gainRange * ((100 + this.fightProp.gainRangeRate) / 100));
        return range;
    }

    /**
     * 复活  恢复100%血量
     */
    public revive() {
        this.execRecoveryCurrHp(100,2,true);
    }


    public static getInstance() {
        if (!this._instance) {
            this._instance = new PlayerFightPropCtrl();
            this._instance._init();
        }

        return this._instance;
    }

    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }

    private _init() {
    }

    private _destroy() { }
}
