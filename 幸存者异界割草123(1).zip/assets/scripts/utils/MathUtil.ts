// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class MathUtil  {

    /**
     * 获取xy轴坐标
     * @param x 目标x
     * @param y 目标y
     * @param radius 半径
     * @param angle 角度
     */
    public static getXy(x:number,y:number,radius:number,angle:number) {
        let x1 = x + radius * Math.sin(angle * Math.PI / 180)
        let y1 = y + radius * Math.cos(angle * Math.PI / 180)
        return [y1,x1];
    }

    /**
     * 获取到原点的xy轴坐标
     * @param radius 半径
     * @param angle 角度
     */
     public static getXyToZero(radius:number,angle:number) {
        return this.getXy(0,0,radius,angle);
    }
}
