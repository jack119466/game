const {ccclass, property} = cc._decorator;

@ccclass
export default class RandomUtil {

    /**按权重随产生机值,返回随机到的对象
     * weights_arr{
     * weight:10,
     * }
    */
    public static RandomByWeight(weights_arr) {
        var total_weight = weights_arr.reduce((total, w) => { return total + w.weight }, 0);
        var rand = Math.random() * total_weight;
        for (var i = 0; i < weights_arr.length; i++) {
            rand = rand - Number(weights_arr[i].weight);
            if (rand <= 0) {
                return weights_arr[i];
            }
        }
    }
}
