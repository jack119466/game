// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class PositionUtil{
    public static calculationDis(localPos,tarPos){
        let dx = localPos.x - tarPos.x;
        
        let dy = localPos.y - tarPos.y;
        
        let dis = Math.sqrt(dx*dx + dy*dy);
        return dis;
    } 
}
