// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import ItemConfig from "../config/ItemConfig";
import PlayerLevelConfig, { PlayerLevelBasic } from "../config/PlayerLevelConfig";
import AudioManager from "../manager/AudioManager";
import SdkCtrl from "../manager/SdkCtrl";
import AdvertUtil from "../utils/AdvertUtil";
import PlatformUtil from "../utils/PlatformUtil";
import IndexCtrl from "./IndexCtrl";
import TipCtrl from "./TipCtrl";

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    atkNum: cc.Label = null;

    @property(cc.Label)
    defNum: cc.Label = null;

    @property(cc.Label)
    hpNum: cc.Label = null;

    @property(cc.Label)
    hpRecoveryNum: cc.Label = null;

    @property(cc.Label)
    cost: cc.Label = null;

    @property(cc.Label)
    adGainLabel: cc.Label = null;

    start() {
        this.init();
    }

    init() {
        this.node.parent.parent.getComponent(IndexCtrl).resetGoldNumLabel();
        // 渲染等级属性
        let playerLevel = PlayerCacheCtrl.getInstance().getPlayerLevel();
        let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(playerLevel);
        if(playerLevelConfig == null) {
            return;
        }

        this.atkNum.string = playerLevelConfig.atk + "";
        this.defNum.string = playerLevelConfig.def + "";
        this.hpNum.string = playerLevelConfig.hp + "";
        this.hpRecoveryNum.string = playerLevelConfig.hpRecovery + "";
        this.cost.string = "消耗金币*" + playerLevelConfig.levelUpCost;

        this.adGainLabel.string = "获得金币*" + playerLevelConfig.adGain;

    }

    levelUp() {
        // 渲染等级属性
        let playerLevel = PlayerCacheCtrl.getInstance().getPlayerLevel();
        let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(playerLevel);
        if(playerLevelConfig == null) {
            TipCtrl.getInstance().tip(this.node,"未找到当前强化等级配置");
            return;
        }

        // 下一等级
        let nextLevel = playerLevel + 1;
        let nextPlayerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(nextLevel);
        if(nextPlayerLevelConfig == null) {
            TipCtrl.getInstance().tip(this.node,"下一强化等级暂未开放");
            return;
        }

        let costItemCount = playerLevelConfig.levelUpCost;
        let costFlag = PlayerCacheCtrl.getInstance().costPlayerItem(Number(ItemConfig.ITEM_CONST.GOLD),costItemCount);
        if(!costFlag) {
            TipCtrl.getInstance().tip(this.node,"当前金币不足以强化");
            return;
        }

        // 提升等级
        PlayerCacheCtrl.getInstance().addPlayerLevel(1);
        TipCtrl.getInstance().tip(this.node,"强化成功,属性得到提升");
        AudioManager.getInstance().playerAudio(AudioPathKey.LEVEL_UP_AUDIO,false);

        // 重新渲染
        this.init();
    }

    adGain() {
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            let playerLevel = PlayerCacheCtrl.getInstance().getPlayerLevel();
            let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(playerLevel);
            if(playerLevelConfig == null) {
                return;
            }
    
            let addItemCount = playerLevelConfig.adGain;
    
            let addFlag = PlayerCacheCtrl.getInstance().addPlayerItem(Number(ItemConfig.ITEM_CONST.GOLD),addItemCount);
            if(!addFlag) {
                TipCtrl.getInstance().tip(this.node,"增加金币失败,请联系作者");
                return;
            }
            // 重新渲染
            this.init();
        })
        
    }
}
