import CacheUtil from "../cache/CacheUtil";
import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import CacheKey from "../config/CacheKey";
import ChapterConfig, { ChapterBasic } from "../config/ChapterConfig";
import SceneKey from "../config/SecenKey";
import AudioManager from "../manager/AudioManager";
import SdkCtrl from "../manager/SdkCtrl";
import ButtonUtil from "../utils/ButtonUtil";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GongCtrl extends cc.Component {

    @property(cc.Prefab)
    chapterPrefab:cc.Prefab = null;

    @property(cc.Node)
    chapterParentNode:cc.Node = null;

    @property(cc.Node)
    chapterDescNode:cc.Node = null;
    
    @property(cc.Label)
    chapterDescLabel:cc.Label = null;
    
    @property(cc.Label)
    chapterMonsterDescLabel:cc.Label = null;

    @property(cc.Node)
    maskNode:cc.Node = null;

    onEnable() {
        this.init();
    }

   
    init() {
        // 关卡父节点归位，清空所有子节点
        this.chapterParentNode.setPosition(cc.v2(0,0));
        this.chapterParentNode.removeAllChildren();

        for(let i = 0; i < ChapterConfig.CONFIG.length; i++ ) {
            let chapterConfig:ChapterBasic = ChapterConfig.CONFIG[i];
            this.initShow(chapterConfig);
        }

        // 调整初始显示的区域
        if(ChapterConfig.CONFIG.length > 5) {
            // 玩家当前通关数
            let playerChapter = PlayerCacheCtrl.getInstance().getChapter();
            // 移动到玩家当前最新关卡
            let yLen = 220;
            let subNum = playerChapter - (ChapterConfig.CONFIG.length / 2) + 1;
            let chapterParentNodeY = yLen * subNum;
            this.chapterParentNode.setPosition(cc.v2(0,chapterParentNodeY));
        }
    }

    initShow(chapterConfig:ChapterBasic) {
        // 创建一个关卡
        let chapterNode:cc.Node = cc.instantiate(this.chapterPrefab);

        // 关卡名称
        let sceneName:cc.Label = chapterNode.getChildByName("sceneName").getComponent(cc.Label);
        sceneName.string = chapterConfig.name;      

        // 关卡小节名
        let levelName:cc.Label = chapterNode.getChildByName("levelName").getComponent(cc.Label);
        levelName.string = chapterConfig.levelName;      

        // 玩家通关关卡
        let playerChapter = PlayerCacheCtrl.getInstance().getChapter();

        // 通关数+1 可以进入关卡
        if(playerChapter + 1 >= chapterConfig.id) {

            // 隐藏锁节点
            chapterNode.getChildByName("lock").active = false;

            // 关卡的进入按钮节点
            let enterButtonNode:cc.Button = chapterNode.getChildByName("enterButton").getComponent(cc.Button);

            // 给按钮增加事件
            ButtonUtil._setEvent(this.node,enterButtonNode,"FightCtrl","enterFight",chapterConfig.id + "");

            enterButtonNode.node.active = true;
        }
        
        // 关卡的介绍按钮节点
        let descButtonNode:cc.Button = chapterNode.getChildByName("descButton").getComponent(cc.Button);
        // 给介绍按钮增加事件
        ButtonUtil._setEvent(this.node,descButtonNode,"FightCtrl","showChapterDesc",chapterConfig.id + "");

        this.chapterParentNode.addChild(chapterNode);

        chapterNode.active = true;
    }

    
    /**
     * 进入游戏关卡
     * @param event 按钮事件
     * @param customEventData 关卡数据
     */
    enterFight(event,customEventData) {
        
        CacheUtil.getInstance().set(CacheKey.FIGHT_CHAPTER,customEventData);

        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);

        // 加载游戏场景
        cc.director.loadScene(SceneKey.FIGHT);

        // SdkCtrl.getInstance().HideBanner();

        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);
    }

    /**
     * 展示关卡介绍界面
     * @returns 
     */
    showChapterDesc(event,customEventData) {
        // 渲染
        let chapter = ChapterConfig.getConfigById(Number(customEventData));
        this.chapterDescLabel.string = chapter.desc;
        this.chapterMonsterDescLabel.string = chapter.monsterParam.desc;
        this.chapterDescNode.active = true;
        this.maskNode.active = true;

        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);
    }

    /**
     * 关闭关卡介绍界面
     * @returns 
     */
    closeChapterDesc() {
        this.chapterDescNode.active = false;
        this.maskNode.active = false;
    }


}
