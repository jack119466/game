const {ccclass, property} = cc._decorator;

/**
 * 伙伴AI控制器
 */
@ccclass
export default class NewClass extends cc.Component {

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    private max = 40;

    private min = 20;

    private dir = 1;

    private speed = 0.3;

    // start () {

    // }

    update (dt) {
        let oldY = this.node.getPosition().y;
        if(oldY >= this.max) {
            this.dir = -1;
        }else if(oldY <= this.min) {
            this.dir = 1;
        }

        oldY = oldY + (this.dir * this.speed);
        this.node.setPosition(cc.v2(-24.5,oldY));
    }
}
