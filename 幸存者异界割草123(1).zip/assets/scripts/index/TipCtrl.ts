
import TipLabelCtrl from "../common/TipLabelCtrl";
import UiPathKey from "../config/UiPathKey";
import ObjectManager from "../manager/ObjectManager";

const {ccclass, property} = cc._decorator;

@ccclass
export default class TipCtrl extends cc.Component {

    private static _instance: TipCtrl = null;

    public static getInstance() {
        if (!this._instance) {
            this._instance = new TipCtrl();
            this._instance._init();
        }
        
        return this._instance;
    }
   
    public static destroyInstance() {
        if (this._instance) {
            this._instance._destroy();
            delete this._instance;
            this._instance = null;
        }
    }
    
    private _init() {
    }
    
    private _destroy() { }

    /**
     * 提示信息，  后面找个其他公用地方放置
     * @param parentNode 父节点
     * @param content 提示内容
     */
    public async tip(parentNode,content) {
        let duration = 1000; // 临时设置1秒
        let prefab = await ObjectManager.getInstance().getObjectPrefab(UiPathKey.TIP_PREFAB);
        let tip = cc.instantiate(prefab);
        tip.getComponent(TipLabelCtrl).init(content,duration);
        parentNode.addChild(tip);
        tip.active = true;
    }
}
