
import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import GeneralConfig, { GeneralBasic } from "../config/GeneralConfig";
import SpriteUtil from "../utils/SpriteUtil";
import SkillConfig from "../config/SkillConfig";
import ButtonUtil from "../utils/ButtonUtil";
import CommonConfig from "../config/CommonConfig";
import UnlockManager from "../manager/UnlockManager";
import TipCtrl from "./TipCtrl";
import AudioManager from "../manager/AudioManager";
import AudioPathKey from "../config/AudioPathKey";
import IndexCtrl from "./IndexCtrl";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GeneralCtrl extends cc.Component {

    @property(cc.Node)
    generalParentNode:cc.Node = null; // 角色父节点

    @property(cc.Prefab)
    generalPrefab:cc.Prefab = null; // 角色信息预制体

    @property(cc.Sprite)
    generalOpPic:cc.Sprite = null; // 角色操作中的图片

    @property(cc.Label)
    generalOpName:cc.Label = null; // 角色操作中的名称

    @property(cc.Label)
    generalOpDesc:cc.Label = null; // 角色操作中的介绍

    @property(cc.Label)
    generalOpSkill:cc.Label = null; // 角色操作中的初始法宝

    @property(cc.Button)
    useGeneralButton:cc.Button = null; // 上阵角色

    @property(cc.Button)
    unlockButton:cc.Button = null; // 获得按钮节点

    @property(cc.Label)
    unlockLabel:cc.Label = null; // 获得途径说明节点

    start () {
    }
    
    onEnable() {
        // 渲染当前上阵的角色信息，如果没有则渲染第一个角色
        let generalId = PlayerCacheCtrl.getInstance().getPlayerUseGeneral();
        this.init(generalId);
    }

    init(chooseGeneralId:number) {
        this.node.parent.parent.getComponent(IndexCtrl).resetGoldNumLabel();
        this.generalParentNode.removeAllChildren();

        // 渲染列表
        for(let i = 0; i < GeneralConfig.CONFIG.length; i++) {
            let generalConfig:GeneralBasic = GeneralConfig.CONFIG[i];
            this.initShow(generalConfig,chooseGeneralId);
        }

        // 渲染角色操作
        this.resetGeneralOp(chooseGeneralId);
    }

    initShow(generalConfig:GeneralBasic,chooseGeneralId:number) {
        let general = cc.instantiate(this.generalPrefab);

        // 选择状态
        let chooseNode:cc.Node = general.getChildByName("choose");
        chooseNode.active = false;
        if(generalConfig.id == chooseGeneralId) {
            chooseNode.active = true;
        }

        let generalLevelLabel = "待开放";
        let labelColor = cc.Color.GRAY;
        if(CommonConfig.ENABLE_STATUS.ENABLED == generalConfig.status) {
            generalLevelLabel = "未获得";
            labelColor = cc.Color.RED;
            
            // 渲染点击事件
            let button = general.getComponent(cc.Button);
            ButtonUtil._setEvent(this.node,button,"GeneralCtrl","chooseGeneral",generalConfig.id+"");
          
            let playerGeneral = PlayerCacheCtrl.getInstance().getPlayerGeneralById(generalConfig.id);
            if(playerGeneral != null) {
                generalLevelLabel = "已获得";
                labelColor = cc.Color.BLACK;
            }
        }

        // 渲染图片
        let generalPic:cc.Sprite = general.getChildByName("pic").getComponent(cc.Sprite);
        generalPic.node.width = generalConfig.picRes.width;
        generalPic.node.height = generalConfig.picRes.height;
        SpriteUtil._addSpritePic(generalPic,generalConfig.picRes.uri);

        // 渲染介绍
        let generalLabel:cc.Label = general.getChildByName("level").getComponent(cc.Label);
        generalLabel.string = generalLevelLabel;
        generalLabel.node.color = labelColor;

        this.generalParentNode.addChild(general);

    } 

    resetGeneralOp(generalId:number) {
        let generalConfig = GeneralConfig.getConfigById(generalId);

        // 角色图片
        let picUri = generalConfig.picRes.uri;
        SpriteUtil._addSpritePic(this.generalOpPic,picUri);

        this.generalOpName.string = generalConfig.name;
        this.generalOpDesc.string = generalConfig.desc;

        let skillName = SkillConfig.getTypeName(generalConfig.initSkillType + "");
        this.generalOpSkill.string = skillName;

        let playerGeneral = PlayerCacheCtrl.getInstance().getPlayerGeneralById(generalConfig.id);
        
        this.unlockButton.node.active = false;
        this.useGeneralButton.node.active = false;
        if(playerGeneral == null) {
            // 如果未解锁，隐藏上阵按钮，显示解锁按钮和解锁条件
            this.unlockLabel.string = UnlockManager.getInstance().getUnlockDesc(generalConfig.unlockType,generalConfig.unlockContent);
            ButtonUtil._setEvent(this.node,this.unlockButton,"GeneralCtrl","gainGeneral",generalConfig.id + "");
            this.unlockButton.node.active = true;
        }else if(CommonConfig.USE_STATUS.USED == playerGeneral.useStatus) {
            this.useGeneralButton.interactable = false;
            this.useGeneralButton.node.active = true;
            this.useGeneralButton.node.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = "已上阵";
        }else {
            // 已解锁并且未使用的角色可以进行使用操作
            // 添加点击事件
            ButtonUtil._setEvent(this.node,this.useGeneralButton,"GeneralCtrl","useGeneral",generalConfig.id + "");
            this.useGeneralButton.interactable = true;
            this.useGeneralButton.node.active = true;
            this.useGeneralButton.node.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = "上阵";
        
        }
    }

   
    /**
     * 使用角色
     * @param event 
     * @param customEventData 角色ID
     */
    public useGeneral(event,customEventData) {
        let generalId = Number(customEventData);

        let generalConfig = GeneralConfig.getConfigById(generalId);
        if(generalConfig == null) {
            return;
        }

        let playerGeneral = PlayerCacheCtrl.getInstance().getPlayerGeneralById(generalId);
        if(playerGeneral == null ||
            CommonConfig.UNLOCK_STATUS.LOCK == playerGeneral.unlockStatus || 
            CommonConfig.USE_STATUS.USED == playerGeneral.useStatus) {
                return;
        }
        TipCtrl.getInstance().tip(this.node,"上阵角色：" + generalConfig.name);
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
        PlayerCacheCtrl.getInstance().playerUseGeneral(generalId);

        this.init(generalId); // 使用完角色后重新渲染
    }

    /**
     * 选中角色位置 
     * @param event 
     * @param customEventData 0-6
     */
    public chooseGeneral(event,customEventData) {
        let generalId =  Number(customEventData);
        if(GeneralConfig.getConfigById(generalId) == null) {
            return;
        }
        this.init(generalId);
    }

     /**
     * 获得角色
     * @param event 
     * @param customEventData 角色ID 
     */
    public gainGeneral(event,customEventData) {
        let generalId = Number(customEventData);

        let generalConfig = GeneralConfig.getConfigById(generalId);
        if(generalConfig == null) {
            TipCtrl.getInstance().tip(this.node,"角色信息不存在");
            return;
        }

        let unlockRst = UnlockManager.getInstance().unlock(generalConfig.unlockType,generalConfig.unlockContent);
        if(!unlockRst) {
            TipCtrl.getInstance().tip(this.node,"条件未满足，获得角色失败");
            return;
        }

        // 获得新角色
        PlayerCacheCtrl.getInstance().addGeneral(generalId,false);
        
        TipCtrl.getInstance().tip(this.node,"获得角色：" + generalConfig.name);

        AudioManager.getInstance().playerAudio(AudioPathKey.LEVEL_UP_AUDIO,false);

        // this.usePet(null,petId);

        // 默认选中刚获得的角色
        this.init(generalId);
    }
}
