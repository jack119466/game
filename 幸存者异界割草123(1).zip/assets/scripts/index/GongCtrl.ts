import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import GongConfig, { GongBasic } from "../config/GongConfig";
import ItemConfig, { ItemBasic } from "../config/ItemConfig";
import UiPathKey from "../config/UiPathKey";
import AudioManager from "../manager/AudioManager";
import ButtonUtil from "../utils/ButtonUtil";
import SpriteUtil from "../utils/SpriteUtil";
import IndexCtrl from "./IndexCtrl";
import TipCtrl from "./TipCtrl";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GongCtrl extends cc.Component {

    @property(cc.Node)
    gongParentNode:cc.Node = null; // 天赋父节点

    @property(cc.Prefab)
    gongPrefab:cc.Prefab = null; // 天赋预制体
    
    @property(cc.Prefab)
    levelStatusPrefab:cc.Prefab = null; // 等级状态预制体

    onEnable() {
        this.init();
    }

    init() {
        this.node.parent.parent.getComponent(IndexCtrl).resetGoldNumLabel();
        this.gongParentNode.removeAllChildren();
        for(let i = 0; i < GongConfig.CONFIG.length;i++) {
            let gongConfig:GongBasic = GongConfig.CONFIG[i];
            this.initShow(gongConfig);
        }

        
        // 调整初始显示的区域
        if(GongConfig.CONFIG.length > 5) {
            let yLen = 180;
            let subNum = 4;
            let gongParentNodeY = yLen * subNum * -1;
            this.gongParentNode.setPosition(cc.v2(0,gongParentNodeY));
        }
    }

    /**
     * 渲染
     */
    initShow(gongConfig:GongBasic) {
        let gong = cc.instantiate(this.gongPrefab);

        // 天赋名称
        let gongName:cc.Label = gong.getChildByName("gongName").getComponent(cc.Label);
        gongName.string = gongConfig.name;

        // 天赋介绍
        let gongDesc:cc.Label = gong.getChildByName("gongDesc").getComponent(cc.Label);
        gongDesc.string = gongConfig.desc;

        // 天赋图片
        let gongPic:cc.Sprite = gong.getChildByName("gongPic").getComponent(cc.Sprite);
        SpriteUtil._addSpritePic(gongPic,gongConfig.picRes)

        // 天赋图片
        let gongLevelNode:cc.Node = gong.getChildByName("gongLevel");
        SpriteUtil._addSpritePic(gongPic,gongConfig.picRes)
        let levelList = GongConfig.getLevelListById(gongConfig.id);
        let playerGongLevel = PlayerCacheCtrl.getInstance().getPlayerGongLevelById(gongConfig.id);
        let posList = GongConfig.LEVEL_STATUS_POS[levelList.length-1]; // 天赋等级数量对应的位置
        for(let i = 0; i < levelList.length; i++) {
            let levelInfo = levelList[i];
            // 创建等级节点
            let levelStatus = cc.instantiate(this.levelStatusPrefab);
            if(playerGongLevel >= levelInfo.level) {
                // 替换图片
                let levelStatusPic:cc.Sprite = levelStatus.getComponent(cc.Sprite);
                SpriteUtil._addSpritePic(levelStatusPic,UiPathKey.TALENT_LEVEL_STATUS_BG.ENABLE);
            }
            let pos = posList[i];
            levelStatus.setPosition(cc.v2(pos,0));
            gongLevelNode.addChild(levelStatus);
            levelStatus.active = true;
        }

        // // 天赋按钮事件
        let gongLevelUpButton:cc.Button = gong.getChildByName("levelUpButton").getComponent(cc.Button);
        let gongLevelUpLabel:cc.Label = gong.getChildByName("levelUpButton").getChildByName("Background").getChildByName("levelUpLabel").getComponent(cc.Label);

        // 玩家天赋等级已经最大则提示满级且按钮禁用
        if(playerGongLevel >= levelList.length) {
            gongLevelUpLabel.string = "已满级";
            gongLevelUpButton.interactable = false;
        }else {
            let costItem = GongConfig.getLevelUpCostById(gongConfig.id,playerGongLevel + 1);
            let itemName = ItemConfig.getConfigById(costItem.itemId).name;
            let costLabel:cc.Label = gong.getChildByName("costLabel").getComponent(cc.Label);
            costLabel.string = "消耗"+itemName+"*"+costItem.itemCount;
            costLabel.node.active = true;
            ButtonUtil._setEvent(this.node,gongLevelUpButton,"GongCtrl","gongLevelUp",gongConfig.id + "");
        }

        this.gongParentNode.addChild(gong);
        gong.active = true;


    }

    /**
     * 天赋升级
     * @param event 
     * @param customEventData 天赋ID 
     */
    gongLevelUp(event,customEventData) {
        if(customEventData == null) {
            return;
        }

        let gongId = Number(customEventData);
        let gongConfig:GongBasic = GongConfig.getConfigById(gongId);
        if(gongConfig == null) {
            cc.log("天赋配置不存在,id:",gongId);
            return;
        }

        // 玩家该天赋等级
        let playerGongLevel = PlayerCacheCtrl.getInstance().getPlayerGongLevelById(gongId);
        // 下一级别
        let nextLevel = playerGongLevel + 1;
        if(nextLevel > GongConfig.getLevelListById(gongId)) {
            cc.log("天赋%s级别%s配置不存在:",gongId,nextLevel);
            return;
        }

        // 扣除资源
        let costItem = GongConfig.getLevelUpCostById(gongId,nextLevel);
        cc.log("查看天赋等级需要扣除的资源 id:%s,level:%s",gongId,nextLevel);
        cc.log("costItem:",costItem);
        let costFlag = PlayerCacheCtrl.getInstance().costPlayerItem(costItem.itemId,costItem.itemCount);
        if(!costFlag) {
            cc.log("天赋升级扣除资源失败,costItem:",costItem);
            TipCtrl.getInstance().tip(this.node,"当前金币不足以升级");
            return;
        }

        // 数据操作
        PlayerCacheCtrl.getInstance().plyerGongLevelUp(gongId);

        AudioManager.getInstance().playerAudio(AudioPathKey.LEVEL_UP_AUDIO,false);
        
        // 渲染
        this.init();
    }
}
