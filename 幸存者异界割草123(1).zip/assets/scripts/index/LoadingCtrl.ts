// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import AudioPathKey from "../config/AudioPathKey";
import GeneralConfig from "../config/GeneralConfig";
import SceneKey from "../config/SecenKey";
import AudioManager from "../manager/AudioManager";
import SdkCtrl from "../manager/SdkCtrl";

const {ccclass, property} = cc._decorator;

@ccclass
export default class LoadingCtrl extends cc.Component {

    @property(cc.ProgressBar)
    loadingProgressBar: cc.ProgressBar = null;

    @property(cc.Label)
    loadingLabel: cc.Label = null;

    @property(cc.Label)
    loadingPer: cc.Label = null;

    private currTime:number = 0; // 当前时间，秒

    private loadingUseTime:number = 10000; // 加载场景大概需要消耗时间,毫秒

    private loadingStatus = 0; // 加载状态，只有当加载状态为1时，进度条与进度文本才完成，并且设置加载状态为2，2代表可以跳转到主页了

    onLoad () {
    }

    start () {
        SdkCtrl.getInstance().showShareMenu();

        GeneralConfig.loadConfigMap();

        // 预加载主页场景
        this.loadingLabel.string = "主场景加载中";
        var that = this;
        cc.director.preloadScene(SceneKey.INDEX, function () {
            cc.log("主场景加载完成");
            that.loadingLabel.string = "战斗场景加载中";
            // 预加载战斗场景
            cc.director.preloadScene(SceneKey.FIGHT, function () {
                that.loadingStatus = 1; // 进度条可以渲染100%了
                cc.log("战斗场景加载完成");
            });
        });
    }

    update (dt) {
        // 是否已经完成加载
        if(this.loadingStatus == 2) {
            
            // 跳转到主页
            cc.director.loadScene(SceneKey.INDEX);

            return;
        }

        this.currTime += dt;

        this.resetPer();

    }

    // 设置加载进度条
    resetPer() {
        // 如果加载未完成，则最多到99%
        if(this.loadingStatus == 0 && this.currTime * 1000 >= this.loadingUseTime) {
            return;
        }
        
        let per = 0;
        if(this.loadingStatus == 0) {
            per = this.currTime * 1000 / this.loadingUseTime;
            if(per >= 1) {
                return;
            }
        }else if(this.loadingStatus == 1) {
            per = 1;
        }else {
            return;
        }
        
        this.loadingProgressBar.progress = per;
        this.loadingPer.string = (per * 100).toFixed(1) + "%";

        if(per == 1) {
            this.scheduleOnce(() => {
                this.loadingStatus = 2; // 可以跳转到主页了
            },0.2);
        }
    }

    ok() {
        this.loadingStatus = 1;
    }
}
