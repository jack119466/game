import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import CommonConfig from "../config/CommonConfig";
import GlobalConfig from "../config/GlobalConfig";
import ItemConfig from "../config/ItemConfig";
import PetConfig, { PetBasic } from "../config/PetConfig";
import AnimationManger from "../manager/AnimationManager";
import AudioManager from "../manager/AudioManager";
import LabelCtrl from "../manager/LabelCtrl";
import UnlockManager from "../manager/UnlockManager";
import ButtonUtil from "../utils/ButtonUtil";
import RandomUtil from "../utils/RandomUtil";
import SpriteUtil from "../utils/SpriteUtil";
import TipCtrl from "./TipCtrl";

const { ccclass, property } = cc._decorator;

@ccclass
export default class PetCtrl extends cc.Component {

    @property(cc.Label)
    petName:cc.Label = null; // 伙伴名称

    @property(cc.Label)
    petDesc:cc.Label = null; // 伙伴介绍

    @property(cc.Node)
    opNode:cc.Node = null; // 操作节点

    @property(cc.Node)
    centerPic:cc.Node = null; // 伙伴中心图
    
    @property(cc.Button)
    useButton:cc.Button = null; // 上阵按钮节点

    @property(cc.Button)
    unlockButton:cc.Button = null; // 获得按钮节点

    @property(cc.Label)
    unlockLabel:cc.Label = null; // 获得途径说明节点

    @property(cc.Node)
    petParentNode:cc.Node = null; // 伙伴列表父节点

    @property(cc.Prefab)
    petPrefab:cc.Prefab = null; // 伙伴预制体


    onEnable() {
        // 渲染当前上阵的伙伴信息，如果没有则渲染第一个伙伴
        let petId = PlayerCacheCtrl.getInstance().getPlayerUsePet();
        this.init(petId);
    }

    init(choosePetId:number) {
        
        this.petParentNode.removeAllChildren();

        // 渲染底部列表
        for(let i = 0; i < PetConfig.CONFIG.length;i++) {
            let petConfig:PetBasic = PetConfig.CONFIG[i];
            this.initShow(petConfig,choosePetId);
        }

        // 渲染顶部
        this.resetPetInfo(null,choosePetId);

        // 渲染伙伴中心动图
        this.resetPetOp(choosePetId);
        
    }


    /**
     * 渲染伙伴中心动图
     */
    resetPetOp(petId:number) {
        let petConfig = PetConfig.getConfigById(petId);
        
        // 伙伴图片
        let picUri = petConfig.picRes.uri;
        let pic = this.centerPic.getComponent(cc.Sprite);
        SpriteUtil._addSpritePic(pic,picUri);

        // 伙伴飞行动画
        let flyAniAddress = petConfig.animationRes.fly;
        let ani:cc.Animation = this.centerPic.getComponent(cc.Animation);
        this.setAnimation(ani,flyAniAddress);
        let playerPet = PlayerCacheCtrl.getInstance().getPlayerPetById(petId);

        if(playerPet == null) {
            this.unlockButton.node.active = true;
            this.unlockLabel.string = UnlockManager.getInstance().getUnlockDesc(petConfig.unlockType,petConfig.unlockContent);
            ButtonUtil._setEvent(this.node,this.unlockButton,"PetCtrl","gainPet",petId+"");
            
            this.useButton.node.active = false;
        }else if(CommonConfig.USE_STATUS.USED == playerPet.useStatus) {
            this.unlockButton.node.active = false;
            this.useButton.interactable = false;
            this.useButton.node.active = true;
            this.useButton.node.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = "已上阵";
        }else {
            this.unlockButton.node.active = false;
            this.useButton.node.active = true;
            ButtonUtil._setEvent(this.node,this.useButton,"PetCtrl","usePet",petId+"");
        }
    }

    // 设置伙伴飞行动画并播放
    async setAnimation(ani,flyAniAddress) {
        let animationClip = await AnimationManger.getInstance().getAnimationClipsByName(ani,flyAniAddress);
        ani._clips = [];
        ani.addClip(animationClip);
        ani.play("fly");
    }

    /**
     * 渲染列表
     * @param petConfig 伙伴配置
     * @param choosePetId 选择的伙伴
     */
    initShow(petConfig:PetBasic,choosePetId:number) {
        let pet = cc.instantiate(this.petPrefab);

        // 选择状态
        let chooseNode:cc.Node = pet.getChildByName("choose");
        chooseNode.active = false;
        if(petConfig.id == choosePetId) {
            chooseNode.active = true;
        }

        let petLevelLabel = "待开放";
        if(CommonConfig.ENABLE_STATUS.ENABLED == petConfig.status) {
            petLevelLabel = "未获得";
            let playerPet = PlayerCacheCtrl.getInstance().getPlayerPetById(petConfig.id);
            if(playerPet != null) {
                petLevelLabel = "已获得";
            }
        }

        // 渲染图片
        let petPic:cc.Sprite = pet.getChildByName("pic").getComponent(cc.Sprite);
        petPic.node.width = petConfig.picRes.width;
        petPic.node.height = petConfig.picRes.height;
        SpriteUtil._addSpritePic(petPic,petConfig.picRes.uri);


        // 渲染等级
        let petLevel:cc.Label = pet.getChildByName("level").getComponent(cc.Label);
        petLevel.string = petLevelLabel;

        this.petParentNode.addChild(pet);

    }

    // 重新设置当前玩家选择的伙伴信息
    resetPetInfo(event,petId) {
        let petConfig = PetConfig.getConfigById(petId)
        if(petConfig == null) {
            return;
        }
        this.petName.string = petConfig.name;
        this.petDesc.string = petConfig.desc;
    }

     /**
     * 获得伙伴
     * @param event 
     * @param customEventData 伙伴ID 
     */
    public gainPet(event,customEventData) {
        let petId = Number(customEventData);

        let petConfig = PetConfig.getConfigById(petId);
        if(petConfig == null) {
            TipCtrl.getInstance().tip(this.node,"伙伴信息不存在");
            return;
        }

        let unlockRst = UnlockManager.getInstance().unlock(petConfig.unlockType,petConfig.unlockContent);
        if(!unlockRst) {
            TipCtrl.getInstance().tip(this.node,"条件未满足，获得伙伴失败");
            return;
        }

        // 获得新伙伴
        PlayerCacheCtrl.getInstance().addPet(petId,false);
        
        TipCtrl.getInstance().tip(this.node,"获得伙伴：" + petConfig.name);

        AudioManager.getInstance().playerAudio(AudioPathKey.LEVEL_UP_AUDIO,false);

        // this.usePet(null,petId);

        this.init(PlayerCacheCtrl.getInstance().getPlayerUsePet());
    }

    /**
     * 上阵伙伴
     * @param event 
     * @param customEventData 伙伴ID 
     */
    public usePet(event,customEventData) {
        let petId = Number(customEventData);

        let petConfig = PetConfig.getConfigById(petId);
        if(petConfig == null) {
            TipCtrl.getInstance().tip(this.node,"伙伴信息不存在");
            return;
        }

        PlayerCacheCtrl.getInstance().playerUsePet(petId);

        TipCtrl.getInstance().tip(this.node,"上阵伙伴：" + petConfig.name);

        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);


        this.init(PlayerCacheCtrl.getInstance().getPlayerUsePet());
    }
}
