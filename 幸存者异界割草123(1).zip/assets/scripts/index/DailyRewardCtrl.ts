// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import ItemConfig from "../config/ItemConfig";
import PlayerLevelConfig, { PlayerLevelBasic } from "../config/PlayerLevelConfig";
import AudioManager from "../manager/AudioManager";
import SdkCtrl from "../manager/SdkCtrl";
import DateUtil from "../utils/DateUtil";
import IndexCtrl from "./IndexCtrl";
import TipCtrl from "./TipCtrl";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DailyRewardCtrl extends cc.Component {

    @property(cc.Label)
    private rewardCount1:cc.Label = null;

    @property(cc.Label)
    private rewardDesc1:cc.Label = null;
    
    @property(cc.Button)
    private normalButton1:cc.Button = null;

    @property(cc.Button)
    private adButton1:cc.Button = null;

    @property(cc.Label)
    private rewardCount2:cc.Label = null;

    @property(cc.Label)
    private rewardDesc2:cc.Label = null;
    
    @property(cc.Button)
    private normalButton2:cc.Button = null;

    @property(cc.Button)
    private adButton2:cc.Button = null;
    
    @property(cc.Label)
    private rewardCount3:cc.Label = null;

    @property(cc.Label)
    private rewardDesc3:cc.Label = null;
    
    @property(cc.Button)
    private normalButton3:cc.Button = null;

    @property(cc.Button)
    private adButton3:cc.Button = null;

    start() {
        // this.init();
    }

    protected onEnable(): void {
        this.init();
    }

    init() {
        this.node.parent.parent.getComponent(IndexCtrl).resetGoldNumLabel();
        
        this.initShow(1,this.rewardCount1,this.rewardDesc1,this.normalButton1,this.adButton1);
        this.initShow(2,this.rewardCount2,this.rewardDesc2,this.normalButton2,this.adButton2);
        this.initShow(3,this.rewardCount3,this.rewardDesc3,this.normalButton3,this.adButton3);

    }

    /**
     * 初始化奖励展示信息
     */
    initShow(num:number,rewardCount:cc.Label,rewardDesc:cc.Label,normalButton:cc.Button,adButton:cc.Button) {
        let nowTime = new Date().getTime();
        let itemCount = this.getRewardCount(num);
        rewardCount.string = "+" + itemCount;

        let playerDailyRewardInfo = PlayerCacheCtrl.getInstance().getDailyRewardInfo();
        let dailyRewardTime = playerDailyRewardInfo.rewardTime;
        let dailyRewardCount = playerDailyRewardInfo.rewardCount;

        let isToday = DateUtil.isToday(dailyRewardTime);
        if(isToday && dailyRewardCount >= num) {
            normalButton.node.active = false;
            adButton.node.active = false;
            rewardDesc.string = "已领取";
            rewardDesc.node.active = true;
        }else if(isToday && dailyRewardCount + 1 == num && nowTime - dailyRewardTime < 300 * 1000) {
            normalButton.node.active = false;
            adButton.node.active = false;
            let subTime = Math.floor(300 - ((nowTime - dailyRewardTime) / 1000));
            rewardDesc.string = subTime + "秒后可领取该奖励";
            rewardDesc.node.color = cc.Color.BLACK;
            rewardDesc.node.active = true;
        }else if(dailyRewardCount + 1 < num ) {
            normalButton.node.active = false;
            adButton.node.active = false;
            rewardDesc.string = "领取上一个奖励后可领取";
            rewardDesc.node.color = cc.Color.GRAY;
            rewardDesc.node.active = true;
        }else if(!isToday) {
            if(num == 1) {
                normalButton.node.active = true;
                adButton.node.active = true;
                rewardDesc.node.active = false;
            }else {
                normalButton.node.active = false;
                adButton.node.active = false;
                rewardDesc.string = "领取上一个奖励后可领取";
                rewardDesc.node.color = cc.Color.GRAY;
                rewardDesc.node.active = true;
            }
        }else {
            normalButton.node.active = true;
            adButton.node.active = true;
            rewardDesc.node.active = false;
        }

    }

    /**
     * 普通领取
     */
    normalGain(event,customData) {
        let num = Number(customData);
        this.gainReward(false,num);
    }

    /**
     * 广告领取
     */
    adGain(event,customData) {
        let num = Number(customData);
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            this.gainReward(true,num);
        })
    }

    /**
     * 获得奖励
     * @param adFlag 广告获取
     * @param num 第几个奖励
     * @returns 
     */
    gainReward(adFlag,num) {
        let nowTime = new Date().getTime();

        let playerDailyRewardInfo = PlayerCacheCtrl.getInstance().getDailyRewardInfo();
        let rewardTime = playerDailyRewardInfo.rewardTime;
        let rewardCount = playerDailyRewardInfo.rewardCount;

        let isToday:boolean = DateUtil.isToday(rewardTime);
        if(isToday && rewardCount >= 3) {
            TipCtrl.getInstance().tip(this.node,"当日可领取的每日奖励已达上限");
            return;
        }

        // 不是第一个奖励，距离上一次领取奖励时间小于5分钟
        if(num > 1 && nowTime - rewardTime < 300 * 1000) {
            TipCtrl.getInstance().tip(this.node,"距离上一次领取奖励时间不足5分钟");
            return;
        }
        
        playerDailyRewardInfo.rewardTime = nowTime;
        playerDailyRewardInfo.rewardCount = num;

        // 更新每日奖励领取信息
        PlayerCacheCtrl.getInstance().setDailyRewardInfo(playerDailyRewardInfo);

        let addItemCount = this.getRewardCount(num);
        
        if(adFlag) {
            addItemCount = addItemCount * 3;
        }

        let addFlag = PlayerCacheCtrl.getInstance().addPlayerItem(Number(ItemConfig.ITEM_CONST.GOLD),addItemCount);
        if(!addFlag) {
            TipCtrl.getInstance().tip(this.node,"增加金币失败,请联系作者");
            return;
        }

        TipCtrl.getInstance().tip(this.node,"获得"+ addItemCount +"金币");

        // 重新渲染
        this.init();
    }

    /**
     * 获取每日奖励的金币数量
     * @param num 第几次奖励
     */
    getRewardCount(num) {
        let playerLevel = PlayerCacheCtrl.getInstance().getPlayerLevel();
        let playerLevelConfig:PlayerLevelBasic = PlayerLevelConfig.getConfigByLevel(playerLevel);
        if(playerLevelConfig == null) {
            return;
        }

        let multiNum = 1;
        if(num == 1) {
            multiNum = 0.6;
        }else if(num == 2) {
            multiNum = 0.8;
        }else if(num == 3) {
            multiNum = 1;
        }

        let addItemCount = playerLevelConfig.adGain * multiNum;

        return addItemCount;
    }
}
