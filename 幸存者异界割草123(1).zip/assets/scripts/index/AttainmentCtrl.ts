import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AttainmentConfig, { AttainmentBasic } from "../config/AttainmentConfig";
import AudioPathKey from "../config/AudioPathKey";
import attainmentConfig, { GongBasic } from "../config/attainmentConfig";
import ItemConfig, { ItemBasic } from "../config/ItemConfig";
import UiPathKey from "../config/UiPathKey";
import AudioManager from "../manager/AudioManager";
import ButtonUtil from "../utils/ButtonUtil";
import SpriteUtil from "../utils/SpriteUtil";
import IndexCtrl from "./IndexCtrl";
import TipCtrl from "./TipCtrl";
import SdkCtrl from "../manager/SdkCtrl";

const { ccclass, property } = cc._decorator;

@ccclass
export default class AttainmentCtrl extends cc.Component {

    @property(cc.Node)
    attainmentParentNode:cc.Node = null; // 成就父节点

    @property(cc.Prefab)
    attainmentPrefab:cc.Prefab = null; // 成就预制体

    @property(cc.Label)
    killCountLabel: cc.Label = null; // 击杀数量

    @property(cc.Label)
    aliveTimeLabel: cc.Label = null; // 存活时间
    

    onEnable() {
        this.init();
    }

    init() {
        this.node.parent.parent.getComponent(IndexCtrl).resetGoldNumLabel();
        this.attainmentParentNode.removeAllChildren();
        for(let i = 0; i < AttainmentConfig.CONFIG.length;i++) {
            let attainmentConfig:AttainmentBasic = AttainmentConfig.CONFIG[i];
            this.initShow(attainmentConfig);
        }

        this.killCountLabel.string = "击杀：" + PlayerCacheCtrl.getInstance().getKillCount();
        this.aliveTimeLabel.string = "存活：" + PlayerCacheCtrl.getInstance().getAliveTime();

        
        // 调整初始显示的区域
        if(AttainmentConfig.CONFIG.length > 5) {
            let yLen = 250;
            let subNum = 9;
            let attainmentParentNodeY = yLen * subNum * -1;
            this.attainmentParentNode.setPosition(cc.v2(0,attainmentParentNodeY));
        }
    }

    /**
     * 渲染
     */
    initShow(attainmentConfig:AttainmentBasic) {
        let attainment = cc.instantiate(this.attainmentPrefab);

        // 成就名称
        let name:cc.Label = attainment.getChildByName("name").getComponent(cc.Label);
        name.string = attainmentConfig.name;

        // 成就介绍
        let descContent:cc.Label = attainment.getChildByName("descContent").getComponent(cc.Label);
        descContent.string = attainmentConfig.desc;

        // 奖励介绍
        let awardContent:cc.Label = attainment.getChildByName("awardContent").getComponent(cc.Label);
        awardContent.string = "金币 * " + attainmentConfig.itemCount;

        // 检查成就状态
        let status = this.checkStatus(attainmentConfig);
        if(AttainmentConfig.STATUS_CONST.RECEIVE == status) {
            let lock:cc.Node = attainment.getChildByName("lock");
            lock.active = false;
            let alreadyReceive:cc.Label = attainment.getChildByName("alreadyReceive").getComponent(cc.Label);
            alreadyReceive.node.active = true;
        }else if(AttainmentConfig.STATUS_CONST.CAN_RECEIVE == status) {
            let lock:cc.Node = attainment.getChildByName("lock");
            lock.active = false;
            let receiveButton:cc.Button = attainment.getChildByName("receive").getComponent(cc.Button);
            ButtonUtil._setEvent(this.node,receiveButton,"AttainmentCtrl","receive",attainmentConfig.id + "");
            receiveButton.node.active = true;
            let adReceiveButton:cc.Button = attainment.getChildByName("adReceive").getComponent(cc.Button);
            ButtonUtil._setEvent(this.node,adReceiveButton,"AttainmentCtrl","adReceive",attainmentConfig.id + "");
            adReceiveButton.node.active = true;
        }
        
        this.attainmentParentNode.addChild(attainment);
        attainment.active = true;
    }

    /**
     * 检查成就状态
     * @param attainmentConfig 成就配置
     */
    private checkStatus(attainmentConfig:AttainmentBasic) {

        // 成就是否已经领取过
        let attainmentRewardInfo = PlayerCacheCtrl.getInstance().getAttainmentRewardInfo();
        if(attainmentRewardInfo[attainmentConfig.id + ""] != null) {
            return AttainmentConfig.STATUS_CONST.RECEIVE;
        }

        if(attainmentConfig.type == AttainmentConfig.TYPE_CONST.KILL) {
            let killCount = PlayerCacheCtrl.getInstance().getKillCount();
            if(killCount >= attainmentConfig.count) {
                return AttainmentConfig.STATUS_CONST.CAN_RECEIVE;
            }
        }else if(attainmentConfig.type == AttainmentConfig.TYPE_CONST.ALLIVE) {
            let alliveTime = PlayerCacheCtrl.getInstance().getAliveTime();
            if(alliveTime >= attainmentConfig.count) {
                return AttainmentConfig.STATUS_CONST.CAN_RECEIVE;
            }
        }

        return AttainmentConfig.STATUS_CONST.LOCK;
    }

    /**
     * 广告领取
     * @param event 
     * @param customEventData 成就ID 
     */
    adReceive(event,customEventData) {
        SdkCtrl.getInstance().ShowRewardedVideoAd(()=>{
            this.execReceive(customEventData,true);
        })
    }

    /**
     * 成就升级
     * @param event 
     * @param customEventData 成就ID 
     */
    receive(event,customEventData) {
        this.execReceive(customEventData,false);
    }

    /**
     * 执行成就奖励领取
     * @param id 成就ID
     * @param ad 是否为广告领取
     * @returns 
     */
    execReceive(id,ad:boolean) {
        if(id == null) {
            return;
        }

        let attainmentId = Number(id);
        let attainmentConfig:AttainmentBasic = AttainmentConfig.getConfigById(attainmentId);
        if(attainmentConfig == null) {
            cc.log("成就配置不存在,id:",attainmentId);
            return;
        }

        // 成就是否可以领取
        let status = this.checkStatus(attainmentConfig);
        if(AttainmentConfig.STATUS_CONST.CAN_RECEIVE != status) {
            cc.log("成就不可领取,id:",attainmentId);
            return;
        }

        // 奖励
        let addItemCount = attainmentConfig.itemCount;
        if(ad) {
            addItemCount = addItemCount * 3;
        }

        let addFlag = PlayerCacheCtrl.getInstance().addPlayerItem(Number(ItemConfig.ITEM_CONST.GOLD),addItemCount);
        if(!addFlag) {
            TipCtrl.getInstance().tip(this.node,"增加金币失败,请联系作者");
            return;
        }

        // 记录成就领取记录
        let attainmentRewardInfo = PlayerCacheCtrl.getInstance().getAttainmentRewardInfo();
        attainmentRewardInfo["" + id] = true;
        PlayerCacheCtrl.getInstance().setAttainmentRewardInfo(attainmentRewardInfo);

        TipCtrl.getInstance().tip(this.node,"获得"+ addItemCount +"金币");

        AudioManager.getInstance().playerAudio(AudioPathKey.LEVEL_UP_AUDIO,false);
        
        // 渲染
        this.init();
    }
}
