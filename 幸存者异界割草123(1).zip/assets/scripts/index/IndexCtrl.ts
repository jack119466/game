// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ChapterConfig, { ChapterBasic } from "../config/ChapterConfig";
import PlayerLevelConfig from "../config/PlayerLevelConfig";
import SceneKey from "../config/SecenKey";
import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import ItemConfig from "../config/ItemConfig";
import GeneralConfig from "../config/GeneralConfig";
import GongConfig from "../config/GongConfig";
import GlobalConfig from "../config/GlobalConfig";
import PetConfig from "../config/PetConfig";
import AudioManager from "../manager/AudioManager";
import AudioPathKey from "../config/AudioPathKey";
import MapManager from "../manager/MapManager";
import PlatformUtil from "../utils/PlatformUtil";
import SdkCtrl from "../manager/SdkCtrl";
import AttainmentConfig from "../config/AttainmentConfig";

const {ccclass, property} = cc._decorator;

@ccclass
export default class IndexCtrl extends cc.Component {

    @property(cc.Node)
    petNavNode:cc.Node = null; // 导航栏-伙伴节点

    @property(cc.Node)
    talentNavNode:cc.Node = null; // 导航栏-天赋节点

    @property(cc.Node)
    generalNavNode:cc.Node = null; // 导航栏-角色节点

    @property(cc.Node)
    mineNavNode:cc.Node = null; // 导航栏-强化节点

    @property(cc.Node)
    viewNode:cc.Node = null; // 页面

    @property(cc.Node)
    mineNode:cc.Node = null; // 强化

    @property(cc.Node)
    petNode:cc.Node = null; // 伙伴

    @property(cc.Node)
    talentNode:cc.Node = null; // 天赋

    @property(cc.Node)
    fightNode:cc.Node = null; // 秘境

    @property(cc.Node)
    generalNode:cc.Node = null; // 角色

    @property(cc.Node)
    settingNode:cc.Node = null; // 设置

    @property(cc.Node)
    dailyRewardNode:cc.Node = null; // 每日奖励

    @property(cc.Node)
    attainmentRewardNode:cc.Node = null; // 成就奖励
    
    @property(cc.Label)
    goldNumLabel:cc.Label = null; // 玩家金币数量

    start () {

        // 加载配置
        ChapterConfig.loadConfigMap();
        PlayerLevelConfig.loadConfigMap();
        ItemConfig.loadConfigMap();
        GeneralConfig.loadConfigMap();
        GongConfig.loadConfigMap();
        PetConfig.loadConfigMap();
        AttainmentConfig.loadConfigMap();

        // 初始加载地图资源
        MapManager.getInstance().initMapPic();

    }

    // update (dt) {
    // }

    protected onEnable(): void {
        // 重新渲染玩家金币数量
        this.resetGoldNumLabel();

        // banner广告
        // SdkCtrl.getInstance().ShowBanner();
    }

    toFunction(event,customEventData) {
        this.allHidden();
        if(customEventData == 1) {
            this.toPet();
        }else if(customEventData == 2){
            this.toTalent();
        }else if(customEventData == 3){
            this.toFight();
        }else if(customEventData == 4){
            this.toGeneral();
        }else if(customEventData == 5){
            this.toSetting();
        }else if(customEventData == 6){
            this.toMine();
        }else if(customEventData == 7){
            this.toDailyReward();
        }else if(customEventData == 8){
            this.toAttainmentReward();
        }
        // banner广告
        // SdkCtrl.getInstance().ShowBanner();

        AudioManager.getInstance().playerAudio(AudioPathKey.OPEN_VIEW_AUDIO,false);
        this.viewNode.active = true;
    }

    closeView() {
        // SdkCtrl.getInstance().HideBanner();
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
        this.viewNode.active = false;
    }

    // 1-跳转到伙伴界面
    toPet() {
        this.petNode.active = true;
    }

    // 2-跳转到天赋界面
    toTalent() {
        this.talentNode.active = true;
    }

    // 3-跳转到关卡界面
    toFight() {
        this.fightNode.active = true;
    }

    // 4-跳转到角色界面
    toGeneral() {
        this.generalNode.active = true;
    }

    // 5-跳转到设置界面
    toSetting() {
        this.settingNode.active = true;
    }

    // 6-跳转到强化界面
    toMine() {
        this.mineNode.active = true;
    }

    // 7-跳转到每日奖励界面
    toDailyReward() {
        this.dailyRewardNode.active = true;
    }

    // 8-跳转到成就奖励界面
    toAttainmentReward() {
        this.attainmentRewardNode.active = true;
    }

    // 先隐藏所有
    allHidden() {
        this.fightNode.active = false;
        this.petNode.active = false;
        this.talentNode.active = false;
        this.settingNode.active = false;
        this.generalNode.active = false;
        this.mineNode.active = false;
        this.dailyRewardNode.active = false;
        this.attainmentRewardNode.active = false;
    }


    // 渲染金币数量
    public resetGoldNumLabel() {
        this.goldNumLabel.string = PlayerCacheCtrl.getInstance().getPlayerGoldNum() + "";
    }
    

    // 测试增加资源 itemId_itemCount
    testAddRes(event,customEventData) {
        if(GlobalConfig.IS_TEST) {
            AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
            let item = customEventData.toString().split("_");
            PlayerCacheCtrl.getInstance().addPlayerItem(Number(item[0]),Number(item[1]));
            this.resetGoldNumLabel();
        }
    }
}
