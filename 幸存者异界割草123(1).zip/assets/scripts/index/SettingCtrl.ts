import PlayerCacheCtrl from "../cache/PlayerCacheCtrl";
import AudioPathKey from "../config/AudioPathKey";
import AudioManager from "../manager/AudioManager";

const {ccclass, property} = cc._decorator;

/**
 * 修行
 */
@ccclass
export default class SettingCtrl extends cc.Component {

    @property(cc.Button)
    damageTextStatusButton:cc.Button = null; // 展示伤害开关

    @property(cc.Button)
    audioStatusButton:cc.Button = null; // 播放声音开关

    onLoad () {

        this.init();
    }

    start () {

    }

    // 渲染玩家系统设置
    init() {

        let sysSetting = PlayerCacheCtrl.getInstance().getSysSetting();
        cc.log(sysSetting);
        let audioStatus = sysSetting.audioStatus;
        let damageTextStatus = sysSetting.damageTextStatus;

        let audioLabel = "开启";
        if(!audioStatus) {
            audioLabel = "关闭";
        }
        this.audioStatusButton.node.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = audioLabel;

        let textLabel = "开启";
        if(!damageTextStatus) {
            textLabel = "关闭";
        }
        this.damageTextStatusButton.node.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = textLabel;

    }
    

    editAudioStatus() {
        let sysSetting = PlayerCacheCtrl.getInstance().getSysSetting();
        let audioStatus = sysSetting.audioStatus;
        PlayerCacheCtrl.getInstance().editAudioStatus(!audioStatus);
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
        this.init();
    }

    editTextStatus() {
        let sysSetting = PlayerCacheCtrl.getInstance().getSysSetting();
        let damageTextStatus = sysSetting.damageTextStatus;
        PlayerCacheCtrl.getInstance().editDamageTextStatus(!damageTextStatus);
        AudioManager.getInstance().playerAudio(AudioPathKey.BOTTON_NAV_AUDIO,false);
        this.init();
    }
}
