
const {ccclass, property} = cc._decorator;

/**
 * 掉落基础类
 */
@ccclass
export default class BaseDrop extends cc.Component {
    
    public itemId: number = null; // 物品ID

    public num: number = null; // 数量

    public pos: cc.Vec2 = null; // 掉落位置

    public destroyType: number = 0; // 销毁类型 1-时间 2-范围

    public destroyContent: number = 0; // 销毁内容

    public isAlive = false; // 是否还存活

    public existTime = 0; // 存活时间

    start () {

    }

    init(dropConfig:any) {
        this.initProp(dropConfig);
    }

    initProp(dropConfig:any) {
        this.itemId = dropConfig.itemId;
        this.num = dropConfig.num;
        this.pos = dropConfig.pos;
        this.destroyType = dropConfig.destroyType;
        this.destroyContent = dropConfig.destroyContent;
        this.isAlive = true;
    }

    update (dt) {
        this.existTime += dt;

        if(!this.isAlive) {
            return;
        }

        // 销毁类型-时间
        if(this.destroyType == 1 && this.existTime * 1000 >= this.destroyContent) {
            this.node.destroy();
            return;
        }

        // 销毁类型-超出范围，待实现 todo
        if(this.destroyType == 2 && false) {
            
        }
    
    }

    /**
     * 被拾取了
     * @param gainNode 获得者节点
     */
    bePacking(gainNode:cc.Node) {
        if(!this.isAlive) {
            return;
        }
        this.isAlive = false;
        this.node.destroy();
    }
}
