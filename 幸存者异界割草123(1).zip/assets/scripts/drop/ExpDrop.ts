
import AudioPathKey from "../config/AudioPathKey";
import AudioManager from "../manager/AudioManager";
import Player from "../player/Player";
import BaseDrop from "./BaseDrop";

const {ccclass, property} = cc._decorator;

@ccclass
export default class ExpDrop extends BaseDrop {

   
    start () {

    }

    /**
     * 被拾取了
     * @param gainNode 获得者节点
     */
    bePacking(gainNode:cc.Node): void {
        if(!this.isAlive) {
            return;
        }
        this.isAlive = false;

        // 通知获得者增加经验
        if(gainNode == null) {
            return;
        }

        let player: Player = gainNode.getComponent(Player);
        if(!player || !player.isAlive) {
            return;
        }

        let gainPos: cc.Vec2 = this.node.parent.convertToNodeSpaceAR(gainNode.convertToWorldSpaceAR(cc.Vec2.ZERO));

        // 执行动画
        this.doMove(gainPos,() => {
            // 增加玩家经验
            player.addExp(this.num);

            AudioManager.getInstance().playerAudio(AudioPathKey.GAIN.EXP,false);

            // 销毁自身
            this.node.destroy();
        });
    }

    doMove(pos,call) {
        cc.tween(this.node)
        .to(0.2,{
            x : pos.x,
            y : pos.y
        })
        .call(() => {
            call&call(); // 执行回调
        })
        .start();
    }
}
